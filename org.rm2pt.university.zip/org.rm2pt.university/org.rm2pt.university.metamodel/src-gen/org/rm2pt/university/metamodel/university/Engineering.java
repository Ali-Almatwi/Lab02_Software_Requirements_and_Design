/**
 */
package org.rm2pt.university.metamodel.university;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Engineering</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getEngineering()
 * @model
 * @generated
 */
public interface Engineering extends org.rm2pt.university.metamodel.university.Class {

} // Engineering
