/**
 */
package org.rm2pt.university.metamodel.university;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.rm2pt.university.metamodel.university.UniversityFactory
 * @model kind="package"
 * @generated
 */
public interface UniversityPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "university";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/university";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "university";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	UniversityPackage eINSTANCE = org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.rm2pt.university.metamodel.university.impl.UniversityImpl <em>University</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.university.metamodel.university.impl.UniversityImpl
	 * @see org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl#getUniversity()
	 * @generated
	 */
	int UNIVERSITY = 0;

	/**
	 * The feature id for the '<em><b>University name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIVERSITY__UNIVERSITY_NAME = 0;

	/**
	 * The feature id for the '<em><b>Classes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIVERSITY__CLASSES = 1;

	/**
	 * The number of structural features of the '<em>University</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIVERSITY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>University</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIVERSITY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.university.metamodel.university.impl.ClassImpl <em>Class</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.university.metamodel.university.impl.ClassImpl
	 * @see org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl#getClass_()
	 * @generated
	 */
	int CLASS = 1;

	/**
	 * The feature id for the '<em><b>Teaches</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__TEACHES = 0;

	/**
	 * The feature id for the '<em><b>Learns</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__LEARNS = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__ID = 2;

	/**
	 * The feature id for the '<em><b>Computer science</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__COMPUTER_SCIENCE = 3;

	/**
	 * The feature id for the '<em><b>It</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__IT = 4;

	/**
	 * The feature id for the '<em><b>Engineering</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__ENGINEERING = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__NAME = 6;

	/**
	 * The feature id for the '<em><b>Phone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__PHONE = 7;

	/**
	 * The number of structural features of the '<em>Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.university.metamodel.university.impl.Computer_scienceImpl <em>Computer science</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.university.metamodel.university.impl.Computer_scienceImpl
	 * @see org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl#getComputer_science()
	 * @generated
	 */
	int COMPUTER_SCIENCE = 2;

	/**
	 * The feature id for the '<em><b>Teaches</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_SCIENCE__TEACHES = CLASS__TEACHES;

	/**
	 * The feature id for the '<em><b>Learns</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_SCIENCE__LEARNS = CLASS__LEARNS;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_SCIENCE__ID = CLASS__ID;

	/**
	 * The feature id for the '<em><b>Computer science</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_SCIENCE__COMPUTER_SCIENCE = CLASS__COMPUTER_SCIENCE;

	/**
	 * The feature id for the '<em><b>It</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_SCIENCE__IT = CLASS__IT;

	/**
	 * The feature id for the '<em><b>Engineering</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_SCIENCE__ENGINEERING = CLASS__ENGINEERING;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_SCIENCE__NAME = CLASS__NAME;

	/**
	 * The feature id for the '<em><b>Phone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_SCIENCE__PHONE = CLASS__PHONE;

	/**
	 * The number of structural features of the '<em>Computer science</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_SCIENCE_FEATURE_COUNT = CLASS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Computer science</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_SCIENCE_OPERATION_COUNT = CLASS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.university.metamodel.university.impl.ITImpl <em>IT</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.university.metamodel.university.impl.ITImpl
	 * @see org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl#getIT()
	 * @generated
	 */
	int IT = 3;

	/**
	 * The feature id for the '<em><b>Teaches</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IT__TEACHES = CLASS__TEACHES;

	/**
	 * The feature id for the '<em><b>Learns</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IT__LEARNS = CLASS__LEARNS;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IT__ID = CLASS__ID;

	/**
	 * The feature id for the '<em><b>Computer science</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IT__COMPUTER_SCIENCE = CLASS__COMPUTER_SCIENCE;

	/**
	 * The feature id for the '<em><b>It</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IT__IT = CLASS__IT;

	/**
	 * The feature id for the '<em><b>Engineering</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IT__ENGINEERING = CLASS__ENGINEERING;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IT__NAME = CLASS__NAME;

	/**
	 * The feature id for the '<em><b>Phone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IT__PHONE = CLASS__PHONE;

	/**
	 * The number of structural features of the '<em>IT</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IT_FEATURE_COUNT = CLASS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>IT</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IT_OPERATION_COUNT = CLASS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.university.metamodel.university.impl.EngineeringImpl <em>Engineering</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.university.metamodel.university.impl.EngineeringImpl
	 * @see org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl#getEngineering()
	 * @generated
	 */
	int ENGINEERING = 4;

	/**
	 * The feature id for the '<em><b>Teaches</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINEERING__TEACHES = CLASS__TEACHES;

	/**
	 * The feature id for the '<em><b>Learns</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINEERING__LEARNS = CLASS__LEARNS;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINEERING__ID = CLASS__ID;

	/**
	 * The feature id for the '<em><b>Computer science</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINEERING__COMPUTER_SCIENCE = CLASS__COMPUTER_SCIENCE;

	/**
	 * The feature id for the '<em><b>It</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINEERING__IT = CLASS__IT;

	/**
	 * The feature id for the '<em><b>Engineering</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINEERING__ENGINEERING = CLASS__ENGINEERING;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINEERING__NAME = CLASS__NAME;

	/**
	 * The feature id for the '<em><b>Phone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINEERING__PHONE = CLASS__PHONE;

	/**
	 * The number of structural features of the '<em>Engineering</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINEERING_FEATURE_COUNT = CLASS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Engineering</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINEERING_OPERATION_COUNT = CLASS_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link org.rm2pt.university.metamodel.university.University <em>University</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>University</em>'.
	 * @see org.rm2pt.university.metamodel.university.University
	 * @generated
	 */
	EClass getUniversity();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.university.metamodel.university.University#getUniversity_name <em>University name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>University name</em>'.
	 * @see org.rm2pt.university.metamodel.university.University#getUniversity_name()
	 * @see #getUniversity()
	 * @generated
	 */
	EAttribute getUniversity_University_name();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.university.metamodel.university.University#getClasses <em>Classes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Classes</em>'.
	 * @see org.rm2pt.university.metamodel.university.University#getClasses()
	 * @see #getUniversity()
	 * @generated
	 */
	EReference getUniversity_Classes();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.university.metamodel.university.Class <em>Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Class</em>'.
	 * @see org.rm2pt.university.metamodel.university.Class
	 * @generated
	 */
	EClass getClass_();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.university.metamodel.university.Class#getTeaches <em>Teaches</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Teaches</em>'.
	 * @see org.rm2pt.university.metamodel.university.Class#getTeaches()
	 * @see #getClass_()
	 * @generated
	 */
	EReference getClass_Teaches();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.university.metamodel.university.Class#getLearns <em>Learns</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Learns</em>'.
	 * @see org.rm2pt.university.metamodel.university.Class#getLearns()
	 * @see #getClass_()
	 * @generated
	 */
	EReference getClass_Learns();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.university.metamodel.university.Class#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see org.rm2pt.university.metamodel.university.Class#getId()
	 * @see #getClass_()
	 * @generated
	 */
	EAttribute getClass_Id();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.university.metamodel.university.Class#getComputer_science <em>Computer science</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Computer science</em>'.
	 * @see org.rm2pt.university.metamodel.university.Class#getComputer_science()
	 * @see #getClass_()
	 * @generated
	 */
	EReference getClass_Computer_science();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.university.metamodel.university.Class#getIt <em>It</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>It</em>'.
	 * @see org.rm2pt.university.metamodel.university.Class#getIt()
	 * @see #getClass_()
	 * @generated
	 */
	EReference getClass_It();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.university.metamodel.university.Class#getEngineering <em>Engineering</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Engineering</em>'.
	 * @see org.rm2pt.university.metamodel.university.Class#getEngineering()
	 * @see #getClass_()
	 * @generated
	 */
	EReference getClass_Engineering();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.university.metamodel.university.Class#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.university.metamodel.university.Class#getName()
	 * @see #getClass_()
	 * @generated
	 */
	EAttribute getClass_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.university.metamodel.university.Class#getPhone <em>Phone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Phone</em>'.
	 * @see org.rm2pt.university.metamodel.university.Class#getPhone()
	 * @see #getClass_()
	 * @generated
	 */
	EAttribute getClass_Phone();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.university.metamodel.university.Computer_science <em>Computer science</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Computer science</em>'.
	 * @see org.rm2pt.university.metamodel.university.Computer_science
	 * @generated
	 */
	EClass getComputer_science();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.university.metamodel.university.IT <em>IT</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>IT</em>'.
	 * @see org.rm2pt.university.metamodel.university.IT
	 * @generated
	 */
	EClass getIT();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.university.metamodel.university.Engineering <em>Engineering</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Engineering</em>'.
	 * @see org.rm2pt.university.metamodel.university.Engineering
	 * @generated
	 */
	EClass getEngineering();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	UniversityFactory getUniversityFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.rm2pt.university.metamodel.university.impl.UniversityImpl <em>University</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.university.metamodel.university.impl.UniversityImpl
		 * @see org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl#getUniversity()
		 * @generated
		 */
		EClass UNIVERSITY = eINSTANCE.getUniversity();

		/**
		 * The meta object literal for the '<em><b>University name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute UNIVERSITY__UNIVERSITY_NAME = eINSTANCE.getUniversity_University_name();

		/**
		 * The meta object literal for the '<em><b>Classes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference UNIVERSITY__CLASSES = eINSTANCE.getUniversity_Classes();

		/**
		 * The meta object literal for the '{@link org.rm2pt.university.metamodel.university.impl.ClassImpl <em>Class</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.university.metamodel.university.impl.ClassImpl
		 * @see org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl#getClass_()
		 * @generated
		 */
		EClass CLASS = eINSTANCE.getClass_();

		/**
		 * The meta object literal for the '<em><b>Teaches</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASS__TEACHES = eINSTANCE.getClass_Teaches();

		/**
		 * The meta object literal for the '<em><b>Learns</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASS__LEARNS = eINSTANCE.getClass_Learns();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLASS__ID = eINSTANCE.getClass_Id();

		/**
		 * The meta object literal for the '<em><b>Computer science</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASS__COMPUTER_SCIENCE = eINSTANCE.getClass_Computer_science();

		/**
		 * The meta object literal for the '<em><b>It</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASS__IT = eINSTANCE.getClass_It();

		/**
		 * The meta object literal for the '<em><b>Engineering</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASS__ENGINEERING = eINSTANCE.getClass_Engineering();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLASS__NAME = eINSTANCE.getClass_Name();

		/**
		 * The meta object literal for the '<em><b>Phone</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLASS__PHONE = eINSTANCE.getClass_Phone();

		/**
		 * The meta object literal for the '{@link org.rm2pt.university.metamodel.university.impl.Computer_scienceImpl <em>Computer science</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.university.metamodel.university.impl.Computer_scienceImpl
		 * @see org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl#getComputer_science()
		 * @generated
		 */
		EClass COMPUTER_SCIENCE = eINSTANCE.getComputer_science();

		/**
		 * The meta object literal for the '{@link org.rm2pt.university.metamodel.university.impl.ITImpl <em>IT</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.university.metamodel.university.impl.ITImpl
		 * @see org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl#getIT()
		 * @generated
		 */
		EClass IT = eINSTANCE.getIT();

		/**
		 * The meta object literal for the '{@link org.rm2pt.university.metamodel.university.impl.EngineeringImpl <em>Engineering</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.university.metamodel.university.impl.EngineeringImpl
		 * @see org.rm2pt.university.metamodel.university.impl.UniversityPackageImpl#getEngineering()
		 * @generated
		 */
		EClass ENGINEERING = eINSTANCE.getEngineering();

	}

} //UniversityPackage
