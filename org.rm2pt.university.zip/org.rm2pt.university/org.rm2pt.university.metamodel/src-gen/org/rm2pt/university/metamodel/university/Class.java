/**
 */
package org.rm2pt.university.metamodel.university;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.university.metamodel.university.Class#getTeaches <em>Teaches</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.Class#getLearns <em>Learns</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.Class#getId <em>Id</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.Class#getComputer_science <em>Computer science</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.Class#getIt <em>It</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.Class#getEngineering <em>Engineering</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.Class#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.Class#getPhone <em>Phone</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getClass_()
 * @model abstract="true"
 * @generated
 */
public interface Class extends EObject {
	/**
	 * Returns the value of the '<em><b>Teaches</b></em>' reference list.
	 * The list contents are of type {@link org.rm2pt.university.metamodel.university.Class}.
	 * It is bidirectional and its opposite is '{@link org.rm2pt.university.metamodel.university.Class#getLearns <em>Learns</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Teaches</em>' reference list.
	 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getClass_Teaches()
	 * @see org.rm2pt.university.metamodel.university.Class#getLearns
	 * @model opposite="learns"
	 * @generated
	 */
	EList<Class> getTeaches();

	/**
	 * Returns the value of the '<em><b>Learns</b></em>' reference list.
	 * The list contents are of type {@link org.rm2pt.university.metamodel.university.Class}.
	 * It is bidirectional and its opposite is '{@link org.rm2pt.university.metamodel.university.Class#getTeaches <em>Teaches</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Learns</em>' reference list.
	 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getClass_Learns()
	 * @see org.rm2pt.university.metamodel.university.Class#getTeaches
	 * @model opposite="teaches"
	 * @generated
	 */
	EList<Class> getLearns();

	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(int)
	 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getClass_Id()
	 * @model
	 * @generated
	 */
	int getId();

	/**
	 * Sets the value of the '{@link org.rm2pt.university.metamodel.university.Class#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(int value);

	/**
	 * Returns the value of the '<em><b>Computer science</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Computer science</em>' reference.
	 * @see #setComputer_science(Computer_science)
	 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getClass_Computer_science()
	 * @model derived="true"
	 * @generated
	 */
	Computer_science getComputer_science();

	/**
	 * Sets the value of the '{@link org.rm2pt.university.metamodel.university.Class#getComputer_science <em>Computer science</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Computer science</em>' reference.
	 * @see #getComputer_science()
	 * @generated
	 */
	void setComputer_science(Computer_science value);

	/**
	 * Returns the value of the '<em><b>It</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>It</em>' reference.
	 * @see #setIt(IT)
	 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getClass_It()
	 * @model derived="true"
	 * @generated
	 */
	IT getIt();

	/**
	 * Sets the value of the '{@link org.rm2pt.university.metamodel.university.Class#getIt <em>It</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>It</em>' reference.
	 * @see #getIt()
	 * @generated
	 */
	void setIt(IT value);

	/**
	 * Returns the value of the '<em><b>Engineering</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Engineering</em>' reference.
	 * @see #setEngineering(Engineering)
	 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getClass_Engineering()
	 * @model derived="true"
	 * @generated
	 */
	Engineering getEngineering();

	/**
	 * Sets the value of the '{@link org.rm2pt.university.metamodel.university.Class#getEngineering <em>Engineering</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Engineering</em>' reference.
	 * @see #getEngineering()
	 * @generated
	 */
	void setEngineering(Engineering value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getClass_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.university.metamodel.university.Class#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Phone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Phone</em>' attribute.
	 * @see #setPhone(String)
	 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getClass_Phone()
	 * @model
	 * @generated
	 */
	String getPhone();

	/**
	 * Sets the value of the '{@link org.rm2pt.university.metamodel.university.Class#getPhone <em>Phone</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Phone</em>' attribute.
	 * @see #getPhone()
	 * @generated
	 */
	void setPhone(String value);

} // Class
