/**
 */
package org.rm2pt.university.metamodel.university.impl;

import org.eclipse.emf.ecore.EClass;
import org.rm2pt.university.metamodel.university.Computer_science;
import org.rm2pt.university.metamodel.university.UniversityPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Computer science</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class Computer_scienceImpl extends ClassImpl implements Computer_science {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Computer_scienceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UniversityPackage.Literals.COMPUTER_SCIENCE;
	}

} //Computer_scienceImpl
