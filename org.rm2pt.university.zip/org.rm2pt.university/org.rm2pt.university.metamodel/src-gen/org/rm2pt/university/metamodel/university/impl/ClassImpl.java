/**
 */
package org.rm2pt.university.metamodel.university.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.rm2pt.university.metamodel.university.Computer_science;
import org.rm2pt.university.metamodel.university.Engineering;
import org.rm2pt.university.metamodel.university.IT;
import org.rm2pt.university.metamodel.university.UniversityPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Class</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.university.metamodel.university.impl.ClassImpl#getTeaches <em>Teaches</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.impl.ClassImpl#getLearns <em>Learns</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.impl.ClassImpl#getId <em>Id</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.impl.ClassImpl#getComputer_science <em>Computer science</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.impl.ClassImpl#getIt <em>It</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.impl.ClassImpl#getEngineering <em>Engineering</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.impl.ClassImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.impl.ClassImpl#getPhone <em>Phone</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ClassImpl extends MinimalEObjectImpl.Container
		implements org.rm2pt.university.metamodel.university.Class {
	/**
	 * The cached value of the '{@link #getTeaches() <em>Teaches</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTeaches()
	 * @generated
	 * @ordered
	 */
	protected EList<org.rm2pt.university.metamodel.university.Class> teaches;

	/**
	 * The cached value of the '{@link #getLearns() <em>Learns</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLearns()
	 * @generated
	 * @ordered
	 */
	protected EList<org.rm2pt.university.metamodel.university.Class> learns;

	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final int ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected int id = ID_EDEFAULT;

	/**
	 * The cached value of the '{@link #getComputer_science() <em>Computer science</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComputer_science()
	 * @generated
	 * @ordered
	 */
	protected Computer_science computer_science;

	/**
	 * The cached value of the '{@link #getIt() <em>It</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIt()
	 * @generated
	 * @ordered
	 */
	protected IT it;

	/**
	 * The cached value of the '{@link #getEngineering() <em>Engineering</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEngineering()
	 * @generated
	 * @ordered
	 */
	protected Engineering engineering;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPhone() <em>Phone</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhone()
	 * @generated
	 * @ordered
	 */
	protected static final String PHONE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPhone() <em>Phone</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhone()
	 * @generated
	 * @ordered
	 */
	protected String phone = PHONE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClassImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UniversityPackage.Literals.CLASS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<org.rm2pt.university.metamodel.university.Class> getTeaches() {
		if (teaches == null) {
			teaches = new EObjectWithInverseResolvingEList.ManyInverse<org.rm2pt.university.metamodel.university.Class>(
					org.rm2pt.university.metamodel.university.Class.class, this, UniversityPackage.CLASS__TEACHES,
					UniversityPackage.CLASS__LEARNS);
		}
		return teaches;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<org.rm2pt.university.metamodel.university.Class> getLearns() {
		if (learns == null) {
			learns = new EObjectWithInverseResolvingEList.ManyInverse<org.rm2pt.university.metamodel.university.Class>(
					org.rm2pt.university.metamodel.university.Class.class, this, UniversityPackage.CLASS__LEARNS,
					UniversityPackage.CLASS__TEACHES);
		}
		return learns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId(int newId) {
		int oldId = id;
		id = newId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UniversityPackage.CLASS__ID, oldId, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Computer_science getComputer_science() {
		if (computer_science != null && computer_science.eIsProxy()) {
			InternalEObject oldComputer_science = (InternalEObject) computer_science;
			computer_science = (Computer_science) eResolveProxy(oldComputer_science);
			if (computer_science != oldComputer_science) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UniversityPackage.CLASS__COMPUTER_SCIENCE,
							oldComputer_science, computer_science));
			}
		}
		return computer_science;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Computer_science basicGetComputer_science() {
		return computer_science;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setComputer_science(Computer_science newComputer_science) {
		Computer_science oldComputer_science = computer_science;
		computer_science = newComputer_science;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UniversityPackage.CLASS__COMPUTER_SCIENCE,
					oldComputer_science, computer_science));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IT getIt() {
		if (it != null && it.eIsProxy()) {
			InternalEObject oldIt = (InternalEObject) it;
			it = (IT) eResolveProxy(oldIt);
			if (it != oldIt) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UniversityPackage.CLASS__IT, oldIt, it));
			}
		}
		return it;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IT basicGetIt() {
		return it;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIt(IT newIt) {
		IT oldIt = it;
		it = newIt;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UniversityPackage.CLASS__IT, oldIt, it));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Engineering getEngineering() {
		if (engineering != null && engineering.eIsProxy()) {
			InternalEObject oldEngineering = (InternalEObject) engineering;
			engineering = (Engineering) eResolveProxy(oldEngineering);
			if (engineering != oldEngineering) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, UniversityPackage.CLASS__ENGINEERING,
							oldEngineering, engineering));
			}
		}
		return engineering;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Engineering basicGetEngineering() {
		return engineering;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEngineering(Engineering newEngineering) {
		Engineering oldEngineering = engineering;
		engineering = newEngineering;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UniversityPackage.CLASS__ENGINEERING, oldEngineering,
					engineering));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UniversityPackage.CLASS__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPhone(String newPhone) {
		String oldPhone = phone;
		phone = newPhone;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UniversityPackage.CLASS__PHONE, oldPhone, phone));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UniversityPackage.CLASS__TEACHES:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getTeaches()).basicAdd(otherEnd, msgs);
		case UniversityPackage.CLASS__LEARNS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getLearns()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UniversityPackage.CLASS__TEACHES:
			return ((InternalEList<?>) getTeaches()).basicRemove(otherEnd, msgs);
		case UniversityPackage.CLASS__LEARNS:
			return ((InternalEList<?>) getLearns()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UniversityPackage.CLASS__TEACHES:
			return getTeaches();
		case UniversityPackage.CLASS__LEARNS:
			return getLearns();
		case UniversityPackage.CLASS__ID:
			return getId();
		case UniversityPackage.CLASS__COMPUTER_SCIENCE:
			if (resolve)
				return getComputer_science();
			return basicGetComputer_science();
		case UniversityPackage.CLASS__IT:
			if (resolve)
				return getIt();
			return basicGetIt();
		case UniversityPackage.CLASS__ENGINEERING:
			if (resolve)
				return getEngineering();
			return basicGetEngineering();
		case UniversityPackage.CLASS__NAME:
			return getName();
		case UniversityPackage.CLASS__PHONE:
			return getPhone();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UniversityPackage.CLASS__TEACHES:
			getTeaches().clear();
			getTeaches().addAll((Collection<? extends org.rm2pt.university.metamodel.university.Class>) newValue);
			return;
		case UniversityPackage.CLASS__LEARNS:
			getLearns().clear();
			getLearns().addAll((Collection<? extends org.rm2pt.university.metamodel.university.Class>) newValue);
			return;
		case UniversityPackage.CLASS__ID:
			setId((Integer) newValue);
			return;
		case UniversityPackage.CLASS__COMPUTER_SCIENCE:
			setComputer_science((Computer_science) newValue);
			return;
		case UniversityPackage.CLASS__IT:
			setIt((IT) newValue);
			return;
		case UniversityPackage.CLASS__ENGINEERING:
			setEngineering((Engineering) newValue);
			return;
		case UniversityPackage.CLASS__NAME:
			setName((String) newValue);
			return;
		case UniversityPackage.CLASS__PHONE:
			setPhone((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UniversityPackage.CLASS__TEACHES:
			getTeaches().clear();
			return;
		case UniversityPackage.CLASS__LEARNS:
			getLearns().clear();
			return;
		case UniversityPackage.CLASS__ID:
			setId(ID_EDEFAULT);
			return;
		case UniversityPackage.CLASS__COMPUTER_SCIENCE:
			setComputer_science((Computer_science) null);
			return;
		case UniversityPackage.CLASS__IT:
			setIt((IT) null);
			return;
		case UniversityPackage.CLASS__ENGINEERING:
			setEngineering((Engineering) null);
			return;
		case UniversityPackage.CLASS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case UniversityPackage.CLASS__PHONE:
			setPhone(PHONE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UniversityPackage.CLASS__TEACHES:
			return teaches != null && !teaches.isEmpty();
		case UniversityPackage.CLASS__LEARNS:
			return learns != null && !learns.isEmpty();
		case UniversityPackage.CLASS__ID:
			return id != ID_EDEFAULT;
		case UniversityPackage.CLASS__COMPUTER_SCIENCE:
			return computer_science != null;
		case UniversityPackage.CLASS__IT:
			return it != null;
		case UniversityPackage.CLASS__ENGINEERING:
			return engineering != null;
		case UniversityPackage.CLASS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case UniversityPackage.CLASS__PHONE:
			return PHONE_EDEFAULT == null ? phone != null : !PHONE_EDEFAULT.equals(phone);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (id: ");
		result.append(id);
		result.append(", name: ");
		result.append(name);
		result.append(", phone: ");
		result.append(phone);
		result.append(')');
		return result.toString();
	}

} //ClassImpl
