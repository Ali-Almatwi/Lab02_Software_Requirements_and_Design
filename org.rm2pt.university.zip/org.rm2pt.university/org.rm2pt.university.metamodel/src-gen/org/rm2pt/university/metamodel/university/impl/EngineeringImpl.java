/**
 */
package org.rm2pt.university.metamodel.university.impl;

import org.eclipse.emf.ecore.EClass;
import org.rm2pt.university.metamodel.university.Engineering;
import org.rm2pt.university.metamodel.university.UniversityPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Engineering</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EngineeringImpl extends ClassImpl implements Engineering {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EngineeringImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UniversityPackage.Literals.ENGINEERING;
	}

} //EngineeringImpl
