/**
 */
package org.rm2pt.university.metamodel.university;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>IT</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getIT()
 * @model
 * @generated
 */
public interface IT extends org.rm2pt.university.metamodel.university.Class {

} // IT
