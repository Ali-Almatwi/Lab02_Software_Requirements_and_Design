/**
 */
package org.rm2pt.university.metamodel.university;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Computer science</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getComputer_science()
 * @model
 * @generated
 */
public interface Computer_science extends org.rm2pt.university.metamodel.university.Class {

} // Computer_science
