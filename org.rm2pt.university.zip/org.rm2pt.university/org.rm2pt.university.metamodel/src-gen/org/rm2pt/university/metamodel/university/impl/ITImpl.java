/**
 */
package org.rm2pt.university.metamodel.university.impl;

import org.eclipse.emf.ecore.EClass;
import org.rm2pt.university.metamodel.university.IT;
import org.rm2pt.university.metamodel.university.UniversityPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>IT</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ITImpl extends ClassImpl implements IT {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ITImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UniversityPackage.Literals.IT;
	}

} //ITImpl
