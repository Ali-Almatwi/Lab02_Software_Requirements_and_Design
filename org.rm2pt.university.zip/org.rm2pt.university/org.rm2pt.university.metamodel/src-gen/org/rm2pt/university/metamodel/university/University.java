/**
 */
package org.rm2pt.university.metamodel.university;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>University</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.university.metamodel.university.University#getUniversity_name <em>University name</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.University#getClasses <em>Classes</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getUniversity()
 * @model
 * @generated
 */
public interface University extends EObject {
	/**
	 * Returns the value of the '<em><b>University name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>University name</em>' attribute.
	 * @see #setUniversity_name(String)
	 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getUniversity_University_name()
	 * @model
	 * @generated
	 */
	String getUniversity_name();

	/**
	 * Sets the value of the '{@link org.rm2pt.university.metamodel.university.University#getUniversity_name <em>University name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>University name</em>' attribute.
	 * @see #getUniversity_name()
	 * @generated
	 */
	void setUniversity_name(String value);

	/**
	 * Returns the value of the '<em><b>Classes</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.university.metamodel.university.Class}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Classes</em>' containment reference list.
	 * @see org.rm2pt.university.metamodel.university.UniversityPackage#getUniversity_Classes()
	 * @model containment="true"
	 * @generated
	 */
	EList<org.rm2pt.university.metamodel.university.Class> getClasses();

} // University
