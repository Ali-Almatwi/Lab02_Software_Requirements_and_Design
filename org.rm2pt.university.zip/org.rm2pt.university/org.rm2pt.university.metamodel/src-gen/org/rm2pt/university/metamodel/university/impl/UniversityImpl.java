/**
 */
package org.rm2pt.university.metamodel.university.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.rm2pt.university.metamodel.university.University;
import org.rm2pt.university.metamodel.university.UniversityPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>University</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.university.metamodel.university.impl.UniversityImpl#getUniversity_name <em>University name</em>}</li>
 *   <li>{@link org.rm2pt.university.metamodel.university.impl.UniversityImpl#getClasses <em>Classes</em>}</li>
 * </ul>
 *
 * @generated
 */
public class UniversityImpl extends MinimalEObjectImpl.Container implements University {
	/**
	 * The default value of the '{@link #getUniversity_name() <em>University name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUniversity_name()
	 * @generated
	 * @ordered
	 */
	protected static final String UNIVERSITY_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUniversity_name() <em>University name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUniversity_name()
	 * @generated
	 * @ordered
	 */
	protected String university_name = UNIVERSITY_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getClasses() <em>Classes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClasses()
	 * @generated
	 * @ordered
	 */
	protected EList<org.rm2pt.university.metamodel.university.Class> classes;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UniversityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return UniversityPackage.Literals.UNIVERSITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUniversity_name() {
		return university_name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUniversity_name(String newUniversity_name) {
		String oldUniversity_name = university_name;
		university_name = newUniversity_name;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, UniversityPackage.UNIVERSITY__UNIVERSITY_NAME,
					oldUniversity_name, university_name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<org.rm2pt.university.metamodel.university.Class> getClasses() {
		if (classes == null) {
			classes = new EObjectContainmentEList<org.rm2pt.university.metamodel.university.Class>(
					org.rm2pt.university.metamodel.university.Class.class, this, UniversityPackage.UNIVERSITY__CLASSES);
		}
		return classes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case UniversityPackage.UNIVERSITY__CLASSES:
			return ((InternalEList<?>) getClasses()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case UniversityPackage.UNIVERSITY__UNIVERSITY_NAME:
			return getUniversity_name();
		case UniversityPackage.UNIVERSITY__CLASSES:
			return getClasses();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case UniversityPackage.UNIVERSITY__UNIVERSITY_NAME:
			setUniversity_name((String) newValue);
			return;
		case UniversityPackage.UNIVERSITY__CLASSES:
			getClasses().clear();
			getClasses().addAll((Collection<? extends org.rm2pt.university.metamodel.university.Class>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case UniversityPackage.UNIVERSITY__UNIVERSITY_NAME:
			setUniversity_name(UNIVERSITY_NAME_EDEFAULT);
			return;
		case UniversityPackage.UNIVERSITY__CLASSES:
			getClasses().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case UniversityPackage.UNIVERSITY__UNIVERSITY_NAME:
			return UNIVERSITY_NAME_EDEFAULT == null ? university_name != null
					: !UNIVERSITY_NAME_EDEFAULT.equals(university_name);
		case UniversityPackage.UNIVERSITY__CLASSES:
			return classes != null && !classes.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (university_name: ");
		result.append(university_name);
		result.append(')');
		return result.toString();
	}

} //UniversityImpl
