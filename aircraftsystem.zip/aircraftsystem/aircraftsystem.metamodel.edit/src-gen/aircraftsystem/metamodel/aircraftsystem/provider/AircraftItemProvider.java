/**
 */
package aircraftsystem.metamodel.aircraftsystem.provider;

import aircraftsystem.metamodel.aircraftsystem.Aircraft;
import aircraftsystem.metamodel.aircraftsystem.AircraftsystemFactory;
import aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link aircraftsystem.metamodel.aircraftsystem.Aircraft} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class AircraftItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AircraftItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addModelPropertyDescriptor(object);
			addMaxSeedPropertyDescriptor(object);
			addRangePropertyDescriptor(object);
			addSeatingCategoryPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Model feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addModelPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Aircraft_model_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Aircraft_model_feature",
								"_UI_Aircraft_type"),
						AircraftsystemPackage.Literals.AIRCRAFT__MODEL, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Max Seed feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addMaxSeedPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Aircraft_maxSeed_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Aircraft_maxSeed_feature",
								"_UI_Aircraft_type"),
						AircraftsystemPackage.Literals.AIRCRAFT__MAX_SEED, true, false, false,
						ItemPropertyDescriptor.REAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Range feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addRangePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Aircraft_range_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Aircraft_range_feature",
								"_UI_Aircraft_type"),
						AircraftsystemPackage.Literals.AIRCRAFT__RANGE, true, false, false,
						ItemPropertyDescriptor.REAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Seating Category feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSeatingCategoryPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Aircraft_seatingCategory_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Aircraft_seatingCategory_feature",
								"_UI_Aircraft_type"),
						AircraftsystemPackage.Literals.AIRCRAFT__SEATING_CATEGORY, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(AircraftsystemPackage.Literals.AIRCRAFT__WING);
			childrenFeatures.add(AircraftsystemPackage.Literals.AIRCRAFT__FUSELAGE);
			childrenFeatures.add(AircraftsystemPackage.Literals.AIRCRAFT__ENGINE);
			childrenFeatures.add(AircraftsystemPackage.Literals.AIRCRAFT__AVIONICS);
			childrenFeatures.add(AircraftsystemPackage.Literals.AIRCRAFT__CONTROLSURFACES);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns Aircraft.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Aircraft"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Aircraft) object).getModel();
		return label == null || label.length() == 0 ? getString("_UI_Aircraft_type")
				: getString("_UI_Aircraft_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Aircraft.class)) {
		case AircraftsystemPackage.AIRCRAFT__MODEL:
		case AircraftsystemPackage.AIRCRAFT__MAX_SEED:
		case AircraftsystemPackage.AIRCRAFT__RANGE:
		case AircraftsystemPackage.AIRCRAFT__SEATING_CATEGORY:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case AircraftsystemPackage.AIRCRAFT__WING:
		case AircraftsystemPackage.AIRCRAFT__FUSELAGE:
		case AircraftsystemPackage.AIRCRAFT__ENGINE:
		case AircraftsystemPackage.AIRCRAFT__AVIONICS:
		case AircraftsystemPackage.AIRCRAFT__CONTROLSURFACES:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(AircraftsystemPackage.Literals.AIRCRAFT__WING,
				AircraftsystemFactory.eINSTANCE.createWing()));

		newChildDescriptors.add(createChildParameter(AircraftsystemPackage.Literals.AIRCRAFT__FUSELAGE,
				AircraftsystemFactory.eINSTANCE.createFuselage()));

		newChildDescriptors.add(createChildParameter(AircraftsystemPackage.Literals.AIRCRAFT__ENGINE,
				AircraftsystemFactory.eINSTANCE.createEngine()));

		newChildDescriptors.add(createChildParameter(AircraftsystemPackage.Literals.AIRCRAFT__AVIONICS,
				AircraftsystemFactory.eINSTANCE.createAvionics()));

		newChildDescriptors.add(createChildParameter(AircraftsystemPackage.Literals.AIRCRAFT__CONTROLSURFACES,
				AircraftsystemFactory.eINSTANCE.createControlSurfaces()));
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return AircraftsystemEditPlugin.INSTANCE;
	}

}
