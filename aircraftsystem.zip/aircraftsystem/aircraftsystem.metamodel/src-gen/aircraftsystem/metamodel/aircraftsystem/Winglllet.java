/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Winglllet</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Winglllet#getHeight <em>Height</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Winglllet#getAngle <em>Angle</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getWinglllet()
 * @model
 * @generated
 */
public interface Winglllet extends EObject {
	/**
	 * Returns the value of the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Height</em>' attribute.
	 * @see #setHeight(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getWinglllet_Height()
	 * @model
	 * @generated
	 */
	double getHeight();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Winglllet#getHeight <em>Height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Height</em>' attribute.
	 * @see #getHeight()
	 * @generated
	 */
	void setHeight(double value);

	/**
	 * Returns the value of the '<em><b>Angle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Angle</em>' attribute.
	 * @see #setAngle(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getWinglllet_Angle()
	 * @model
	 * @generated
	 */
	double getAngle();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Winglllet#getAngle <em>Angle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Angle</em>' attribute.
	 * @see #getAngle()
	 * @generated
	 */
	void setAngle(double value);

} // Winglllet
