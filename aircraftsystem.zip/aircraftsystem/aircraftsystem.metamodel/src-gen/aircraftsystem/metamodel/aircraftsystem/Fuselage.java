/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fuselage</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Fuselage#getLength <em>Length</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Fuselage#getDiameter <em>Diameter</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Fuselage#getMaterial <em>Material</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getFuselage()
 * @model
 * @generated
 */
public interface Fuselage extends EObject {
	/**
	 * Returns the value of the '<em><b>Length</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Length</em>' attribute.
	 * @see #setLength(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getFuselage_Length()
	 * @model
	 * @generated
	 */
	double getLength();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Fuselage#getLength <em>Length</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Length</em>' attribute.
	 * @see #getLength()
	 * @generated
	 */
	void setLength(double value);

	/**
	 * Returns the value of the '<em><b>Diameter</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Diameter</em>' attribute.
	 * @see #setDiameter(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getFuselage_Diameter()
	 * @model
	 * @generated
	 */
	double getDiameter();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Fuselage#getDiameter <em>Diameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Diameter</em>' attribute.
	 * @see #getDiameter()
	 * @generated
	 */
	void setDiameter(double value);

	/**
	 * Returns the value of the '<em><b>Material</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Material</em>' attribute.
	 * @see #setMaterial(String)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getFuselage_Material()
	 * @model
	 * @generated
	 */
	String getMaterial();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Fuselage#getMaterial <em>Material</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Material</em>' attribute.
	 * @see #getMaterial()
	 * @generated
	 */
	void setMaterial(String value);

} // Fuselage
