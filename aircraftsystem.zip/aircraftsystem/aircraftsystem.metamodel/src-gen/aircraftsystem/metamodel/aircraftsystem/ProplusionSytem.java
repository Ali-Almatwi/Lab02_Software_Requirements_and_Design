/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Proplusion Sytem</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.ProplusionSytem#getFuelType <em>Fuel Type</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.ProplusionSytem#getEfficiency <em>Efficiency</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getProplusionSytem()
 * @model
 * @generated
 */
public interface ProplusionSytem extends EObject {
	/**
	 * Returns the value of the '<em><b>Fuel Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fuel Type</em>' attribute.
	 * @see #setFuelType(String)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getProplusionSytem_FuelType()
	 * @model
	 * @generated
	 */
	String getFuelType();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.ProplusionSytem#getFuelType <em>Fuel Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fuel Type</em>' attribute.
	 * @see #getFuelType()
	 * @generated
	 */
	void setFuelType(String value);

	/**
	 * Returns the value of the '<em><b>Efficiency</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Efficiency</em>' attribute.
	 * @see #setEfficiency(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getProplusionSytem_Efficiency()
	 * @model
	 * @generated
	 */
	double getEfficiency();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.ProplusionSytem#getEfficiency <em>Efficiency</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Efficiency</em>' attribute.
	 * @see #getEfficiency()
	 * @generated
	 */
	void setEfficiency(double value);

} // ProplusionSytem
