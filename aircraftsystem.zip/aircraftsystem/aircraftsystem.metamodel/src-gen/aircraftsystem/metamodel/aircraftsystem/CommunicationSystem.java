/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Communication System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.CommunicationSystem#getFrequencyRange <em>Frequency Range</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.CommunicationSystem#getTechnology <em>Technology</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getCommunicationSystem()
 * @model
 * @generated
 */
public interface CommunicationSystem extends EObject {
	/**
	 * Returns the value of the '<em><b>Frequency Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Frequency Range</em>' attribute.
	 * @see #setFrequencyRange(String)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getCommunicationSystem_FrequencyRange()
	 * @model
	 * @generated
	 */
	String getFrequencyRange();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.CommunicationSystem#getFrequencyRange <em>Frequency Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Frequency Range</em>' attribute.
	 * @see #getFrequencyRange()
	 * @generated
	 */
	void setFrequencyRange(String value);

	/**
	 * Returns the value of the '<em><b>Technology</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Technology</em>' attribute.
	 * @see #setTechnology(String)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getCommunicationSystem_Technology()
	 * @model
	 * @generated
	 */
	String getTechnology();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.CommunicationSystem#getTechnology <em>Technology</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Technology</em>' attribute.
	 * @see #getTechnology()
	 * @generated
	 */
	void setTechnology(String value);

} // CommunicationSystem
