/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage
 * @generated
 */
public interface AircraftsystemFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	AircraftsystemFactory eINSTANCE = aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Aircraft</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Aircraft</em>'.
	 * @generated
	 */
	Aircraft createAircraft();

	/**
	 * Returns a new object of class '<em>Wing</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Wing</em>'.
	 * @generated
	 */
	Wing createWing();

	/**
	 * Returns a new object of class '<em>Fuselage</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fuselage</em>'.
	 * @generated
	 */
	Fuselage createFuselage();

	/**
	 * Returns a new object of class '<em>Engine</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Engine</em>'.
	 * @generated
	 */
	Engine createEngine();

	/**
	 * Returns a new object of class '<em>Avionics</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Avionics</em>'.
	 * @generated
	 */
	Avionics createAvionics();

	/**
	 * Returns a new object of class '<em>Winglet</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Winglet</em>'.
	 * @generated
	 */
	Winglet createWinglet();

	/**
	 * Returns a new object of class '<em>Proplusion Sytem</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Proplusion Sytem</em>'.
	 * @generated
	 */
	ProplusionSytem createProplusionSytem();

	/**
	 * Returns a new object of class '<em>Communication System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Communication System</em>'.
	 * @generated
	 */
	CommunicationSystem createCommunicationSystem();

	/**
	 * Returns a new object of class '<em>Control Surfaces</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Control Surfaces</em>'.
	 * @generated
	 */
	ControlSurfaces createControlSurfaces();

	/**
	 * Returns a new object of class '<em>Rudder</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Rudder</em>'.
	 * @generated
	 */
	Rudder createRudder();

	/**
	 * Returns a new object of class '<em>Elevator</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Elevator</em>'.
	 * @generated
	 */
	Elevator createElevator();

	/**
	 * Returns a new object of class '<em>Ailleron</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Ailleron</em>'.
	 * @generated
	 */
	Ailleron createAilleron();

	/**
	 * Returns a new object of class '<em>Navigation System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Navigation System</em>'.
	 * @generated
	 */
	NavigationSystem createNavigationSystem();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	AircraftsystemPackage getAircraftsystemPackage();

} //AircraftsystemFactory
