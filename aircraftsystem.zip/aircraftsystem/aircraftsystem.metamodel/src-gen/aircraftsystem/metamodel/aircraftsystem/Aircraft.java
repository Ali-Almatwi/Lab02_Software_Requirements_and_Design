/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Aircraft</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getModel <em>Model</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getMaxSeed <em>Max Seed</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getWing <em>Wing</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getFuselage <em>Fuselage</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getEngine <em>Engine</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getAvionics <em>Avionics</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getControlsurfaces <em>Controlsurfaces</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getRange <em>Range</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getSeatingCategory <em>Seating Category</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAircraft()
 * @model
 * @generated
 */
public interface Aircraft extends EObject {
	/**
	 * Returns the value of the '<em><b>Model</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model</em>' attribute.
	 * @see #setModel(String)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAircraft_Model()
	 * @model
	 * @generated
	 */
	String getModel();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getModel <em>Model</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Model</em>' attribute.
	 * @see #getModel()
	 * @generated
	 */
	void setModel(String value);

	/**
	 * Returns the value of the '<em><b>Max Seed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Seed</em>' attribute.
	 * @see #setMaxSeed(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAircraft_MaxSeed()
	 * @model
	 * @generated
	 */
	double getMaxSeed();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getMaxSeed <em>Max Seed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Seed</em>' attribute.
	 * @see #getMaxSeed()
	 * @generated
	 */
	void setMaxSeed(double value);

	/**
	 * Returns the value of the '<em><b>Wing</b></em>' containment reference list.
	 * The list contents are of type {@link aircraftsystem.metamodel.aircraftsystem.Wing}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Wing</em>' containment reference list.
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAircraft_Wing()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Wing> getWing();

	/**
	 * Returns the value of the '<em><b>Fuselage</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fuselage</em>' containment reference.
	 * @see #setFuselage(Fuselage)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAircraft_Fuselage()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Fuselage getFuselage();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getFuselage <em>Fuselage</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fuselage</em>' containment reference.
	 * @see #getFuselage()
	 * @generated
	 */
	void setFuselage(Fuselage value);

	/**
	 * Returns the value of the '<em><b>Engine</b></em>' containment reference list.
	 * The list contents are of type {@link aircraftsystem.metamodel.aircraftsystem.Engine}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Engine</em>' containment reference list.
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAircraft_Engine()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Engine> getEngine();

	/**
	 * Returns the value of the '<em><b>Avionics</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Avionics</em>' containment reference.
	 * @see #setAvionics(Avionics)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAircraft_Avionics()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Avionics getAvionics();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getAvionics <em>Avionics</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Avionics</em>' containment reference.
	 * @see #getAvionics()
	 * @generated
	 */
	void setAvionics(Avionics value);

	/**
	 * Returns the value of the '<em><b>Controlsurfaces</b></em>' containment reference list.
	 * The list contents are of type {@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controlsurfaces</em>' containment reference list.
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAircraft_Controlsurfaces()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<ControlSurfaces> getControlsurfaces();

	/**
	 * Returns the value of the '<em><b>Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Range</em>' attribute.
	 * @see #setRange(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAircraft_Range()
	 * @model
	 * @generated
	 */
	double getRange();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getRange <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Range</em>' attribute.
	 * @see #getRange()
	 * @generated
	 */
	void setRange(double value);

	/**
	 * Returns the value of the '<em><b>Seating Category</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Seating Category</em>' attribute.
	 * @see #setSeatingCategory(int)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAircraft_SeatingCategory()
	 * @model
	 * @generated
	 */
	int getSeatingCategory();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getSeatingCategory <em>Seating Category</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Seating Category</em>' attribute.
	 * @see #getSeatingCategory()
	 * @generated
	 */
	void setSeatingCategory(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void calculatePerformanceMetrics();

} // Aircraft
