/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Control Surfaces</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getType <em>Type</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getArea <em>Area</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getRudder <em>Rudder</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getAilleron <em>Ailleron</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getElevator <em>Elevator</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getControlSurfaces()
 * @model
 * @generated
 */
public interface ControlSurfaces extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getControlSurfaces_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Area</em>' attribute.
	 * @see #setArea(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getControlSurfaces_Area()
	 * @model
	 * @generated
	 */
	double getArea();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getArea <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Area</em>' attribute.
	 * @see #getArea()
	 * @generated
	 */
	void setArea(double value);

	/**
	 * Returns the value of the '<em><b>Rudder</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rudder</em>' containment reference.
	 * @see #setRudder(Rudder)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getControlSurfaces_Rudder()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Rudder getRudder();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getRudder <em>Rudder</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rudder</em>' containment reference.
	 * @see #getRudder()
	 * @generated
	 */
	void setRudder(Rudder value);

	/**
	 * Returns the value of the '<em><b>Ailleron</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ailleron</em>' containment reference.
	 * @see #setAilleron(Ailleron)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getControlSurfaces_Ailleron()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Ailleron getAilleron();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getAilleron <em>Ailleron</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ailleron</em>' containment reference.
	 * @see #getAilleron()
	 * @generated
	 */
	void setAilleron(Ailleron value);

	/**
	 * Returns the value of the '<em><b>Elevator</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elevator</em>' containment reference.
	 * @see #setElevator(Elevator)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getControlSurfaces_Elevator()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Elevator getElevator();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getElevator <em>Elevator</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Elevator</em>' containment reference.
	 * @see #getElevator()
	 * @generated
	 */
	void setElevator(Elevator value);

} // ControlSurfaces
