/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Engine</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Engine#getEngineType <em>Engine Type</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Engine#getThrust <em>Thrust</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Engine#getFuelConsumption <em>Fuel Consumption</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Engine#getProplusionsytem <em>Proplusionsytem</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getEngine()
 * @model
 * @generated
 */
public interface Engine extends EObject {
	/**
	 * Returns the value of the '<em><b>Engine Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Engine Type</em>' attribute.
	 * @see #setEngineType(String)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getEngine_EngineType()
	 * @model
	 * @generated
	 */
	String getEngineType();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Engine#getEngineType <em>Engine Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Engine Type</em>' attribute.
	 * @see #getEngineType()
	 * @generated
	 */
	void setEngineType(String value);

	/**
	 * Returns the value of the '<em><b>Thrust</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Thrust</em>' attribute.
	 * @see #setThrust(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getEngine_Thrust()
	 * @model
	 * @generated
	 */
	double getThrust();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Engine#getThrust <em>Thrust</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Thrust</em>' attribute.
	 * @see #getThrust()
	 * @generated
	 */
	void setThrust(double value);

	/**
	 * Returns the value of the '<em><b>Fuel Consumption</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fuel Consumption</em>' attribute.
	 * @see #setFuelConsumption(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getEngine_FuelConsumption()
	 * @model
	 * @generated
	 */
	double getFuelConsumption();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Engine#getFuelConsumption <em>Fuel Consumption</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fuel Consumption</em>' attribute.
	 * @see #getFuelConsumption()
	 * @generated
	 */
	void setFuelConsumption(double value);

	/**
	 * Returns the value of the '<em><b>Proplusionsytem</b></em>' containment reference list.
	 * The list contents are of type {@link aircraftsystem.metamodel.aircraftsystem.ProplusionSytem}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Proplusionsytem</em>' containment reference list.
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getEngine_Proplusionsytem()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<ProplusionSytem> getProplusionsytem();

} // Engine
