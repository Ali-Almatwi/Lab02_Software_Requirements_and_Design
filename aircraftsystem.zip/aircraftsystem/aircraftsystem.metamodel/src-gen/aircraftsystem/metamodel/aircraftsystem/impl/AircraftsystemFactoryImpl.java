/**
 */
package aircraftsystem.metamodel.aircraftsystem.impl;

import aircraftsystem.metamodel.aircraftsystem.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class AircraftsystemFactoryImpl extends EFactoryImpl implements AircraftsystemFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static AircraftsystemFactory init() {
		try {
			AircraftsystemFactory theAircraftsystemFactory = (AircraftsystemFactory) EPackage.Registry.INSTANCE
					.getEFactory(AircraftsystemPackage.eNS_URI);
			if (theAircraftsystemFactory != null) {
				return theAircraftsystemFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new AircraftsystemFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AircraftsystemFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case AircraftsystemPackage.AIRCRAFT:
			return createAircraft();
		case AircraftsystemPackage.WING:
			return createWing();
		case AircraftsystemPackage.FUSELAGE:
			return createFuselage();
		case AircraftsystemPackage.ENGINE:
			return createEngine();
		case AircraftsystemPackage.AVIONICS:
			return createAvionics();
		case AircraftsystemPackage.WINGLET:
			return createWinglet();
		case AircraftsystemPackage.PROPLUSION_SYTEM:
			return createProplusionSytem();
		case AircraftsystemPackage.COMMUNICATION_SYSTEM:
			return createCommunicationSystem();
		case AircraftsystemPackage.CONTROL_SURFACES:
			return createControlSurfaces();
		case AircraftsystemPackage.RUDDER:
			return createRudder();
		case AircraftsystemPackage.ELEVATOR:
			return createElevator();
		case AircraftsystemPackage.AILLERON:
			return createAilleron();
		case AircraftsystemPackage.NAVIGATION_SYSTEM:
			return createNavigationSystem();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Aircraft createAircraft() {
		AircraftImpl aircraft = new AircraftImpl();
		return aircraft;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Wing createWing() {
		WingImpl wing = new WingImpl();
		return wing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fuselage createFuselage() {
		FuselageImpl fuselage = new FuselageImpl();
		return fuselage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Engine createEngine() {
		EngineImpl engine = new EngineImpl();
		return engine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Avionics createAvionics() {
		AvionicsImpl avionics = new AvionicsImpl();
		return avionics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Winglet createWinglet() {
		WingletImpl winglet = new WingletImpl();
		return winglet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProplusionSytem createProplusionSytem() {
		ProplusionSytemImpl proplusionSytem = new ProplusionSytemImpl();
		return proplusionSytem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommunicationSystem createCommunicationSystem() {
		CommunicationSystemImpl communicationSystem = new CommunicationSystemImpl();
		return communicationSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ControlSurfaces createControlSurfaces() {
		ControlSurfacesImpl controlSurfaces = new ControlSurfacesImpl();
		return controlSurfaces;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Rudder createRudder() {
		RudderImpl rudder = new RudderImpl();
		return rudder;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Elevator createElevator() {
		ElevatorImpl elevator = new ElevatorImpl();
		return elevator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ailleron createAilleron() {
		AilleronImpl ailleron = new AilleronImpl();
		return ailleron;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NavigationSystem createNavigationSystem() {
		NavigationSystemImpl navigationSystem = new NavigationSystemImpl();
		return navigationSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AircraftsystemPackage getAircraftsystemPackage() {
		return (AircraftsystemPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static AircraftsystemPackage getPackage() {
		return AircraftsystemPackage.eINSTANCE;
	}

} //AircraftsystemFactoryImpl
