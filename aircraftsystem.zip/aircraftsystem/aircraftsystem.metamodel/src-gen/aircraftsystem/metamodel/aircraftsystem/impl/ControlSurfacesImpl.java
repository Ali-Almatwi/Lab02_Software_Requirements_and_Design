/**
 */
package aircraftsystem.metamodel.aircraftsystem.impl;

import aircraftsystem.metamodel.aircraftsystem.Ailleron;
import aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage;
import aircraftsystem.metamodel.aircraftsystem.ControlSurfaces;
import aircraftsystem.metamodel.aircraftsystem.Elevator;
import aircraftsystem.metamodel.aircraftsystem.Rudder;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Control Surfaces</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.ControlSurfacesImpl#getType <em>Type</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.ControlSurfacesImpl#getArea <em>Area</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.ControlSurfacesImpl#getRudder <em>Rudder</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.ControlSurfacesImpl#getAilleron <em>Ailleron</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.ControlSurfacesImpl#getElevator <em>Elevator</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ControlSurfacesImpl extends MinimalEObjectImpl.Container implements ControlSurfaces {
	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getArea() <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArea()
	 * @generated
	 * @ordered
	 */
	protected static final double AREA_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getArea() <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArea()
	 * @generated
	 * @ordered
	 */
	protected double area = AREA_EDEFAULT;

	/**
	 * The cached value of the '{@link #getRudder() <em>Rudder</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRudder()
	 * @generated
	 * @ordered
	 */
	protected Rudder rudder;

	/**
	 * The cached value of the '{@link #getAilleron() <em>Ailleron</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAilleron()
	 * @generated
	 * @ordered
	 */
	protected Ailleron ailleron;

	/**
	 * The cached value of the '{@link #getElevator() <em>Elevator</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElevator()
	 * @generated
	 * @ordered
	 */
	protected Elevator elevator;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ControlSurfacesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AircraftsystemPackage.Literals.CONTROL_SURFACES;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.CONTROL_SURFACES__TYPE, oldType,
					type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getArea() {
		return area;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArea(double newArea) {
		double oldArea = area;
		area = newArea;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.CONTROL_SURFACES__AREA, oldArea,
					area));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Rudder getRudder() {
		return rudder;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRudder(Rudder newRudder, NotificationChain msgs) {
		Rudder oldRudder = rudder;
		rudder = newRudder;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					AircraftsystemPackage.CONTROL_SURFACES__RUDDER, oldRudder, newRudder);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRudder(Rudder newRudder) {
		if (newRudder != rudder) {
			NotificationChain msgs = null;
			if (rudder != null)
				msgs = ((InternalEObject) rudder).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.CONTROL_SURFACES__RUDDER, null, msgs);
			if (newRudder != null)
				msgs = ((InternalEObject) newRudder).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.CONTROL_SURFACES__RUDDER, null, msgs);
			msgs = basicSetRudder(newRudder, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.CONTROL_SURFACES__RUDDER,
					newRudder, newRudder));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ailleron getAilleron() {
		return ailleron;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAilleron(Ailleron newAilleron, NotificationChain msgs) {
		Ailleron oldAilleron = ailleron;
		ailleron = newAilleron;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					AircraftsystemPackage.CONTROL_SURFACES__AILLERON, oldAilleron, newAilleron);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAilleron(Ailleron newAilleron) {
		if (newAilleron != ailleron) {
			NotificationChain msgs = null;
			if (ailleron != null)
				msgs = ((InternalEObject) ailleron).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.CONTROL_SURFACES__AILLERON, null, msgs);
			if (newAilleron != null)
				msgs = ((InternalEObject) newAilleron).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.CONTROL_SURFACES__AILLERON, null, msgs);
			msgs = basicSetAilleron(newAilleron, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.CONTROL_SURFACES__AILLERON,
					newAilleron, newAilleron));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Elevator getElevator() {
		return elevator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetElevator(Elevator newElevator, NotificationChain msgs) {
		Elevator oldElevator = elevator;
		elevator = newElevator;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					AircraftsystemPackage.CONTROL_SURFACES__ELEVATOR, oldElevator, newElevator);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setElevator(Elevator newElevator) {
		if (newElevator != elevator) {
			NotificationChain msgs = null;
			if (elevator != null)
				msgs = ((InternalEObject) elevator).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.CONTROL_SURFACES__ELEVATOR, null, msgs);
			if (newElevator != null)
				msgs = ((InternalEObject) newElevator).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.CONTROL_SURFACES__ELEVATOR, null, msgs);
			msgs = basicSetElevator(newElevator, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.CONTROL_SURFACES__ELEVATOR,
					newElevator, newElevator));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AircraftsystemPackage.CONTROL_SURFACES__RUDDER:
			return basicSetRudder(null, msgs);
		case AircraftsystemPackage.CONTROL_SURFACES__AILLERON:
			return basicSetAilleron(null, msgs);
		case AircraftsystemPackage.CONTROL_SURFACES__ELEVATOR:
			return basicSetElevator(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AircraftsystemPackage.CONTROL_SURFACES__TYPE:
			return getType();
		case AircraftsystemPackage.CONTROL_SURFACES__AREA:
			return getArea();
		case AircraftsystemPackage.CONTROL_SURFACES__RUDDER:
			return getRudder();
		case AircraftsystemPackage.CONTROL_SURFACES__AILLERON:
			return getAilleron();
		case AircraftsystemPackage.CONTROL_SURFACES__ELEVATOR:
			return getElevator();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AircraftsystemPackage.CONTROL_SURFACES__TYPE:
			setType((String) newValue);
			return;
		case AircraftsystemPackage.CONTROL_SURFACES__AREA:
			setArea((Double) newValue);
			return;
		case AircraftsystemPackage.CONTROL_SURFACES__RUDDER:
			setRudder((Rudder) newValue);
			return;
		case AircraftsystemPackage.CONTROL_SURFACES__AILLERON:
			setAilleron((Ailleron) newValue);
			return;
		case AircraftsystemPackage.CONTROL_SURFACES__ELEVATOR:
			setElevator((Elevator) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.CONTROL_SURFACES__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case AircraftsystemPackage.CONTROL_SURFACES__AREA:
			setArea(AREA_EDEFAULT);
			return;
		case AircraftsystemPackage.CONTROL_SURFACES__RUDDER:
			setRudder((Rudder) null);
			return;
		case AircraftsystemPackage.CONTROL_SURFACES__AILLERON:
			setAilleron((Ailleron) null);
			return;
		case AircraftsystemPackage.CONTROL_SURFACES__ELEVATOR:
			setElevator((Elevator) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.CONTROL_SURFACES__TYPE:
			return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		case AircraftsystemPackage.CONTROL_SURFACES__AREA:
			return area != AREA_EDEFAULT;
		case AircraftsystemPackage.CONTROL_SURFACES__RUDDER:
			return rudder != null;
		case AircraftsystemPackage.CONTROL_SURFACES__AILLERON:
			return ailleron != null;
		case AircraftsystemPackage.CONTROL_SURFACES__ELEVATOR:
			return elevator != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(", area: ");
		result.append(area);
		result.append(')');
		return result.toString();
	}

} //ControlSurfacesImpl
