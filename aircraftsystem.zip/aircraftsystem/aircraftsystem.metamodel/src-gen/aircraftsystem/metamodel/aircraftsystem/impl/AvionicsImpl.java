/**
 */
package aircraftsystem.metamodel.aircraftsystem.impl;

import aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage;
import aircraftsystem.metamodel.aircraftsystem.Avionics;
import aircraftsystem.metamodel.aircraftsystem.CommunicationSystem;
import aircraftsystem.metamodel.aircraftsystem.NavigationSystem;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Avionics</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AvionicsImpl#getCommunicationsystem <em>Communicationsystem</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AvionicsImpl#getManufacturer <em>Manufacturer</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AvionicsImpl#getModel <em>Model</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AvionicsImpl#getNavigationsystem <em>Navigationsystem</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AvionicsImpl extends MinimalEObjectImpl.Container implements Avionics {
	/**
	 * The cached value of the '{@link #getCommunicationsystem() <em>Communicationsystem</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommunicationsystem()
	 * @generated
	 * @ordered
	 */
	protected CommunicationSystem communicationsystem;

	/**
	 * The default value of the '{@link #getManufacturer() <em>Manufacturer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManufacturer()
	 * @generated
	 * @ordered
	 */
	protected static final String MANUFACTURER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getManufacturer() <em>Manufacturer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManufacturer()
	 * @generated
	 * @ordered
	 */
	protected String manufacturer = MANUFACTURER_EDEFAULT;

	/**
	 * The default value of the '{@link #getModel() <em>Model</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModel()
	 * @generated
	 * @ordered
	 */
	protected static final String MODEL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getModel() <em>Model</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModel()
	 * @generated
	 * @ordered
	 */
	protected String model = MODEL_EDEFAULT;

	/**
	 * The cached value of the '{@link #getNavigationsystem() <em>Navigationsystem</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNavigationsystem()
	 * @generated
	 * @ordered
	 */
	protected NavigationSystem navigationsystem;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AvionicsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AircraftsystemPackage.Literals.AVIONICS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommunicationSystem getCommunicationsystem() {
		return communicationsystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCommunicationsystem(CommunicationSystem newCommunicationsystem,
			NotificationChain msgs) {
		CommunicationSystem oldCommunicationsystem = communicationsystem;
		communicationsystem = newCommunicationsystem;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					AircraftsystemPackage.AVIONICS__COMMUNICATIONSYSTEM, oldCommunicationsystem,
					newCommunicationsystem);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCommunicationsystem(CommunicationSystem newCommunicationsystem) {
		if (newCommunicationsystem != communicationsystem) {
			NotificationChain msgs = null;
			if (communicationsystem != null)
				msgs = ((InternalEObject) communicationsystem).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.AVIONICS__COMMUNICATIONSYSTEM, null, msgs);
			if (newCommunicationsystem != null)
				msgs = ((InternalEObject) newCommunicationsystem).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.AVIONICS__COMMUNICATIONSYSTEM, null, msgs);
			msgs = basicSetCommunicationsystem(newCommunicationsystem, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.AVIONICS__COMMUNICATIONSYSTEM,
					newCommunicationsystem, newCommunicationsystem));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getManufacturer() {
		return manufacturer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setManufacturer(String newManufacturer) {
		String oldManufacturer = manufacturer;
		manufacturer = newManufacturer;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.AVIONICS__MANUFACTURER,
					oldManufacturer, manufacturer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getModel() {
		return model;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setModel(String newModel) {
		String oldModel = model;
		model = newModel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.AVIONICS__MODEL, oldModel,
					model));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NavigationSystem getNavigationsystem() {
		return navigationsystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetNavigationsystem(NavigationSystem newNavigationsystem, NotificationChain msgs) {
		NavigationSystem oldNavigationsystem = navigationsystem;
		navigationsystem = newNavigationsystem;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					AircraftsystemPackage.AVIONICS__NAVIGATIONSYSTEM, oldNavigationsystem, newNavigationsystem);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNavigationsystem(NavigationSystem newNavigationsystem) {
		if (newNavigationsystem != navigationsystem) {
			NotificationChain msgs = null;
			if (navigationsystem != null)
				msgs = ((InternalEObject) navigationsystem).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.AVIONICS__NAVIGATIONSYSTEM, null, msgs);
			if (newNavigationsystem != null)
				msgs = ((InternalEObject) newNavigationsystem).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.AVIONICS__NAVIGATIONSYSTEM, null, msgs);
			msgs = basicSetNavigationsystem(newNavigationsystem, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.AVIONICS__NAVIGATIONSYSTEM,
					newNavigationsystem, newNavigationsystem));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AircraftsystemPackage.AVIONICS__COMMUNICATIONSYSTEM:
			return basicSetCommunicationsystem(null, msgs);
		case AircraftsystemPackage.AVIONICS__NAVIGATIONSYSTEM:
			return basicSetNavigationsystem(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AircraftsystemPackage.AVIONICS__COMMUNICATIONSYSTEM:
			return getCommunicationsystem();
		case AircraftsystemPackage.AVIONICS__MANUFACTURER:
			return getManufacturer();
		case AircraftsystemPackage.AVIONICS__MODEL:
			return getModel();
		case AircraftsystemPackage.AVIONICS__NAVIGATIONSYSTEM:
			return getNavigationsystem();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AircraftsystemPackage.AVIONICS__COMMUNICATIONSYSTEM:
			setCommunicationsystem((CommunicationSystem) newValue);
			return;
		case AircraftsystemPackage.AVIONICS__MANUFACTURER:
			setManufacturer((String) newValue);
			return;
		case AircraftsystemPackage.AVIONICS__MODEL:
			setModel((String) newValue);
			return;
		case AircraftsystemPackage.AVIONICS__NAVIGATIONSYSTEM:
			setNavigationsystem((NavigationSystem) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.AVIONICS__COMMUNICATIONSYSTEM:
			setCommunicationsystem((CommunicationSystem) null);
			return;
		case AircraftsystemPackage.AVIONICS__MANUFACTURER:
			setManufacturer(MANUFACTURER_EDEFAULT);
			return;
		case AircraftsystemPackage.AVIONICS__MODEL:
			setModel(MODEL_EDEFAULT);
			return;
		case AircraftsystemPackage.AVIONICS__NAVIGATIONSYSTEM:
			setNavigationsystem((NavigationSystem) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.AVIONICS__COMMUNICATIONSYSTEM:
			return communicationsystem != null;
		case AircraftsystemPackage.AVIONICS__MANUFACTURER:
			return MANUFACTURER_EDEFAULT == null ? manufacturer != null : !MANUFACTURER_EDEFAULT.equals(manufacturer);
		case AircraftsystemPackage.AVIONICS__MODEL:
			return MODEL_EDEFAULT == null ? model != null : !MODEL_EDEFAULT.equals(model);
		case AircraftsystemPackage.AVIONICS__NAVIGATIONSYSTEM:
			return navigationsystem != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (manufacturer: ");
		result.append(manufacturer);
		result.append(", model: ");
		result.append(model);
		result.append(')');
		return result.toString();
	}

} //AvionicsImpl
