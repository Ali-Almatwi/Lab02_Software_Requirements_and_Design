/**
 */
package aircraftsystem.metamodel.aircraftsystem.impl;

import aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage;
import aircraftsystem.metamodel.aircraftsystem.Engine;
import aircraftsystem.metamodel.aircraftsystem.ProplusionSytem;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Engine</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.EngineImpl#getEngineType <em>Engine Type</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.EngineImpl#getThrust <em>Thrust</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.EngineImpl#getFuelConsumption <em>Fuel Consumption</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.EngineImpl#getProplusionsytem <em>Proplusionsytem</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EngineImpl extends MinimalEObjectImpl.Container implements Engine {
	/**
	 * The default value of the '{@link #getEngineType() <em>Engine Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEngineType()
	 * @generated
	 * @ordered
	 */
	protected static final String ENGINE_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEngineType() <em>Engine Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEngineType()
	 * @generated
	 * @ordered
	 */
	protected String engineType = ENGINE_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getThrust() <em>Thrust</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThrust()
	 * @generated
	 * @ordered
	 */
	protected static final double THRUST_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getThrust() <em>Thrust</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThrust()
	 * @generated
	 * @ordered
	 */
	protected double thrust = THRUST_EDEFAULT;

	/**
	 * The default value of the '{@link #getFuelConsumption() <em>Fuel Consumption</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFuelConsumption()
	 * @generated
	 * @ordered
	 */
	protected static final double FUEL_CONSUMPTION_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getFuelConsumption() <em>Fuel Consumption</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFuelConsumption()
	 * @generated
	 * @ordered
	 */
	protected double fuelConsumption = FUEL_CONSUMPTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getProplusionsytem() <em>Proplusionsytem</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProplusionsytem()
	 * @generated
	 * @ordered
	 */
	protected EList<ProplusionSytem> proplusionsytem;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EngineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AircraftsystemPackage.Literals.ENGINE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEngineType() {
		return engineType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEngineType(String newEngineType) {
		String oldEngineType = engineType;
		engineType = newEngineType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.ENGINE__ENGINE_TYPE,
					oldEngineType, engineType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getThrust() {
		return thrust;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setThrust(double newThrust) {
		double oldThrust = thrust;
		thrust = newThrust;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.ENGINE__THRUST, oldThrust,
					thrust));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getFuelConsumption() {
		return fuelConsumption;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFuelConsumption(double newFuelConsumption) {
		double oldFuelConsumption = fuelConsumption;
		fuelConsumption = newFuelConsumption;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.ENGINE__FUEL_CONSUMPTION,
					oldFuelConsumption, fuelConsumption));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ProplusionSytem> getProplusionsytem() {
		if (proplusionsytem == null) {
			proplusionsytem = new EObjectContainmentEList<ProplusionSytem>(ProplusionSytem.class, this,
					AircraftsystemPackage.ENGINE__PROPLUSIONSYTEM);
		}
		return proplusionsytem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AircraftsystemPackage.ENGINE__PROPLUSIONSYTEM:
			return ((InternalEList<?>) getProplusionsytem()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AircraftsystemPackage.ENGINE__ENGINE_TYPE:
			return getEngineType();
		case AircraftsystemPackage.ENGINE__THRUST:
			return getThrust();
		case AircraftsystemPackage.ENGINE__FUEL_CONSUMPTION:
			return getFuelConsumption();
		case AircraftsystemPackage.ENGINE__PROPLUSIONSYTEM:
			return getProplusionsytem();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AircraftsystemPackage.ENGINE__ENGINE_TYPE:
			setEngineType((String) newValue);
			return;
		case AircraftsystemPackage.ENGINE__THRUST:
			setThrust((Double) newValue);
			return;
		case AircraftsystemPackage.ENGINE__FUEL_CONSUMPTION:
			setFuelConsumption((Double) newValue);
			return;
		case AircraftsystemPackage.ENGINE__PROPLUSIONSYTEM:
			getProplusionsytem().clear();
			getProplusionsytem().addAll((Collection<? extends ProplusionSytem>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.ENGINE__ENGINE_TYPE:
			setEngineType(ENGINE_TYPE_EDEFAULT);
			return;
		case AircraftsystemPackage.ENGINE__THRUST:
			setThrust(THRUST_EDEFAULT);
			return;
		case AircraftsystemPackage.ENGINE__FUEL_CONSUMPTION:
			setFuelConsumption(FUEL_CONSUMPTION_EDEFAULT);
			return;
		case AircraftsystemPackage.ENGINE__PROPLUSIONSYTEM:
			getProplusionsytem().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.ENGINE__ENGINE_TYPE:
			return ENGINE_TYPE_EDEFAULT == null ? engineType != null : !ENGINE_TYPE_EDEFAULT.equals(engineType);
		case AircraftsystemPackage.ENGINE__THRUST:
			return thrust != THRUST_EDEFAULT;
		case AircraftsystemPackage.ENGINE__FUEL_CONSUMPTION:
			return fuelConsumption != FUEL_CONSUMPTION_EDEFAULT;
		case AircraftsystemPackage.ENGINE__PROPLUSIONSYTEM:
			return proplusionsytem != null && !proplusionsytem.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EngineType: ");
		result.append(engineType);
		result.append(", thrust: ");
		result.append(thrust);
		result.append(", fuelConsumption: ");
		result.append(fuelConsumption);
		result.append(')');
		return result.toString();
	}

} //EngineImpl
