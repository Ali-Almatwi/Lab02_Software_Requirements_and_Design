/**
 */
package aircraftsystem.metamodel.aircraftsystem.impl;

import aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage;
import aircraftsystem.metamodel.aircraftsystem.Wing;
import aircraftsystem.metamodel.aircraftsystem.Winglet;
import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Wing</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.WingImpl#getWinglllet <em>Winglllet</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.WingImpl#getSpan <em>Span</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.WingImpl#getSweepAngle <em>Sweep Angle</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.WingImpl#getArea <em>Area</em>}</li>
 * </ul>
 *
 * @generated
 */
public class WingImpl extends MinimalEObjectImpl.Container implements Wing {
	/**
	 * The cached value of the '{@link #getWinglllet() <em>Winglllet</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWinglllet()
	 * @generated
	 * @ordered
	 */
	protected EList<Winglet> winglllet;

	/**
	 * The default value of the '{@link #getSpan() <em>Span</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpan()
	 * @generated
	 * @ordered
	 */
	protected static final double SPAN_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getSpan() <em>Span</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpan()
	 * @generated
	 * @ordered
	 */
	protected double span = SPAN_EDEFAULT;

	/**
	 * The default value of the '{@link #getSweepAngle() <em>Sweep Angle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSweepAngle()
	 * @generated
	 * @ordered
	 */
	protected static final double SWEEP_ANGLE_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getSweepAngle() <em>Sweep Angle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSweepAngle()
	 * @generated
	 * @ordered
	 */
	protected double sweepAngle = SWEEP_ANGLE_EDEFAULT;

	/**
	 * The default value of the '{@link #getArea() <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArea()
	 * @generated
	 * @ordered
	 */
	protected static final double AREA_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getArea() <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArea()
	 * @generated
	 * @ordered
	 */
	protected double area = AREA_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WingImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AircraftsystemPackage.Literals.WING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Winglet> getWinglllet() {
		if (winglllet == null) {
			winglllet = new EObjectContainmentEList<Winglet>(Winglet.class, this,
					AircraftsystemPackage.WING__WINGLLLET);
		}
		return winglllet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getSpan() {
		return span;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSpan(double newSpan) {
		double oldSpan = span;
		span = newSpan;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.WING__SPAN, oldSpan, span));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getSweepAngle() {
		return sweepAngle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSweepAngle(double newSweepAngle) {
		double oldSweepAngle = sweepAngle;
		sweepAngle = newSweepAngle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.WING__SWEEP_ANGLE,
					oldSweepAngle, sweepAngle));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getArea() {
		return area;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArea(double newArea) {
		double oldArea = area;
		area = newArea;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.WING__AREA, oldArea, area));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void calculateLift() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AircraftsystemPackage.WING__WINGLLLET:
			return ((InternalEList<?>) getWinglllet()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AircraftsystemPackage.WING__WINGLLLET:
			return getWinglllet();
		case AircraftsystemPackage.WING__SPAN:
			return getSpan();
		case AircraftsystemPackage.WING__SWEEP_ANGLE:
			return getSweepAngle();
		case AircraftsystemPackage.WING__AREA:
			return getArea();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AircraftsystemPackage.WING__WINGLLLET:
			getWinglllet().clear();
			getWinglllet().addAll((Collection<? extends Winglet>) newValue);
			return;
		case AircraftsystemPackage.WING__SPAN:
			setSpan((Double) newValue);
			return;
		case AircraftsystemPackage.WING__SWEEP_ANGLE:
			setSweepAngle((Double) newValue);
			return;
		case AircraftsystemPackage.WING__AREA:
			setArea((Double) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.WING__WINGLLLET:
			getWinglllet().clear();
			return;
		case AircraftsystemPackage.WING__SPAN:
			setSpan(SPAN_EDEFAULT);
			return;
		case AircraftsystemPackage.WING__SWEEP_ANGLE:
			setSweepAngle(SWEEP_ANGLE_EDEFAULT);
			return;
		case AircraftsystemPackage.WING__AREA:
			setArea(AREA_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.WING__WINGLLLET:
			return winglllet != null && !winglllet.isEmpty();
		case AircraftsystemPackage.WING__SPAN:
			return span != SPAN_EDEFAULT;
		case AircraftsystemPackage.WING__SWEEP_ANGLE:
			return sweepAngle != SWEEP_ANGLE_EDEFAULT;
		case AircraftsystemPackage.WING__AREA:
			return area != AREA_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case AircraftsystemPackage.WING___CALCULATE_LIFT:
			calculateLift();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (span: ");
		result.append(span);
		result.append(", sweepAngle: ");
		result.append(sweepAngle);
		result.append(", area: ");
		result.append(area);
		result.append(')');
		return result.toString();
	}

} //WingImpl
