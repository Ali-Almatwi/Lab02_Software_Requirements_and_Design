/**
 */
package aircraftsystem.metamodel.aircraftsystem.impl;

import aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage;
import aircraftsystem.metamodel.aircraftsystem.CommunicationSystem;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Communication System</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.CommunicationSystemImpl#getFrequencyRange <em>Frequency Range</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.CommunicationSystemImpl#getTechnology <em>Technology</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CommunicationSystemImpl extends MinimalEObjectImpl.Container implements CommunicationSystem {
	/**
	 * The default value of the '{@link #getFrequencyRange() <em>Frequency Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFrequencyRange()
	 * @generated
	 * @ordered
	 */
	protected static final String FREQUENCY_RANGE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFrequencyRange() <em>Frequency Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFrequencyRange()
	 * @generated
	 * @ordered
	 */
	protected String frequencyRange = FREQUENCY_RANGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getTechnology() <em>Technology</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTechnology()
	 * @generated
	 * @ordered
	 */
	protected static final String TECHNOLOGY_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTechnology() <em>Technology</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTechnology()
	 * @generated
	 * @ordered
	 */
	protected String technology = TECHNOLOGY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CommunicationSystemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AircraftsystemPackage.Literals.COMMUNICATION_SYSTEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFrequencyRange() {
		return frequencyRange;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFrequencyRange(String newFrequencyRange) {
		String oldFrequencyRange = frequencyRange;
		frequencyRange = newFrequencyRange;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					AircraftsystemPackage.COMMUNICATION_SYSTEM__FREQUENCY_RANGE, oldFrequencyRange, frequencyRange));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTechnology() {
		return technology;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTechnology(String newTechnology) {
		String oldTechnology = technology;
		technology = newTechnology;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					AircraftsystemPackage.COMMUNICATION_SYSTEM__TECHNOLOGY, oldTechnology, technology));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AircraftsystemPackage.COMMUNICATION_SYSTEM__FREQUENCY_RANGE:
			return getFrequencyRange();
		case AircraftsystemPackage.COMMUNICATION_SYSTEM__TECHNOLOGY:
			return getTechnology();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AircraftsystemPackage.COMMUNICATION_SYSTEM__FREQUENCY_RANGE:
			setFrequencyRange((String) newValue);
			return;
		case AircraftsystemPackage.COMMUNICATION_SYSTEM__TECHNOLOGY:
			setTechnology((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.COMMUNICATION_SYSTEM__FREQUENCY_RANGE:
			setFrequencyRange(FREQUENCY_RANGE_EDEFAULT);
			return;
		case AircraftsystemPackage.COMMUNICATION_SYSTEM__TECHNOLOGY:
			setTechnology(TECHNOLOGY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.COMMUNICATION_SYSTEM__FREQUENCY_RANGE:
			return FREQUENCY_RANGE_EDEFAULT == null ? frequencyRange != null
					: !FREQUENCY_RANGE_EDEFAULT.equals(frequencyRange);
		case AircraftsystemPackage.COMMUNICATION_SYSTEM__TECHNOLOGY:
			return TECHNOLOGY_EDEFAULT == null ? technology != null : !TECHNOLOGY_EDEFAULT.equals(technology);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (frequencyRange: ");
		result.append(frequencyRange);
		result.append(", technology: ");
		result.append(technology);
		result.append(')');
		return result.toString();
	}

} //CommunicationSystemImpl
