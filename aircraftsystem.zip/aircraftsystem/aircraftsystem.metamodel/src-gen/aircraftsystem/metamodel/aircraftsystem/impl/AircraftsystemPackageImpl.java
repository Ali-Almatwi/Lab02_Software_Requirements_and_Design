/**
 */
package aircraftsystem.metamodel.aircraftsystem.impl;

import aircraftsystem.metamodel.aircraftsystem.Ailleron;
import aircraftsystem.metamodel.aircraftsystem.Aircraft;
import aircraftsystem.metamodel.aircraftsystem.AircraftsystemFactory;
import aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage;
import aircraftsystem.metamodel.aircraftsystem.Avionics;
import aircraftsystem.metamodel.aircraftsystem.CommunicationSystem;
import aircraftsystem.metamodel.aircraftsystem.ControlSurfaces;
import aircraftsystem.metamodel.aircraftsystem.Elevator;
import aircraftsystem.metamodel.aircraftsystem.Engine;
import aircraftsystem.metamodel.aircraftsystem.Fuselage;
import aircraftsystem.metamodel.aircraftsystem.NavigationSystem;
import aircraftsystem.metamodel.aircraftsystem.ProplusionSytem;
import aircraftsystem.metamodel.aircraftsystem.Rudder;
import aircraftsystem.metamodel.aircraftsystem.Wing;
import aircraftsystem.metamodel.aircraftsystem.Winglet;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class AircraftsystemPackageImpl extends EPackageImpl implements AircraftsystemPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass aircraftEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass wingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fuselageEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass engineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass avionicsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass wingletEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass proplusionSytemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass communicationSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass controlSurfacesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass rudderEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elevatorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ailleronEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass navigationSystemEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private AircraftsystemPackageImpl() {
		super(eNS_URI, AircraftsystemFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link AircraftsystemPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static AircraftsystemPackage init() {
		if (isInited)
			return (AircraftsystemPackage) EPackage.Registry.INSTANCE.getEPackage(AircraftsystemPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredAircraftsystemPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		AircraftsystemPackageImpl theAircraftsystemPackage = registeredAircraftsystemPackage instanceof AircraftsystemPackageImpl
				? (AircraftsystemPackageImpl) registeredAircraftsystemPackage
				: new AircraftsystemPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theAircraftsystemPackage.createPackageContents();

		// Initialize created meta-data
		theAircraftsystemPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theAircraftsystemPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(AircraftsystemPackage.eNS_URI, theAircraftsystemPackage);
		return theAircraftsystemPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAircraft() {
		return aircraftEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAircraft_Model() {
		return (EAttribute) aircraftEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAircraft_MaxSeed() {
		return (EAttribute) aircraftEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAircraft_Wing() {
		return (EReference) aircraftEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAircraft_Fuselage() {
		return (EReference) aircraftEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAircraft_Engine() {
		return (EReference) aircraftEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAircraft_Avionics() {
		return (EReference) aircraftEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAircraft_Controlsurfaces() {
		return (EReference) aircraftEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAircraft_Range() {
		return (EAttribute) aircraftEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAircraft_SeatingCategory() {
		return (EAttribute) aircraftEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getAircraft__CalculatePerformanceMetrics() {
		return aircraftEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWing() {
		return wingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWing_Winglllet() {
		return (EReference) wingEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWing_Span() {
		return (EAttribute) wingEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWing_SweepAngle() {
		return (EAttribute) wingEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWing_Area() {
		return (EAttribute) wingEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getWing__CalculateLift() {
		return wingEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFuselage() {
		return fuselageEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFuselage_Length() {
		return (EAttribute) fuselageEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFuselage_Diameter() {
		return (EAttribute) fuselageEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFuselage_Material() {
		return (EAttribute) fuselageEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEngine() {
		return engineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEngine_EngineType() {
		return (EAttribute) engineEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEngine_Thrust() {
		return (EAttribute) engineEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEngine_FuelConsumption() {
		return (EAttribute) engineEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEngine_Proplusionsytem() {
		return (EReference) engineEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAvionics() {
		return avionicsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAvionics_Communicationsystem() {
		return (EReference) avionicsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAvionics_Manufacturer() {
		return (EAttribute) avionicsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAvionics_Model() {
		return (EAttribute) avionicsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAvionics_Navigationsystem() {
		return (EReference) avionicsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWinglet() {
		return wingletEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWinglet_Height() {
		return (EAttribute) wingletEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWinglet_Angle() {
		return (EAttribute) wingletEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProplusionSytem() {
		return proplusionSytemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProplusionSytem_FuelType() {
		return (EAttribute) proplusionSytemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProplusionSytem_Efficiency() {
		return (EAttribute) proplusionSytemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCommunicationSystem() {
		return communicationSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCommunicationSystem_FrequencyRange() {
		return (EAttribute) communicationSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCommunicationSystem_Technology() {
		return (EAttribute) communicationSystemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getControlSurfaces() {
		return controlSurfacesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getControlSurfaces_Type() {
		return (EAttribute) controlSurfacesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getControlSurfaces_Area() {
		return (EAttribute) controlSurfacesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getControlSurfaces_Rudder() {
		return (EReference) controlSurfacesEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getControlSurfaces_Ailleron() {
		return (EReference) controlSurfacesEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getControlSurfaces_Elevator() {
		return (EReference) controlSurfacesEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRudder() {
		return rudderEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRudder_Area() {
		return (EAttribute) rudderEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRudder_MaxDeflectionAngle() {
		return (EAttribute) rudderEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getElevator() {
		return elevatorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getElevator_Area() {
		return (EAttribute) elevatorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getElevator_MaxDeflectionAngle() {
		return (EAttribute) elevatorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAilleron() {
		return ailleronEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAilleron_Area() {
		return (EAttribute) ailleronEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAilleron_MaxDeflectionAngle() {
		return (EAttribute) ailleronEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNavigationSystem() {
		return navigationSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNavigationSystem_Technology() {
		return (EAttribute) navigationSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNavigationSystem_Rfeatures() {
		return (EAttribute) navigationSystemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AircraftsystemFactory getAircraftsystemFactory() {
		return (AircraftsystemFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		aircraftEClass = createEClass(AIRCRAFT);
		createEAttribute(aircraftEClass, AIRCRAFT__MODEL);
		createEAttribute(aircraftEClass, AIRCRAFT__MAX_SEED);
		createEReference(aircraftEClass, AIRCRAFT__WING);
		createEReference(aircraftEClass, AIRCRAFT__FUSELAGE);
		createEReference(aircraftEClass, AIRCRAFT__ENGINE);
		createEReference(aircraftEClass, AIRCRAFT__AVIONICS);
		createEReference(aircraftEClass, AIRCRAFT__CONTROLSURFACES);
		createEAttribute(aircraftEClass, AIRCRAFT__RANGE);
		createEAttribute(aircraftEClass, AIRCRAFT__SEATING_CATEGORY);
		createEOperation(aircraftEClass, AIRCRAFT___CALCULATE_PERFORMANCE_METRICS);

		wingEClass = createEClass(WING);
		createEReference(wingEClass, WING__WINGLLLET);
		createEAttribute(wingEClass, WING__SPAN);
		createEAttribute(wingEClass, WING__SWEEP_ANGLE);
		createEAttribute(wingEClass, WING__AREA);
		createEOperation(wingEClass, WING___CALCULATE_LIFT);

		fuselageEClass = createEClass(FUSELAGE);
		createEAttribute(fuselageEClass, FUSELAGE__LENGTH);
		createEAttribute(fuselageEClass, FUSELAGE__DIAMETER);
		createEAttribute(fuselageEClass, FUSELAGE__MATERIAL);

		engineEClass = createEClass(ENGINE);
		createEAttribute(engineEClass, ENGINE__ENGINE_TYPE);
		createEAttribute(engineEClass, ENGINE__THRUST);
		createEAttribute(engineEClass, ENGINE__FUEL_CONSUMPTION);
		createEReference(engineEClass, ENGINE__PROPLUSIONSYTEM);

		avionicsEClass = createEClass(AVIONICS);
		createEReference(avionicsEClass, AVIONICS__COMMUNICATIONSYSTEM);
		createEAttribute(avionicsEClass, AVIONICS__MANUFACTURER);
		createEAttribute(avionicsEClass, AVIONICS__MODEL);
		createEReference(avionicsEClass, AVIONICS__NAVIGATIONSYSTEM);

		wingletEClass = createEClass(WINGLET);
		createEAttribute(wingletEClass, WINGLET__HEIGHT);
		createEAttribute(wingletEClass, WINGLET__ANGLE);

		proplusionSytemEClass = createEClass(PROPLUSION_SYTEM);
		createEAttribute(proplusionSytemEClass, PROPLUSION_SYTEM__FUEL_TYPE);
		createEAttribute(proplusionSytemEClass, PROPLUSION_SYTEM__EFFICIENCY);

		communicationSystemEClass = createEClass(COMMUNICATION_SYSTEM);
		createEAttribute(communicationSystemEClass, COMMUNICATION_SYSTEM__FREQUENCY_RANGE);
		createEAttribute(communicationSystemEClass, COMMUNICATION_SYSTEM__TECHNOLOGY);

		controlSurfacesEClass = createEClass(CONTROL_SURFACES);
		createEAttribute(controlSurfacesEClass, CONTROL_SURFACES__TYPE);
		createEAttribute(controlSurfacesEClass, CONTROL_SURFACES__AREA);
		createEReference(controlSurfacesEClass, CONTROL_SURFACES__RUDDER);
		createEReference(controlSurfacesEClass, CONTROL_SURFACES__AILLERON);
		createEReference(controlSurfacesEClass, CONTROL_SURFACES__ELEVATOR);

		rudderEClass = createEClass(RUDDER);
		createEAttribute(rudderEClass, RUDDER__AREA);
		createEAttribute(rudderEClass, RUDDER__MAX_DEFLECTION_ANGLE);

		elevatorEClass = createEClass(ELEVATOR);
		createEAttribute(elevatorEClass, ELEVATOR__AREA);
		createEAttribute(elevatorEClass, ELEVATOR__MAX_DEFLECTION_ANGLE);

		ailleronEClass = createEClass(AILLERON);
		createEAttribute(ailleronEClass, AILLERON__AREA);
		createEAttribute(ailleronEClass, AILLERON__MAX_DEFLECTION_ANGLE);

		navigationSystemEClass = createEClass(NAVIGATION_SYSTEM);
		createEAttribute(navigationSystemEClass, NAVIGATION_SYSTEM__TECHNOLOGY);
		createEAttribute(navigationSystemEClass, NAVIGATION_SYSTEM__RFEATURES);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(aircraftEClass, Aircraft.class, "Aircraft", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAircraft_Model(), ecorePackage.getEString(), "model", null, 0, 1, Aircraft.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAircraft_MaxSeed(), ecorePackage.getEDouble(), "maxSeed", null, 0, 1, Aircraft.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAircraft_Wing(), this.getWing(), null, "wing", null, 1, -1, Aircraft.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getAircraft_Fuselage(), this.getFuselage(), null, "fuselage", null, 1, 1, Aircraft.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAircraft_Engine(), this.getEngine(), null, "engine", null, 1, -1, Aircraft.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAircraft_Avionics(), this.getAvionics(), null, "avionics", null, 1, 1, Aircraft.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAircraft_Controlsurfaces(), this.getControlSurfaces(), null, "controlsurfaces", null, 1, -1,
				Aircraft.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAircraft_Range(), ecorePackage.getEDouble(), "range", null, 0, 1, Aircraft.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAircraft_SeatingCategory(), ecorePackage.getEInt(), "seatingCategory", null, 0, 1,
				Aircraft.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEOperation(getAircraft__CalculatePerformanceMetrics(), null, "calculatePerformanceMetrics", 0, 1, IS_UNIQUE,
				IS_ORDERED);

		initEClass(wingEClass, Wing.class, "Wing", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getWing_Winglllet(), this.getWinglet(), null, "winglllet", null, 0, -1, Wing.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWing_Span(), ecorePackage.getEDouble(), "span", "0.0", 0, 1, Wing.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWing_SweepAngle(), ecorePackage.getEDouble(), "sweepAngle", "0.0", 0, 1, Wing.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWing_Area(), ecorePackage.getEDouble(), "area", null, 0, 1, Wing.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getWing__CalculateLift(), null, "calculateLift", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(fuselageEClass, Fuselage.class, "Fuselage", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFuselage_Length(), ecorePackage.getEDouble(), "length", null, 0, 1, Fuselage.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFuselage_Diameter(), ecorePackage.getEDouble(), "diameter", null, 0, 1, Fuselage.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFuselage_Material(), ecorePackage.getEString(), "material", null, 0, 1, Fuselage.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(engineEClass, Engine.class, "Engine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEngine_EngineType(), ecorePackage.getEString(), "EngineType", null, 0, 1, Engine.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getEngine_Thrust(), ecorePackage.getEDouble(), "thrust", null, 0, 1, Engine.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getEngine_FuelConsumption(), ecorePackage.getEDouble(), "fuelConsumption", null, 0, 1,
				Engine.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getEngine_Proplusionsytem(), this.getProplusionSytem(), null, "proplusionsytem", null, 1, -1,
				Engine.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(avionicsEClass, Avionics.class, "Avionics", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAvionics_Communicationsystem(), this.getCommunicationSystem(), null, "communicationsystem",
				null, 1, 1, Avionics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAvionics_Manufacturer(), ecorePackage.getEString(), "manufacturer", null, 0, 1,
				Avionics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAvionics_Model(), ecorePackage.getEString(), "model", null, 0, 1, Avionics.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAvionics_Navigationsystem(), this.getNavigationSystem(), null, "navigationsystem", null, 1, 1,
				Avionics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(wingletEClass, Winglet.class, "Winglet", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getWinglet_Height(), ecorePackage.getEDouble(), "height", null, 0, 1, Winglet.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWinglet_Angle(), ecorePackage.getEDouble(), "angle", null, 0, 1, Winglet.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(proplusionSytemEClass, ProplusionSytem.class, "ProplusionSytem", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getProplusionSytem_FuelType(), ecorePackage.getEString(), "fuelType", null, 0, 1,
				ProplusionSytem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getProplusionSytem_Efficiency(), ecorePackage.getEDouble(), "efficiency", null, 0, 1,
				ProplusionSytem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(communicationSystemEClass, CommunicationSystem.class, "CommunicationSystem", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCommunicationSystem_FrequencyRange(), ecorePackage.getEString(), "frequencyRange", null, 0, 1,
				CommunicationSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCommunicationSystem_Technology(), ecorePackage.getEString(), "technology", null, 0, 1,
				CommunicationSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(controlSurfacesEClass, ControlSurfaces.class, "ControlSurfaces", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getControlSurfaces_Type(), ecorePackage.getEString(), "type", null, 0, 1, ControlSurfaces.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getControlSurfaces_Area(), ecorePackage.getEDouble(), "area", null, 0, 1, ControlSurfaces.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getControlSurfaces_Rudder(), this.getRudder(), null, "rudder", null, 1, 1, ControlSurfaces.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getControlSurfaces_Ailleron(), this.getAilleron(), null, "ailleron", null, 1, 1,
				ControlSurfaces.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getControlSurfaces_Elevator(), this.getElevator(), null, "elevator", null, 1, 1,
				ControlSurfaces.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(rudderEClass, Rudder.class, "Rudder", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRudder_Area(), ecorePackage.getEDouble(), "area", null, 0, 1, Rudder.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRudder_MaxDeflectionAngle(), ecorePackage.getEDouble(), "maxDeflectionAngle", null, 0, 1,
				Rudder.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(elevatorEClass, Elevator.class, "Elevator", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getElevator_Area(), ecorePackage.getEDouble(), "area", null, 0, 1, Elevator.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getElevator_MaxDeflectionAngle(), ecorePackage.getEDouble(), "maxDeflectionAngle", null, 0, 1,
				Elevator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(ailleronEClass, Ailleron.class, "Ailleron", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAilleron_Area(), ecorePackage.getEDouble(), "area", null, 0, 1, Ailleron.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAilleron_MaxDeflectionAngle(), ecorePackage.getEDouble(), "maxDeflectionAngle", null, 0, 1,
				Ailleron.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(navigationSystemEClass, NavigationSystem.class, "NavigationSystem", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNavigationSystem_Technology(), ecorePackage.getEString(), "technology", null, 0, 1,
				NavigationSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getNavigationSystem_Rfeatures(), ecorePackage.getEString(), "rfeatures", null, 0, 1,
				NavigationSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //AircraftsystemPackageImpl
