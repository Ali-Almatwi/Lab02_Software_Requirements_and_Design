/**
 */
package aircraftsystem.metamodel.aircraftsystem.impl;

import aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage;
import aircraftsystem.metamodel.aircraftsystem.Elevator;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Elevator</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.ElevatorImpl#getArea <em>Area</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.ElevatorImpl#getMaxDeflectionAngle <em>Max Deflection Angle</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ElevatorImpl extends MinimalEObjectImpl.Container implements Elevator {
	/**
	 * The default value of the '{@link #getArea() <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArea()
	 * @generated
	 * @ordered
	 */
	protected static final double AREA_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getArea() <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArea()
	 * @generated
	 * @ordered
	 */
	protected double area = AREA_EDEFAULT;

	/**
	 * The default value of the '{@link #getMaxDeflectionAngle() <em>Max Deflection Angle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxDeflectionAngle()
	 * @generated
	 * @ordered
	 */
	protected static final double MAX_DEFLECTION_ANGLE_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getMaxDeflectionAngle() <em>Max Deflection Angle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxDeflectionAngle()
	 * @generated
	 * @ordered
	 */
	protected double maxDeflectionAngle = MAX_DEFLECTION_ANGLE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ElevatorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AircraftsystemPackage.Literals.ELEVATOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getArea() {
		return area;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArea(double newArea) {
		double oldArea = area;
		area = newArea;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.ELEVATOR__AREA, oldArea, area));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getMaxDeflectionAngle() {
		return maxDeflectionAngle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaxDeflectionAngle(double newMaxDeflectionAngle) {
		double oldMaxDeflectionAngle = maxDeflectionAngle;
		maxDeflectionAngle = newMaxDeflectionAngle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.ELEVATOR__MAX_DEFLECTION_ANGLE,
					oldMaxDeflectionAngle, maxDeflectionAngle));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AircraftsystemPackage.ELEVATOR__AREA:
			return getArea();
		case AircraftsystemPackage.ELEVATOR__MAX_DEFLECTION_ANGLE:
			return getMaxDeflectionAngle();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AircraftsystemPackage.ELEVATOR__AREA:
			setArea((Double) newValue);
			return;
		case AircraftsystemPackage.ELEVATOR__MAX_DEFLECTION_ANGLE:
			setMaxDeflectionAngle((Double) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.ELEVATOR__AREA:
			setArea(AREA_EDEFAULT);
			return;
		case AircraftsystemPackage.ELEVATOR__MAX_DEFLECTION_ANGLE:
			setMaxDeflectionAngle(MAX_DEFLECTION_ANGLE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.ELEVATOR__AREA:
			return area != AREA_EDEFAULT;
		case AircraftsystemPackage.ELEVATOR__MAX_DEFLECTION_ANGLE:
			return maxDeflectionAngle != MAX_DEFLECTION_ANGLE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (area: ");
		result.append(area);
		result.append(", maxDeflectionAngle: ");
		result.append(maxDeflectionAngle);
		result.append(')');
		return result.toString();
	}

} //ElevatorImpl
