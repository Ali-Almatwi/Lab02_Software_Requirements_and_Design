/**
 */
package aircraftsystem.metamodel.aircraftsystem.impl;

import aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage;
import aircraftsystem.metamodel.aircraftsystem.Fuselage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fuselage</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.FuselageImpl#getLength <em>Length</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.FuselageImpl#getDiameter <em>Diameter</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.FuselageImpl#getMaterial <em>Material</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FuselageImpl extends MinimalEObjectImpl.Container implements Fuselage {
	/**
	 * The default value of the '{@link #getLength() <em>Length</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLength()
	 * @generated
	 * @ordered
	 */
	protected static final double LENGTH_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getLength() <em>Length</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLength()
	 * @generated
	 * @ordered
	 */
	protected double length = LENGTH_EDEFAULT;

	/**
	 * The default value of the '{@link #getDiameter() <em>Diameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiameter()
	 * @generated
	 * @ordered
	 */
	protected static final double DIAMETER_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getDiameter() <em>Diameter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiameter()
	 * @generated
	 * @ordered
	 */
	protected double diameter = DIAMETER_EDEFAULT;

	/**
	 * The default value of the '{@link #getMaterial() <em>Material</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaterial()
	 * @generated
	 * @ordered
	 */
	protected static final String MATERIAL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMaterial() <em>Material</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaterial()
	 * @generated
	 * @ordered
	 */
	protected String material = MATERIAL_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FuselageImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AircraftsystemPackage.Literals.FUSELAGE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getLength() {
		return length;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLength(double newLength) {
		double oldLength = length;
		length = newLength;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.FUSELAGE__LENGTH, oldLength,
					length));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getDiameter() {
		return diameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDiameter(double newDiameter) {
		double oldDiameter = diameter;
		diameter = newDiameter;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.FUSELAGE__DIAMETER, oldDiameter,
					diameter));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMaterial() {
		return material;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaterial(String newMaterial) {
		String oldMaterial = material;
		material = newMaterial;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.FUSELAGE__MATERIAL, oldMaterial,
					material));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AircraftsystemPackage.FUSELAGE__LENGTH:
			return getLength();
		case AircraftsystemPackage.FUSELAGE__DIAMETER:
			return getDiameter();
		case AircraftsystemPackage.FUSELAGE__MATERIAL:
			return getMaterial();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AircraftsystemPackage.FUSELAGE__LENGTH:
			setLength((Double) newValue);
			return;
		case AircraftsystemPackage.FUSELAGE__DIAMETER:
			setDiameter((Double) newValue);
			return;
		case AircraftsystemPackage.FUSELAGE__MATERIAL:
			setMaterial((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.FUSELAGE__LENGTH:
			setLength(LENGTH_EDEFAULT);
			return;
		case AircraftsystemPackage.FUSELAGE__DIAMETER:
			setDiameter(DIAMETER_EDEFAULT);
			return;
		case AircraftsystemPackage.FUSELAGE__MATERIAL:
			setMaterial(MATERIAL_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.FUSELAGE__LENGTH:
			return length != LENGTH_EDEFAULT;
		case AircraftsystemPackage.FUSELAGE__DIAMETER:
			return diameter != DIAMETER_EDEFAULT;
		case AircraftsystemPackage.FUSELAGE__MATERIAL:
			return MATERIAL_EDEFAULT == null ? material != null : !MATERIAL_EDEFAULT.equals(material);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (length: ");
		result.append(length);
		result.append(", diameter: ");
		result.append(diameter);
		result.append(", material: ");
		result.append(material);
		result.append(')');
		return result.toString();
	}

} //FuselageImpl
