/**
 */
package aircraftsystem.metamodel.aircraftsystem.impl;

import aircraftsystem.metamodel.aircraftsystem.Aircraft;
import aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage;
import aircraftsystem.metamodel.aircraftsystem.Avionics;
import aircraftsystem.metamodel.aircraftsystem.ControlSurfaces;
import aircraftsystem.metamodel.aircraftsystem.Engine;
import aircraftsystem.metamodel.aircraftsystem.Fuselage;
import aircraftsystem.metamodel.aircraftsystem.Wing;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Aircraft</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl#getModel <em>Model</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl#getMaxSeed <em>Max Seed</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl#getWing <em>Wing</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl#getFuselage <em>Fuselage</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl#getEngine <em>Engine</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl#getAvionics <em>Avionics</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl#getControlsurfaces <em>Controlsurfaces</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl#getRange <em>Range</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl#getSeatingCategory <em>Seating Category</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AircraftImpl extends MinimalEObjectImpl.Container implements Aircraft {
	/**
	 * The default value of the '{@link #getModel() <em>Model</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModel()
	 * @generated
	 * @ordered
	 */
	protected static final String MODEL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getModel() <em>Model</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModel()
	 * @generated
	 * @ordered
	 */
	protected String model = MODEL_EDEFAULT;

	/**
	 * The default value of the '{@link #getMaxSeed() <em>Max Seed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxSeed()
	 * @generated
	 * @ordered
	 */
	protected static final double MAX_SEED_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getMaxSeed() <em>Max Seed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxSeed()
	 * @generated
	 * @ordered
	 */
	protected double maxSeed = MAX_SEED_EDEFAULT;

	/**
	 * The cached value of the '{@link #getWing() <em>Wing</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWing()
	 * @generated
	 * @ordered
	 */
	protected EList<Wing> wing;

	/**
	 * The cached value of the '{@link #getFuselage() <em>Fuselage</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFuselage()
	 * @generated
	 * @ordered
	 */
	protected Fuselage fuselage;

	/**
	 * The cached value of the '{@link #getEngine() <em>Engine</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEngine()
	 * @generated
	 * @ordered
	 */
	protected EList<Engine> engine;

	/**
	 * The cached value of the '{@link #getAvionics() <em>Avionics</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAvionics()
	 * @generated
	 * @ordered
	 */
	protected Avionics avionics;

	/**
	 * The cached value of the '{@link #getControlsurfaces() <em>Controlsurfaces</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlsurfaces()
	 * @generated
	 * @ordered
	 */
	protected EList<ControlSurfaces> controlsurfaces;

	/**
	 * The default value of the '{@link #getRange() <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRange()
	 * @generated
	 * @ordered
	 */
	protected static final double RANGE_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getRange() <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRange()
	 * @generated
	 * @ordered
	 */
	protected double range = RANGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getSeatingCategory() <em>Seating Category</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSeatingCategory()
	 * @generated
	 * @ordered
	 */
	protected static final int SEATING_CATEGORY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSeatingCategory() <em>Seating Category</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSeatingCategory()
	 * @generated
	 * @ordered
	 */
	protected int seatingCategory = SEATING_CATEGORY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AircraftImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AircraftsystemPackage.Literals.AIRCRAFT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getModel() {
		return model;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setModel(String newModel) {
		String oldModel = model;
		model = newModel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.AIRCRAFT__MODEL, oldModel,
					model));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getMaxSeed() {
		return maxSeed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaxSeed(double newMaxSeed) {
		double oldMaxSeed = maxSeed;
		maxSeed = newMaxSeed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.AIRCRAFT__MAX_SEED, oldMaxSeed,
					maxSeed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Wing> getWing() {
		if (wing == null) {
			wing = new EObjectContainmentEList<Wing>(Wing.class, this, AircraftsystemPackage.AIRCRAFT__WING);
		}
		return wing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fuselage getFuselage() {
		return fuselage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFuselage(Fuselage newFuselage, NotificationChain msgs) {
		Fuselage oldFuselage = fuselage;
		fuselage = newFuselage;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					AircraftsystemPackage.AIRCRAFT__FUSELAGE, oldFuselage, newFuselage);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFuselage(Fuselage newFuselage) {
		if (newFuselage != fuselage) {
			NotificationChain msgs = null;
			if (fuselage != null)
				msgs = ((InternalEObject) fuselage).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.AIRCRAFT__FUSELAGE, null, msgs);
			if (newFuselage != null)
				msgs = ((InternalEObject) newFuselage).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.AIRCRAFT__FUSELAGE, null, msgs);
			msgs = basicSetFuselage(newFuselage, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.AIRCRAFT__FUSELAGE, newFuselage,
					newFuselage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Engine> getEngine() {
		if (engine == null) {
			engine = new EObjectContainmentEList<Engine>(Engine.class, this, AircraftsystemPackage.AIRCRAFT__ENGINE);
		}
		return engine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Avionics getAvionics() {
		return avionics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAvionics(Avionics newAvionics, NotificationChain msgs) {
		Avionics oldAvionics = avionics;
		avionics = newAvionics;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					AircraftsystemPackage.AIRCRAFT__AVIONICS, oldAvionics, newAvionics);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAvionics(Avionics newAvionics) {
		if (newAvionics != avionics) {
			NotificationChain msgs = null;
			if (avionics != null)
				msgs = ((InternalEObject) avionics).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.AIRCRAFT__AVIONICS, null, msgs);
			if (newAvionics != null)
				msgs = ((InternalEObject) newAvionics).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - AircraftsystemPackage.AIRCRAFT__AVIONICS, null, msgs);
			msgs = basicSetAvionics(newAvionics, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.AIRCRAFT__AVIONICS, newAvionics,
					newAvionics));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ControlSurfaces> getControlsurfaces() {
		if (controlsurfaces == null) {
			controlsurfaces = new EObjectContainmentEList<ControlSurfaces>(ControlSurfaces.class, this,
					AircraftsystemPackage.AIRCRAFT__CONTROLSURFACES);
		}
		return controlsurfaces;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getRange() {
		return range;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRange(double newRange) {
		double oldRange = range;
		range = newRange;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.AIRCRAFT__RANGE, oldRange,
					range));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSeatingCategory() {
		return seatingCategory;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSeatingCategory(int newSeatingCategory) {
		int oldSeatingCategory = seatingCategory;
		seatingCategory = newSeatingCategory;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AircraftsystemPackage.AIRCRAFT__SEATING_CATEGORY,
					oldSeatingCategory, seatingCategory));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void calculatePerformanceMetrics() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AircraftsystemPackage.AIRCRAFT__WING:
			return ((InternalEList<?>) getWing()).basicRemove(otherEnd, msgs);
		case AircraftsystemPackage.AIRCRAFT__FUSELAGE:
			return basicSetFuselage(null, msgs);
		case AircraftsystemPackage.AIRCRAFT__ENGINE:
			return ((InternalEList<?>) getEngine()).basicRemove(otherEnd, msgs);
		case AircraftsystemPackage.AIRCRAFT__AVIONICS:
			return basicSetAvionics(null, msgs);
		case AircraftsystemPackage.AIRCRAFT__CONTROLSURFACES:
			return ((InternalEList<?>) getControlsurfaces()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AircraftsystemPackage.AIRCRAFT__MODEL:
			return getModel();
		case AircraftsystemPackage.AIRCRAFT__MAX_SEED:
			return getMaxSeed();
		case AircraftsystemPackage.AIRCRAFT__WING:
			return getWing();
		case AircraftsystemPackage.AIRCRAFT__FUSELAGE:
			return getFuselage();
		case AircraftsystemPackage.AIRCRAFT__ENGINE:
			return getEngine();
		case AircraftsystemPackage.AIRCRAFT__AVIONICS:
			return getAvionics();
		case AircraftsystemPackage.AIRCRAFT__CONTROLSURFACES:
			return getControlsurfaces();
		case AircraftsystemPackage.AIRCRAFT__RANGE:
			return getRange();
		case AircraftsystemPackage.AIRCRAFT__SEATING_CATEGORY:
			return getSeatingCategory();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AircraftsystemPackage.AIRCRAFT__MODEL:
			setModel((String) newValue);
			return;
		case AircraftsystemPackage.AIRCRAFT__MAX_SEED:
			setMaxSeed((Double) newValue);
			return;
		case AircraftsystemPackage.AIRCRAFT__WING:
			getWing().clear();
			getWing().addAll((Collection<? extends Wing>) newValue);
			return;
		case AircraftsystemPackage.AIRCRAFT__FUSELAGE:
			setFuselage((Fuselage) newValue);
			return;
		case AircraftsystemPackage.AIRCRAFT__ENGINE:
			getEngine().clear();
			getEngine().addAll((Collection<? extends Engine>) newValue);
			return;
		case AircraftsystemPackage.AIRCRAFT__AVIONICS:
			setAvionics((Avionics) newValue);
			return;
		case AircraftsystemPackage.AIRCRAFT__CONTROLSURFACES:
			getControlsurfaces().clear();
			getControlsurfaces().addAll((Collection<? extends ControlSurfaces>) newValue);
			return;
		case AircraftsystemPackage.AIRCRAFT__RANGE:
			setRange((Double) newValue);
			return;
		case AircraftsystemPackage.AIRCRAFT__SEATING_CATEGORY:
			setSeatingCategory((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.AIRCRAFT__MODEL:
			setModel(MODEL_EDEFAULT);
			return;
		case AircraftsystemPackage.AIRCRAFT__MAX_SEED:
			setMaxSeed(MAX_SEED_EDEFAULT);
			return;
		case AircraftsystemPackage.AIRCRAFT__WING:
			getWing().clear();
			return;
		case AircraftsystemPackage.AIRCRAFT__FUSELAGE:
			setFuselage((Fuselage) null);
			return;
		case AircraftsystemPackage.AIRCRAFT__ENGINE:
			getEngine().clear();
			return;
		case AircraftsystemPackage.AIRCRAFT__AVIONICS:
			setAvionics((Avionics) null);
			return;
		case AircraftsystemPackage.AIRCRAFT__CONTROLSURFACES:
			getControlsurfaces().clear();
			return;
		case AircraftsystemPackage.AIRCRAFT__RANGE:
			setRange(RANGE_EDEFAULT);
			return;
		case AircraftsystemPackage.AIRCRAFT__SEATING_CATEGORY:
			setSeatingCategory(SEATING_CATEGORY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AircraftsystemPackage.AIRCRAFT__MODEL:
			return MODEL_EDEFAULT == null ? model != null : !MODEL_EDEFAULT.equals(model);
		case AircraftsystemPackage.AIRCRAFT__MAX_SEED:
			return maxSeed != MAX_SEED_EDEFAULT;
		case AircraftsystemPackage.AIRCRAFT__WING:
			return wing != null && !wing.isEmpty();
		case AircraftsystemPackage.AIRCRAFT__FUSELAGE:
			return fuselage != null;
		case AircraftsystemPackage.AIRCRAFT__ENGINE:
			return engine != null && !engine.isEmpty();
		case AircraftsystemPackage.AIRCRAFT__AVIONICS:
			return avionics != null;
		case AircraftsystemPackage.AIRCRAFT__CONTROLSURFACES:
			return controlsurfaces != null && !controlsurfaces.isEmpty();
		case AircraftsystemPackage.AIRCRAFT__RANGE:
			return range != RANGE_EDEFAULT;
		case AircraftsystemPackage.AIRCRAFT__SEATING_CATEGORY:
			return seatingCategory != SEATING_CATEGORY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case AircraftsystemPackage.AIRCRAFT___CALCULATE_PERFORMANCE_METRICS:
			calculatePerformanceMetrics();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (model: ");
		result.append(model);
		result.append(", maxSeed: ");
		result.append(maxSeed);
		result.append(", range: ");
		result.append(range);
		result.append(", seatingCategory: ");
		result.append(seatingCategory);
		result.append(')');
		return result.toString();
	}

} //AircraftImpl
