/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rudder</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Rudder#getArea <em>Area</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Rudder#getMaxDeflectionAngle <em>Max Deflection Angle</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getRudder()
 * @model
 * @generated
 */
public interface Rudder extends EObject {
	/**
	 * Returns the value of the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Area</em>' attribute.
	 * @see #setArea(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getRudder_Area()
	 * @model
	 * @generated
	 */
	double getArea();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Rudder#getArea <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Area</em>' attribute.
	 * @see #getArea()
	 * @generated
	 */
	void setArea(double value);

	/**
	 * Returns the value of the '<em><b>Max Deflection Angle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Deflection Angle</em>' attribute.
	 * @see #setMaxDeflectionAngle(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getRudder_MaxDeflectionAngle()
	 * @model
	 * @generated
	 */
	double getMaxDeflectionAngle();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Rudder#getMaxDeflectionAngle <em>Max Deflection Angle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Deflection Angle</em>' attribute.
	 * @see #getMaxDeflectionAngle()
	 * @generated
	 */
	void setMaxDeflectionAngle(double value);

} // Rudder
