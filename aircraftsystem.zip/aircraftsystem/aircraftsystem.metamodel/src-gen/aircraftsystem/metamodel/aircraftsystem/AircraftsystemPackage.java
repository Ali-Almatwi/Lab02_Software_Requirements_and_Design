/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemFactory
 * @model kind="package"
 * @generated
 */
public interface AircraftsystemPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "aircraftsystem";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/aircraftsystem";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "aircraftsystem";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	AircraftsystemPackage eINSTANCE = aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl.init();

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl <em>Aircraft</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getAircraft()
	 * @generated
	 */
	int AIRCRAFT = 0;

	/**
	 * The feature id for the '<em><b>Model</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT__MODEL = 0;

	/**
	 * The feature id for the '<em><b>Max Seed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT__MAX_SEED = 1;

	/**
	 * The feature id for the '<em><b>Wing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT__WING = 2;

	/**
	 * The feature id for the '<em><b>Fuselage</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT__FUSELAGE = 3;

	/**
	 * The feature id for the '<em><b>Engine</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT__ENGINE = 4;

	/**
	 * The feature id for the '<em><b>Avionics</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT__AVIONICS = 5;

	/**
	 * The feature id for the '<em><b>Controlsurfaces</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT__CONTROLSURFACES = 6;

	/**
	 * The feature id for the '<em><b>Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT__RANGE = 7;

	/**
	 * The feature id for the '<em><b>Seating Category</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT__SEATING_CATEGORY = 8;

	/**
	 * The number of structural features of the '<em>Aircraft</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT_FEATURE_COUNT = 9;

	/**
	 * The operation id for the '<em>Calculate Performance Metrics</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT___CALCULATE_PERFORMANCE_METRICS = 0;

	/**
	 * The number of operations of the '<em>Aircraft</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AIRCRAFT_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.WingImpl <em>Wing</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.WingImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getWing()
	 * @generated
	 */
	int WING = 1;

	/**
	 * The feature id for the '<em><b>Winglllet</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WING__WINGLLLET = 0;

	/**
	 * The feature id for the '<em><b>Span</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WING__SPAN = 1;

	/**
	 * The feature id for the '<em><b>Sweep Angle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WING__SWEEP_ANGLE = 2;

	/**
	 * The feature id for the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WING__AREA = 3;

	/**
	 * The number of structural features of the '<em>Wing</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WING_FEATURE_COUNT = 4;

	/**
	 * The operation id for the '<em>Calculate Lift</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WING___CALCULATE_LIFT = 0;

	/**
	 * The number of operations of the '<em>Wing</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WING_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.FuselageImpl <em>Fuselage</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.FuselageImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getFuselage()
	 * @generated
	 */
	int FUSELAGE = 2;

	/**
	 * The feature id for the '<em><b>Length</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUSELAGE__LENGTH = 0;

	/**
	 * The feature id for the '<em><b>Diameter</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUSELAGE__DIAMETER = 1;

	/**
	 * The feature id for the '<em><b>Material</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUSELAGE__MATERIAL = 2;

	/**
	 * The number of structural features of the '<em>Fuselage</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUSELAGE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Fuselage</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUSELAGE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.EngineImpl <em>Engine</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.EngineImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getEngine()
	 * @generated
	 */
	int ENGINE = 3;

	/**
	 * The feature id for the '<em><b>Engine Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINE__ENGINE_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Thrust</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINE__THRUST = 1;

	/**
	 * The feature id for the '<em><b>Fuel Consumption</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINE__FUEL_CONSUMPTION = 2;

	/**
	 * The feature id for the '<em><b>Proplusionsytem</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINE__PROPLUSIONSYTEM = 3;

	/**
	 * The number of structural features of the '<em>Engine</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Engine</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENGINE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.AvionicsImpl <em>Avionics</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AvionicsImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getAvionics()
	 * @generated
	 */
	int AVIONICS = 4;

	/**
	 * The feature id for the '<em><b>Communicationsystem</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AVIONICS__COMMUNICATIONSYSTEM = 0;

	/**
	 * The feature id for the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AVIONICS__MANUFACTURER = 1;

	/**
	 * The feature id for the '<em><b>Model</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AVIONICS__MODEL = 2;

	/**
	 * The feature id for the '<em><b>Navigationsystem</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AVIONICS__NAVIGATIONSYSTEM = 3;

	/**
	 * The number of structural features of the '<em>Avionics</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AVIONICS_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Avionics</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AVIONICS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.WingletImpl <em>Winglet</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.WingletImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getWinglet()
	 * @generated
	 */
	int WINGLET = 5;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WINGLET__HEIGHT = 0;

	/**
	 * The feature id for the '<em><b>Angle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WINGLET__ANGLE = 1;

	/**
	 * The number of structural features of the '<em>Winglet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WINGLET_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Winglet</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WINGLET_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.ProplusionSytemImpl <em>Proplusion Sytem</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.ProplusionSytemImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getProplusionSytem()
	 * @generated
	 */
	int PROPLUSION_SYTEM = 6;

	/**
	 * The feature id for the '<em><b>Fuel Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPLUSION_SYTEM__FUEL_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Efficiency</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPLUSION_SYTEM__EFFICIENCY = 1;

	/**
	 * The number of structural features of the '<em>Proplusion Sytem</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPLUSION_SYTEM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Proplusion Sytem</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPLUSION_SYTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.CommunicationSystemImpl <em>Communication System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.CommunicationSystemImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getCommunicationSystem()
	 * @generated
	 */
	int COMMUNICATION_SYSTEM = 7;

	/**
	 * The feature id for the '<em><b>Frequency Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMUNICATION_SYSTEM__FREQUENCY_RANGE = 0;

	/**
	 * The feature id for the '<em><b>Technology</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMUNICATION_SYSTEM__TECHNOLOGY = 1;

	/**
	 * The number of structural features of the '<em>Communication System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMUNICATION_SYSTEM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Communication System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMMUNICATION_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.ControlSurfacesImpl <em>Control Surfaces</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.ControlSurfacesImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getControlSurfaces()
	 * @generated
	 */
	int CONTROL_SURFACES = 8;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_SURFACES__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_SURFACES__AREA = 1;

	/**
	 * The feature id for the '<em><b>Rudder</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_SURFACES__RUDDER = 2;

	/**
	 * The feature id for the '<em><b>Ailleron</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_SURFACES__AILLERON = 3;

	/**
	 * The feature id for the '<em><b>Elevator</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_SURFACES__ELEVATOR = 4;

	/**
	 * The number of structural features of the '<em>Control Surfaces</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_SURFACES_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Control Surfaces</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_SURFACES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.RudderImpl <em>Rudder</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.RudderImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getRudder()
	 * @generated
	 */
	int RUDDER = 9;

	/**
	 * The feature id for the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RUDDER__AREA = 0;

	/**
	 * The feature id for the '<em><b>Max Deflection Angle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RUDDER__MAX_DEFLECTION_ANGLE = 1;

	/**
	 * The number of structural features of the '<em>Rudder</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RUDDER_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Rudder</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RUDDER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.ElevatorImpl <em>Elevator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.ElevatorImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getElevator()
	 * @generated
	 */
	int ELEVATOR = 10;

	/**
	 * The feature id for the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR__AREA = 0;

	/**
	 * The feature id for the '<em><b>Max Deflection Angle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR__MAX_DEFLECTION_ANGLE = 1;

	/**
	 * The number of structural features of the '<em>Elevator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Elevator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.AilleronImpl <em>Ailleron</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AilleronImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getAilleron()
	 * @generated
	 */
	int AILLERON = 11;

	/**
	 * The feature id for the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AILLERON__AREA = 0;

	/**
	 * The feature id for the '<em><b>Max Deflection Angle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AILLERON__MAX_DEFLECTION_ANGLE = 1;

	/**
	 * The number of structural features of the '<em>Ailleron</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AILLERON_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Ailleron</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AILLERON_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.NavigationSystemImpl <em>Navigation System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.NavigationSystemImpl
	 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getNavigationSystem()
	 * @generated
	 */
	int NAVIGATION_SYSTEM = 12;

	/**
	 * The feature id for the '<em><b>Technology</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION_SYSTEM__TECHNOLOGY = 0;

	/**
	 * The feature id for the '<em><b>Rfeatures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION_SYSTEM__RFEATURES = 1;

	/**
	 * The number of structural features of the '<em>Navigation System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION_SYSTEM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Navigation System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAVIGATION_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft <em>Aircraft</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aircraft</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft
	 * @generated
	 */
	EClass getAircraft();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getModel <em>Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Model</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft#getModel()
	 * @see #getAircraft()
	 * @generated
	 */
	EAttribute getAircraft_Model();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getMaxSeed <em>Max Seed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Seed</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft#getMaxSeed()
	 * @see #getAircraft()
	 * @generated
	 */
	EAttribute getAircraft_MaxSeed();

	/**
	 * Returns the meta object for the containment reference list '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getWing <em>Wing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Wing</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft#getWing()
	 * @see #getAircraft()
	 * @generated
	 */
	EReference getAircraft_Wing();

	/**
	 * Returns the meta object for the containment reference '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getFuselage <em>Fuselage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Fuselage</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft#getFuselage()
	 * @see #getAircraft()
	 * @generated
	 */
	EReference getAircraft_Fuselage();

	/**
	 * Returns the meta object for the containment reference list '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getEngine <em>Engine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Engine</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft#getEngine()
	 * @see #getAircraft()
	 * @generated
	 */
	EReference getAircraft_Engine();

	/**
	 * Returns the meta object for the containment reference '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getAvionics <em>Avionics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Avionics</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft#getAvionics()
	 * @see #getAircraft()
	 * @generated
	 */
	EReference getAircraft_Avionics();

	/**
	 * Returns the meta object for the containment reference list '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getControlsurfaces <em>Controlsurfaces</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Controlsurfaces</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft#getControlsurfaces()
	 * @see #getAircraft()
	 * @generated
	 */
	EReference getAircraft_Controlsurfaces();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getRange <em>Range</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Range</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft#getRange()
	 * @see #getAircraft()
	 * @generated
	 */
	EAttribute getAircraft_Range();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#getSeatingCategory <em>Seating Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Seating Category</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft#getSeatingCategory()
	 * @see #getAircraft()
	 * @generated
	 */
	EAttribute getAircraft_SeatingCategory();

	/**
	 * Returns the meta object for the '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft#calculatePerformanceMetrics() <em>Calculate Performance Metrics</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Calculate Performance Metrics</em>' operation.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft#calculatePerformanceMetrics()
	 * @generated
	 */
	EOperation getAircraft__CalculatePerformanceMetrics();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.Wing <em>Wing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Wing</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Wing
	 * @generated
	 */
	EClass getWing();

	/**
	 * Returns the meta object for the containment reference list '{@link aircraftsystem.metamodel.aircraftsystem.Wing#getWinglllet <em>Winglllet</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Winglllet</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Wing#getWinglllet()
	 * @see #getWing()
	 * @generated
	 */
	EReference getWing_Winglllet();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Wing#getSpan <em>Span</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Span</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Wing#getSpan()
	 * @see #getWing()
	 * @generated
	 */
	EAttribute getWing_Span();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Wing#getSweepAngle <em>Sweep Angle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sweep Angle</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Wing#getSweepAngle()
	 * @see #getWing()
	 * @generated
	 */
	EAttribute getWing_SweepAngle();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Wing#getArea <em>Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Area</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Wing#getArea()
	 * @see #getWing()
	 * @generated
	 */
	EAttribute getWing_Area();

	/**
	 * Returns the meta object for the '{@link aircraftsystem.metamodel.aircraftsystem.Wing#calculateLift() <em>Calculate Lift</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Calculate Lift</em>' operation.
	 * @see aircraftsystem.metamodel.aircraftsystem.Wing#calculateLift()
	 * @generated
	 */
	EOperation getWing__CalculateLift();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.Fuselage <em>Fuselage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fuselage</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Fuselage
	 * @generated
	 */
	EClass getFuselage();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Fuselage#getLength <em>Length</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Length</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Fuselage#getLength()
	 * @see #getFuselage()
	 * @generated
	 */
	EAttribute getFuselage_Length();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Fuselage#getDiameter <em>Diameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Diameter</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Fuselage#getDiameter()
	 * @see #getFuselage()
	 * @generated
	 */
	EAttribute getFuselage_Diameter();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Fuselage#getMaterial <em>Material</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Material</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Fuselage#getMaterial()
	 * @see #getFuselage()
	 * @generated
	 */
	EAttribute getFuselage_Material();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.Engine <em>Engine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Engine</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Engine
	 * @generated
	 */
	EClass getEngine();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Engine#getEngineType <em>Engine Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Engine Type</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Engine#getEngineType()
	 * @see #getEngine()
	 * @generated
	 */
	EAttribute getEngine_EngineType();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Engine#getThrust <em>Thrust</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Thrust</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Engine#getThrust()
	 * @see #getEngine()
	 * @generated
	 */
	EAttribute getEngine_Thrust();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Engine#getFuelConsumption <em>Fuel Consumption</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Fuel Consumption</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Engine#getFuelConsumption()
	 * @see #getEngine()
	 * @generated
	 */
	EAttribute getEngine_FuelConsumption();

	/**
	 * Returns the meta object for the containment reference list '{@link aircraftsystem.metamodel.aircraftsystem.Engine#getProplusionsytem <em>Proplusionsytem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Proplusionsytem</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Engine#getProplusionsytem()
	 * @see #getEngine()
	 * @generated
	 */
	EReference getEngine_Proplusionsytem();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.Avionics <em>Avionics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Avionics</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Avionics
	 * @generated
	 */
	EClass getAvionics();

	/**
	 * Returns the meta object for the containment reference '{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getCommunicationsystem <em>Communicationsystem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Communicationsystem</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Avionics#getCommunicationsystem()
	 * @see #getAvionics()
	 * @generated
	 */
	EReference getAvionics_Communicationsystem();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getManufacturer <em>Manufacturer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Manufacturer</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Avionics#getManufacturer()
	 * @see #getAvionics()
	 * @generated
	 */
	EAttribute getAvionics_Manufacturer();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getModel <em>Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Model</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Avionics#getModel()
	 * @see #getAvionics()
	 * @generated
	 */
	EAttribute getAvionics_Model();

	/**
	 * Returns the meta object for the containment reference '{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getNavigationsystem <em>Navigationsystem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Navigationsystem</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Avionics#getNavigationsystem()
	 * @see #getAvionics()
	 * @generated
	 */
	EReference getAvionics_Navigationsystem();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.Winglet <em>Winglet</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Winglet</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Winglet
	 * @generated
	 */
	EClass getWinglet();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Winglet#getHeight <em>Height</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Height</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Winglet#getHeight()
	 * @see #getWinglet()
	 * @generated
	 */
	EAttribute getWinglet_Height();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Winglet#getAngle <em>Angle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Angle</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Winglet#getAngle()
	 * @see #getWinglet()
	 * @generated
	 */
	EAttribute getWinglet_Angle();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.ProplusionSytem <em>Proplusion Sytem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Proplusion Sytem</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.ProplusionSytem
	 * @generated
	 */
	EClass getProplusionSytem();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.ProplusionSytem#getFuelType <em>Fuel Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Fuel Type</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.ProplusionSytem#getFuelType()
	 * @see #getProplusionSytem()
	 * @generated
	 */
	EAttribute getProplusionSytem_FuelType();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.ProplusionSytem#getEfficiency <em>Efficiency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Efficiency</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.ProplusionSytem#getEfficiency()
	 * @see #getProplusionSytem()
	 * @generated
	 */
	EAttribute getProplusionSytem_Efficiency();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.CommunicationSystem <em>Communication System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Communication System</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.CommunicationSystem
	 * @generated
	 */
	EClass getCommunicationSystem();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.CommunicationSystem#getFrequencyRange <em>Frequency Range</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Frequency Range</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.CommunicationSystem#getFrequencyRange()
	 * @see #getCommunicationSystem()
	 * @generated
	 */
	EAttribute getCommunicationSystem_FrequencyRange();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.CommunicationSystem#getTechnology <em>Technology</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Technology</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.CommunicationSystem#getTechnology()
	 * @see #getCommunicationSystem()
	 * @generated
	 */
	EAttribute getCommunicationSystem_Technology();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces <em>Control Surfaces</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Control Surfaces</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.ControlSurfaces
	 * @generated
	 */
	EClass getControlSurfaces();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getType()
	 * @see #getControlSurfaces()
	 * @generated
	 */
	EAttribute getControlSurfaces_Type();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getArea <em>Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Area</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getArea()
	 * @see #getControlSurfaces()
	 * @generated
	 */
	EAttribute getControlSurfaces_Area();

	/**
	 * Returns the meta object for the containment reference '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getRudder <em>Rudder</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Rudder</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getRudder()
	 * @see #getControlSurfaces()
	 * @generated
	 */
	EReference getControlSurfaces_Rudder();

	/**
	 * Returns the meta object for the containment reference '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getAilleron <em>Ailleron</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Ailleron</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getAilleron()
	 * @see #getControlSurfaces()
	 * @generated
	 */
	EReference getControlSurfaces_Ailleron();

	/**
	 * Returns the meta object for the containment reference '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getElevator <em>Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Elevator</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.ControlSurfaces#getElevator()
	 * @see #getControlSurfaces()
	 * @generated
	 */
	EReference getControlSurfaces_Elevator();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.Rudder <em>Rudder</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Rudder</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Rudder
	 * @generated
	 */
	EClass getRudder();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Rudder#getArea <em>Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Area</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Rudder#getArea()
	 * @see #getRudder()
	 * @generated
	 */
	EAttribute getRudder_Area();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Rudder#getMaxDeflectionAngle <em>Max Deflection Angle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Deflection Angle</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Rudder#getMaxDeflectionAngle()
	 * @see #getRudder()
	 * @generated
	 */
	EAttribute getRudder_MaxDeflectionAngle();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.Elevator <em>Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevator</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Elevator
	 * @generated
	 */
	EClass getElevator();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Elevator#getArea <em>Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Area</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Elevator#getArea()
	 * @see #getElevator()
	 * @generated
	 */
	EAttribute getElevator_Area();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Elevator#getMaxDeflectionAngle <em>Max Deflection Angle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Deflection Angle</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Elevator#getMaxDeflectionAngle()
	 * @see #getElevator()
	 * @generated
	 */
	EAttribute getElevator_MaxDeflectionAngle();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.Ailleron <em>Ailleron</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ailleron</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Ailleron
	 * @generated
	 */
	EClass getAilleron();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Ailleron#getArea <em>Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Area</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Ailleron#getArea()
	 * @see #getAilleron()
	 * @generated
	 */
	EAttribute getAilleron_Area();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.Ailleron#getMaxDeflectionAngle <em>Max Deflection Angle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Deflection Angle</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.Ailleron#getMaxDeflectionAngle()
	 * @see #getAilleron()
	 * @generated
	 */
	EAttribute getAilleron_MaxDeflectionAngle();

	/**
	 * Returns the meta object for class '{@link aircraftsystem.metamodel.aircraftsystem.NavigationSystem <em>Navigation System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Navigation System</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.NavigationSystem
	 * @generated
	 */
	EClass getNavigationSystem();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.NavigationSystem#getTechnology <em>Technology</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Technology</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.NavigationSystem#getTechnology()
	 * @see #getNavigationSystem()
	 * @generated
	 */
	EAttribute getNavigationSystem_Technology();

	/**
	 * Returns the meta object for the attribute '{@link aircraftsystem.metamodel.aircraftsystem.NavigationSystem#getRfeatures <em>Rfeatures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rfeatures</em>'.
	 * @see aircraftsystem.metamodel.aircraftsystem.NavigationSystem#getRfeatures()
	 * @see #getNavigationSystem()
	 * @generated
	 */
	EAttribute getNavigationSystem_Rfeatures();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	AircraftsystemFactory getAircraftsystemFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl <em>Aircraft</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getAircraft()
		 * @generated
		 */
		EClass AIRCRAFT = eINSTANCE.getAircraft();

		/**
		 * The meta object literal for the '<em><b>Model</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AIRCRAFT__MODEL = eINSTANCE.getAircraft_Model();

		/**
		 * The meta object literal for the '<em><b>Max Seed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AIRCRAFT__MAX_SEED = eINSTANCE.getAircraft_MaxSeed();

		/**
		 * The meta object literal for the '<em><b>Wing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AIRCRAFT__WING = eINSTANCE.getAircraft_Wing();

		/**
		 * The meta object literal for the '<em><b>Fuselage</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AIRCRAFT__FUSELAGE = eINSTANCE.getAircraft_Fuselage();

		/**
		 * The meta object literal for the '<em><b>Engine</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AIRCRAFT__ENGINE = eINSTANCE.getAircraft_Engine();

		/**
		 * The meta object literal for the '<em><b>Avionics</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AIRCRAFT__AVIONICS = eINSTANCE.getAircraft_Avionics();

		/**
		 * The meta object literal for the '<em><b>Controlsurfaces</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AIRCRAFT__CONTROLSURFACES = eINSTANCE.getAircraft_Controlsurfaces();

		/**
		 * The meta object literal for the '<em><b>Range</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AIRCRAFT__RANGE = eINSTANCE.getAircraft_Range();

		/**
		 * The meta object literal for the '<em><b>Seating Category</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AIRCRAFT__SEATING_CATEGORY = eINSTANCE.getAircraft_SeatingCategory();

		/**
		 * The meta object literal for the '<em><b>Calculate Performance Metrics</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation AIRCRAFT___CALCULATE_PERFORMANCE_METRICS = eINSTANCE.getAircraft__CalculatePerformanceMetrics();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.WingImpl <em>Wing</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.WingImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getWing()
		 * @generated
		 */
		EClass WING = eINSTANCE.getWing();

		/**
		 * The meta object literal for the '<em><b>Winglllet</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WING__WINGLLLET = eINSTANCE.getWing_Winglllet();

		/**
		 * The meta object literal for the '<em><b>Span</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WING__SPAN = eINSTANCE.getWing_Span();

		/**
		 * The meta object literal for the '<em><b>Sweep Angle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WING__SWEEP_ANGLE = eINSTANCE.getWing_SweepAngle();

		/**
		 * The meta object literal for the '<em><b>Area</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WING__AREA = eINSTANCE.getWing_Area();

		/**
		 * The meta object literal for the '<em><b>Calculate Lift</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation WING___CALCULATE_LIFT = eINSTANCE.getWing__CalculateLift();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.FuselageImpl <em>Fuselage</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.FuselageImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getFuselage()
		 * @generated
		 */
		EClass FUSELAGE = eINSTANCE.getFuselage();

		/**
		 * The meta object literal for the '<em><b>Length</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FUSELAGE__LENGTH = eINSTANCE.getFuselage_Length();

		/**
		 * The meta object literal for the '<em><b>Diameter</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FUSELAGE__DIAMETER = eINSTANCE.getFuselage_Diameter();

		/**
		 * The meta object literal for the '<em><b>Material</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FUSELAGE__MATERIAL = eINSTANCE.getFuselage_Material();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.EngineImpl <em>Engine</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.EngineImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getEngine()
		 * @generated
		 */
		EClass ENGINE = eINSTANCE.getEngine();

		/**
		 * The meta object literal for the '<em><b>Engine Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENGINE__ENGINE_TYPE = eINSTANCE.getEngine_EngineType();

		/**
		 * The meta object literal for the '<em><b>Thrust</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENGINE__THRUST = eINSTANCE.getEngine_Thrust();

		/**
		 * The meta object literal for the '<em><b>Fuel Consumption</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENGINE__FUEL_CONSUMPTION = eINSTANCE.getEngine_FuelConsumption();

		/**
		 * The meta object literal for the '<em><b>Proplusionsytem</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENGINE__PROPLUSIONSYTEM = eINSTANCE.getEngine_Proplusionsytem();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.AvionicsImpl <em>Avionics</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AvionicsImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getAvionics()
		 * @generated
		 */
		EClass AVIONICS = eINSTANCE.getAvionics();

		/**
		 * The meta object literal for the '<em><b>Communicationsystem</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AVIONICS__COMMUNICATIONSYSTEM = eINSTANCE.getAvionics_Communicationsystem();

		/**
		 * The meta object literal for the '<em><b>Manufacturer</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AVIONICS__MANUFACTURER = eINSTANCE.getAvionics_Manufacturer();

		/**
		 * The meta object literal for the '<em><b>Model</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AVIONICS__MODEL = eINSTANCE.getAvionics_Model();

		/**
		 * The meta object literal for the '<em><b>Navigationsystem</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AVIONICS__NAVIGATIONSYSTEM = eINSTANCE.getAvionics_Navigationsystem();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.WingletImpl <em>Winglet</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.WingletImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getWinglet()
		 * @generated
		 */
		EClass WINGLET = eINSTANCE.getWinglet();

		/**
		 * The meta object literal for the '<em><b>Height</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WINGLET__HEIGHT = eINSTANCE.getWinglet_Height();

		/**
		 * The meta object literal for the '<em><b>Angle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WINGLET__ANGLE = eINSTANCE.getWinglet_Angle();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.ProplusionSytemImpl <em>Proplusion Sytem</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.ProplusionSytemImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getProplusionSytem()
		 * @generated
		 */
		EClass PROPLUSION_SYTEM = eINSTANCE.getProplusionSytem();

		/**
		 * The meta object literal for the '<em><b>Fuel Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPLUSION_SYTEM__FUEL_TYPE = eINSTANCE.getProplusionSytem_FuelType();

		/**
		 * The meta object literal for the '<em><b>Efficiency</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPLUSION_SYTEM__EFFICIENCY = eINSTANCE.getProplusionSytem_Efficiency();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.CommunicationSystemImpl <em>Communication System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.CommunicationSystemImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getCommunicationSystem()
		 * @generated
		 */
		EClass COMMUNICATION_SYSTEM = eINSTANCE.getCommunicationSystem();

		/**
		 * The meta object literal for the '<em><b>Frequency Range</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMMUNICATION_SYSTEM__FREQUENCY_RANGE = eINSTANCE.getCommunicationSystem_FrequencyRange();

		/**
		 * The meta object literal for the '<em><b>Technology</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMMUNICATION_SYSTEM__TECHNOLOGY = eINSTANCE.getCommunicationSystem_Technology();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.ControlSurfacesImpl <em>Control Surfaces</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.ControlSurfacesImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getControlSurfaces()
		 * @generated
		 */
		EClass CONTROL_SURFACES = eINSTANCE.getControlSurfaces();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_SURFACES__TYPE = eINSTANCE.getControlSurfaces_Type();

		/**
		 * The meta object literal for the '<em><b>Area</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_SURFACES__AREA = eINSTANCE.getControlSurfaces_Area();

		/**
		 * The meta object literal for the '<em><b>Rudder</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTROL_SURFACES__RUDDER = eINSTANCE.getControlSurfaces_Rudder();

		/**
		 * The meta object literal for the '<em><b>Ailleron</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTROL_SURFACES__AILLERON = eINSTANCE.getControlSurfaces_Ailleron();

		/**
		 * The meta object literal for the '<em><b>Elevator</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTROL_SURFACES__ELEVATOR = eINSTANCE.getControlSurfaces_Elevator();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.RudderImpl <em>Rudder</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.RudderImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getRudder()
		 * @generated
		 */
		EClass RUDDER = eINSTANCE.getRudder();

		/**
		 * The meta object literal for the '<em><b>Area</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RUDDER__AREA = eINSTANCE.getRudder_Area();

		/**
		 * The meta object literal for the '<em><b>Max Deflection Angle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RUDDER__MAX_DEFLECTION_ANGLE = eINSTANCE.getRudder_MaxDeflectionAngle();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.ElevatorImpl <em>Elevator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.ElevatorImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getElevator()
		 * @generated
		 */
		EClass ELEVATOR = eINSTANCE.getElevator();

		/**
		 * The meta object literal for the '<em><b>Area</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATOR__AREA = eINSTANCE.getElevator_Area();

		/**
		 * The meta object literal for the '<em><b>Max Deflection Angle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATOR__MAX_DEFLECTION_ANGLE = eINSTANCE.getElevator_MaxDeflectionAngle();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.AilleronImpl <em>Ailleron</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AilleronImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getAilleron()
		 * @generated
		 */
		EClass AILLERON = eINSTANCE.getAilleron();

		/**
		 * The meta object literal for the '<em><b>Area</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AILLERON__AREA = eINSTANCE.getAilleron_Area();

		/**
		 * The meta object literal for the '<em><b>Max Deflection Angle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AILLERON__MAX_DEFLECTION_ANGLE = eINSTANCE.getAilleron_MaxDeflectionAngle();

		/**
		 * The meta object literal for the '{@link aircraftsystem.metamodel.aircraftsystem.impl.NavigationSystemImpl <em>Navigation System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.NavigationSystemImpl
		 * @see aircraftsystem.metamodel.aircraftsystem.impl.AircraftsystemPackageImpl#getNavigationSystem()
		 * @generated
		 */
		EClass NAVIGATION_SYSTEM = eINSTANCE.getNavigationSystem();

		/**
		 * The meta object literal for the '<em><b>Technology</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAVIGATION_SYSTEM__TECHNOLOGY = eINSTANCE.getNavigationSystem_Technology();

		/**
		 * The meta object literal for the '<em><b>Rfeatures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAVIGATION_SYSTEM__RFEATURES = eINSTANCE.getNavigationSystem_Rfeatures();

	}

} //AircraftsystemPackage
