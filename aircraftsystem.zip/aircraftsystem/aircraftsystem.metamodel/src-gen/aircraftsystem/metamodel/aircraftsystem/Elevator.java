/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Elevator</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Elevator#getArea <em>Area</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Elevator#getMaxDeflectionAngle <em>Max Deflection Angle</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getElevator()
 * @model
 * @generated
 */
public interface Elevator extends EObject {
	/**
	 * Returns the value of the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Area</em>' attribute.
	 * @see #setArea(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getElevator_Area()
	 * @model
	 * @generated
	 */
	double getArea();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Elevator#getArea <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Area</em>' attribute.
	 * @see #getArea()
	 * @generated
	 */
	void setArea(double value);

	/**
	 * Returns the value of the '<em><b>Max Deflection Angle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Deflection Angle</em>' attribute.
	 * @see #setMaxDeflectionAngle(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getElevator_MaxDeflectionAngle()
	 * @model
	 * @generated
	 */
	double getMaxDeflectionAngle();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Elevator#getMaxDeflectionAngle <em>Max Deflection Angle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Deflection Angle</em>' attribute.
	 * @see #getMaxDeflectionAngle()
	 * @generated
	 */
	void setMaxDeflectionAngle(double value);

} // Elevator
