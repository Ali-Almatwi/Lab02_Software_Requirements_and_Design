/**
 */
package aircraftsystem.metamodel.aircraftsystem.util;

import aircraftsystem.metamodel.aircraftsystem.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage
 * @generated
 */
public class AircraftsystemAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static AircraftsystemPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AircraftsystemAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = AircraftsystemPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AircraftsystemSwitch<Adapter> modelSwitch = new AircraftsystemSwitch<Adapter>() {
		@Override
		public Adapter caseAircraft(Aircraft object) {
			return createAircraftAdapter();
		}

		@Override
		public Adapter caseWing(Wing object) {
			return createWingAdapter();
		}

		@Override
		public Adapter caseFuselage(Fuselage object) {
			return createFuselageAdapter();
		}

		@Override
		public Adapter caseEngine(Engine object) {
			return createEngineAdapter();
		}

		@Override
		public Adapter caseAvionics(Avionics object) {
			return createAvionicsAdapter();
		}

		@Override
		public Adapter caseWinglet(Winglet object) {
			return createWingletAdapter();
		}

		@Override
		public Adapter caseProplusionSytem(ProplusionSytem object) {
			return createProplusionSytemAdapter();
		}

		@Override
		public Adapter caseCommunicationSystem(CommunicationSystem object) {
			return createCommunicationSystemAdapter();
		}

		@Override
		public Adapter caseControlSurfaces(ControlSurfaces object) {
			return createControlSurfacesAdapter();
		}

		@Override
		public Adapter caseRudder(Rudder object) {
			return createRudderAdapter();
		}

		@Override
		public Adapter caseElevator(Elevator object) {
			return createElevatorAdapter();
		}

		@Override
		public Adapter caseAilleron(Ailleron object) {
			return createAilleronAdapter();
		}

		@Override
		public Adapter caseNavigationSystem(NavigationSystem object) {
			return createNavigationSystemAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.Aircraft <em>Aircraft</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.Aircraft
	 * @generated
	 */
	public Adapter createAircraftAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.Wing <em>Wing</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.Wing
	 * @generated
	 */
	public Adapter createWingAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.Fuselage <em>Fuselage</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.Fuselage
	 * @generated
	 */
	public Adapter createFuselageAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.Engine <em>Engine</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.Engine
	 * @generated
	 */
	public Adapter createEngineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.Avionics <em>Avionics</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.Avionics
	 * @generated
	 */
	public Adapter createAvionicsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.Winglet <em>Winglet</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.Winglet
	 * @generated
	 */
	public Adapter createWingletAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.ProplusionSytem <em>Proplusion Sytem</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.ProplusionSytem
	 * @generated
	 */
	public Adapter createProplusionSytemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.CommunicationSystem <em>Communication System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.CommunicationSystem
	 * @generated
	 */
	public Adapter createCommunicationSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.ControlSurfaces <em>Control Surfaces</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.ControlSurfaces
	 * @generated
	 */
	public Adapter createControlSurfacesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.Rudder <em>Rudder</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.Rudder
	 * @generated
	 */
	public Adapter createRudderAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.Elevator <em>Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.Elevator
	 * @generated
	 */
	public Adapter createElevatorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.Ailleron <em>Ailleron</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.Ailleron
	 * @generated
	 */
	public Adapter createAilleronAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aircraftsystem.metamodel.aircraftsystem.NavigationSystem <em>Navigation System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aircraftsystem.metamodel.aircraftsystem.NavigationSystem
	 * @generated
	 */
	public Adapter createNavigationSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //AircraftsystemAdapterFactory
