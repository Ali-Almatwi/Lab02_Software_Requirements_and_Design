/**
 */
package aircraftsystem.metamodel.aircraftsystem.util;

import aircraftsystem.metamodel.aircraftsystem.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage
 * @generated
 */
public class AircraftsystemSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static AircraftsystemPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AircraftsystemSwitch() {
		if (modelPackage == null) {
			modelPackage = AircraftsystemPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case AircraftsystemPackage.AIRCRAFT: {
			Aircraft aircraft = (Aircraft) theEObject;
			T result = caseAircraft(aircraft);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.WING: {
			Wing wing = (Wing) theEObject;
			T result = caseWing(wing);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.FUSELAGE: {
			Fuselage fuselage = (Fuselage) theEObject;
			T result = caseFuselage(fuselage);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.ENGINE: {
			Engine engine = (Engine) theEObject;
			T result = caseEngine(engine);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.AVIONICS: {
			Avionics avionics = (Avionics) theEObject;
			T result = caseAvionics(avionics);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.WINGLET: {
			Winglet winglet = (Winglet) theEObject;
			T result = caseWinglet(winglet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.PROPLUSION_SYTEM: {
			ProplusionSytem proplusionSytem = (ProplusionSytem) theEObject;
			T result = caseProplusionSytem(proplusionSytem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.COMMUNICATION_SYSTEM: {
			CommunicationSystem communicationSystem = (CommunicationSystem) theEObject;
			T result = caseCommunicationSystem(communicationSystem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.CONTROL_SURFACES: {
			ControlSurfaces controlSurfaces = (ControlSurfaces) theEObject;
			T result = caseControlSurfaces(controlSurfaces);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.RUDDER: {
			Rudder rudder = (Rudder) theEObject;
			T result = caseRudder(rudder);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.ELEVATOR: {
			Elevator elevator = (Elevator) theEObject;
			T result = caseElevator(elevator);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.AILLERON: {
			Ailleron ailleron = (Ailleron) theEObject;
			T result = caseAilleron(ailleron);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AircraftsystemPackage.NAVIGATION_SYSTEM: {
			NavigationSystem navigationSystem = (NavigationSystem) theEObject;
			T result = caseNavigationSystem(navigationSystem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Aircraft</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Aircraft</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAircraft(Aircraft object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Wing</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Wing</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWing(Wing object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Fuselage</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Fuselage</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFuselage(Fuselage object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Engine</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Engine</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEngine(Engine object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Avionics</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Avionics</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAvionics(Avionics object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Winglet</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Winglet</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWinglet(Winglet object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Proplusion Sytem</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Proplusion Sytem</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseProplusionSytem(ProplusionSytem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Communication System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Communication System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCommunicationSystem(CommunicationSystem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Control Surfaces</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Control Surfaces</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseControlSurfaces(ControlSurfaces object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Rudder</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Rudder</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRudder(Rudder object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Elevator</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Elevator</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseElevator(Elevator object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Ailleron</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Ailleron</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAilleron(Ailleron object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Navigation System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Navigation System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNavigationSystem(NavigationSystem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //AircraftsystemSwitch
