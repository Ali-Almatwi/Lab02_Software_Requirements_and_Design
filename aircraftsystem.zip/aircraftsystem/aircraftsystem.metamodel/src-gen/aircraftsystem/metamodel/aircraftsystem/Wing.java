/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Wing</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Wing#getWinglllet <em>Winglllet</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Wing#getSpan <em>Span</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Wing#getSweepAngle <em>Sweep Angle</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Wing#getArea <em>Area</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getWing()
 * @model
 * @generated
 */
public interface Wing extends EObject {
	/**
	 * Returns the value of the '<em><b>Winglllet</b></em>' containment reference list.
	 * The list contents are of type {@link aircraftsystem.metamodel.aircraftsystem.Winglet}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Winglllet</em>' containment reference list.
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getWing_Winglllet()
	 * @model containment="true"
	 * @generated
	 */
	EList<Winglet> getWinglllet();

	/**
	 * Returns the value of the '<em><b>Span</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Span</em>' attribute.
	 * @see #setSpan(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getWing_Span()
	 * @model default="0.0"
	 * @generated
	 */
	double getSpan();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Wing#getSpan <em>Span</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Span</em>' attribute.
	 * @see #getSpan()
	 * @generated
	 */
	void setSpan(double value);

	/**
	 * Returns the value of the '<em><b>Sweep Angle</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sweep Angle</em>' attribute.
	 * @see #setSweepAngle(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getWing_SweepAngle()
	 * @model default="0.0"
	 * @generated
	 */
	double getSweepAngle();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Wing#getSweepAngle <em>Sweep Angle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sweep Angle</em>' attribute.
	 * @see #getSweepAngle()
	 * @generated
	 */
	void setSweepAngle(double value);

	/**
	 * Returns the value of the '<em><b>Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Area</em>' attribute.
	 * @see #setArea(double)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getWing_Area()
	 * @model
	 * @generated
	 */
	double getArea();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Wing#getArea <em>Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Area</em>' attribute.
	 * @see #getArea()
	 * @generated
	 */
	void setArea(double value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void calculateLift();

} // Wing
