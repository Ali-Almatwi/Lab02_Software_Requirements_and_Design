/**
 */
package aircraftsystem.metamodel.aircraftsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Avionics</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getCommunicationsystem <em>Communicationsystem</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getManufacturer <em>Manufacturer</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getModel <em>Model</em>}</li>
 *   <li>{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getNavigationsystem <em>Navigationsystem</em>}</li>
 * </ul>
 *
 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAvionics()
 * @model
 * @generated
 */
public interface Avionics extends EObject {
	/**
	 * Returns the value of the '<em><b>Communicationsystem</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Communicationsystem</em>' containment reference.
	 * @see #setCommunicationsystem(CommunicationSystem)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAvionics_Communicationsystem()
	 * @model containment="true" required="true"
	 * @generated
	 */
	CommunicationSystem getCommunicationsystem();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getCommunicationsystem <em>Communicationsystem</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Communicationsystem</em>' containment reference.
	 * @see #getCommunicationsystem()
	 * @generated
	 */
	void setCommunicationsystem(CommunicationSystem value);

	/**
	 * Returns the value of the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Manufacturer</em>' attribute.
	 * @see #setManufacturer(String)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAvionics_Manufacturer()
	 * @model
	 * @generated
	 */
	String getManufacturer();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getManufacturer <em>Manufacturer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Manufacturer</em>' attribute.
	 * @see #getManufacturer()
	 * @generated
	 */
	void setManufacturer(String value);

	/**
	 * Returns the value of the '<em><b>Model</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model</em>' attribute.
	 * @see #setModel(String)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAvionics_Model()
	 * @model
	 * @generated
	 */
	String getModel();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getModel <em>Model</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Model</em>' attribute.
	 * @see #getModel()
	 * @generated
	 */
	void setModel(String value);

	/**
	 * Returns the value of the '<em><b>Navigationsystem</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Navigationsystem</em>' containment reference.
	 * @see #setNavigationsystem(NavigationSystem)
	 * @see aircraftsystem.metamodel.aircraftsystem.AircraftsystemPackage#getAvionics_Navigationsystem()
	 * @model containment="true" required="true"
	 * @generated
	 */
	NavigationSystem getNavigationsystem();

	/**
	 * Sets the value of the '{@link aircraftsystem.metamodel.aircraftsystem.Avionics#getNavigationsystem <em>Navigationsystem</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Navigationsystem</em>' containment reference.
	 * @see #getNavigationsystem()
	 * @generated
	 */
	void setNavigationsystem(NavigationSystem value);

} // Avionics
