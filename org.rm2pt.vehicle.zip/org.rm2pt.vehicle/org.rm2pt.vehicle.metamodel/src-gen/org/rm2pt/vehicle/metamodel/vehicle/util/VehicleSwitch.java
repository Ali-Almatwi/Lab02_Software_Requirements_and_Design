/**
 */
package org.rm2pt.vehicle.metamodel.vehicle.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

import org.rm2pt.vehicle.metamodel.vehicle.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage
 * @generated
 */
public class VehicleSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static VehiclePackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleSwitch() {
		if (modelPackage == null) {
			modelPackage = VehiclePackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case VehiclePackage.SUPPORT_ELEMENT: {
			supportElement supportElement = (supportElement) theEObject;
			T result = casesupportElement(supportElement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.CHASSIS: {
			chassis chassis = (chassis) theEObject;
			T result = casechassis(chassis);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.WHEEL: {
			Wheel wheel = (Wheel) theEObject;
			T result = caseWheel(wheel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.CONTROL_ELEMENT: {
			controlElement controlElement = (controlElement) theEObject;
			T result = casecontrolElement(controlElement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.TAX_AREA: {
			taxArea taxArea = (taxArea) theEObject;
			T result = casetaxArea(taxArea);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.SEAT: {
			seat seat = (seat) theEObject;
			T result = caseseat(seat);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.LOUNGE_AREA: {
			loungeArea loungeArea = (loungeArea) theEObject;
			T result = caseloungeArea(loungeArea);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.PERSON: {
			person person = (person) theEObject;
			T result = caseperson(person);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.DOOR: {
			door door = (door) theEObject;
			T result = casedoor(door);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.WINDOW: {
			window window = (window) theEObject;
			T result = casewindow(window);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.SAFETY_DEVICE: {
			safetyDevice safetyDevice = (safetyDevice) theEObject;
			T result = casesafetyDevice(safetyDevice);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.DRIVE: {
			drive drive = (drive) theEObject;
			T result = casedrive(drive);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.MEANSOF_TRANSPORTATION: {
			meansofTransportation meansofTransportation = (meansofTransportation) theEObject;
			T result = casemeansofTransportation(meansofTransportation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.BRAKE: {
			brake brake = (brake) theEObject;
			T result = casebrake(brake);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.VEHICLE_MODEL: {
			vehicleModel vehicleModel = (vehicleModel) theEObject;
			T result = casevehicleModel(vehicleModel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.POWER_TRANSMISSION: {
			powerTransmission powerTransmission = (powerTransmission) theEObject;
			T result = casepowerTransmission(powerTransmission);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.LUGGAGE_RANGE: {
			luggageRange luggageRange = (luggageRange) theEObject;
			T result = caseluggageRange(luggageRange);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case VehiclePackage.INFORMATION_FACILITY: {
			informationFacility informationFacility = (informationFacility) theEObject;
			T result = caseinformationFacility(informationFacility);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>support Element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>support Element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casesupportElement(supportElement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>chassis</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>chassis</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casechassis(chassis object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Wheel</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Wheel</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWheel(Wheel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>control Element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>control Element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casecontrolElement(controlElement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>tax Area</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>tax Area</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casetaxArea(taxArea object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>seat</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>seat</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseseat(seat object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>lounge Area</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>lounge Area</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseloungeArea(loungeArea object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>person</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>person</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseperson(person object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>door</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>door</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casedoor(door object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>window</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>window</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casewindow(window object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>safety Device</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>safety Device</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casesafetyDevice(safetyDevice object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>drive</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>drive</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casedrive(drive object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>meansof Transportation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>meansof Transportation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casemeansofTransportation(meansofTransportation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>brake</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>brake</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casebrake(brake object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>vehicle Model</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>vehicle Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casevehicleModel(vehicleModel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>power Transmission</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>power Transmission</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casepowerTransmission(powerTransmission object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>luggage Range</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>luggage Range</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseluggageRange(luggageRange object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>information Facility</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>information Facility</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseinformationFacility(informationFacility object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //VehicleSwitch
