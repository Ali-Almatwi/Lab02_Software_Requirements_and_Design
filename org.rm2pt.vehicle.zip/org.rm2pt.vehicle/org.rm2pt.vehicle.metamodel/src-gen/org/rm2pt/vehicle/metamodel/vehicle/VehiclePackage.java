/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehicleFactory
 * @model kind="package"
 * @generated
 */
public interface VehiclePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "vehicle";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/vehicle";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "vehicle";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	VehiclePackage eINSTANCE = org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl.init();

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.supportElementImpl <em>support Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.supportElementImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getsupportElement()
	 * @generated
	 */
	int SUPPORT_ELEMENT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORT_ELEMENT__NAME = 0;

	/**
	 * The number of structural features of the '<em>support Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORT_ELEMENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>support Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPORT_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl <em>chassis</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getchassis()
	 * @generated
	 */
	int CHASSIS = 1;

	/**
	 * The feature id for the '<em><b>Accessories</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS__ACCESSORIES = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS__NAME = 1;

	/**
	 * The feature id for the '<em><b>Load Bearing Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS__LOAD_BEARING_ELEMENT = 2;

	/**
	 * The feature id for the '<em><b>Transportrange</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS__TRANSPORTRANGE = 3;

	/**
	 * The feature id for the '<em><b>Window</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS__WINDOW = 4;

	/**
	 * The feature id for the '<em><b>Door</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS__DOOR = 5;

	/**
	 * The feature id for the '<em><b>Informationfacility</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS__INFORMATIONFACILITY = 6;

	/**
	 * The feature id for the '<em><b>Stayingpossibility</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS__STAYINGPOSSIBILITY = 7;

	/**
	 * The feature id for the '<em><b>Sit</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS__SIT = 8;

	/**
	 * The feature id for the '<em><b>Safetydevice</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS__SAFETYDEVICE = 9;

	/**
	 * The number of structural features of the '<em>chassis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS_FEATURE_COUNT = 10;

	/**
	 * The number of operations of the '<em>chassis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHASSIS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.WheelImpl <em>Wheel</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.WheelImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getWheel()
	 * @generated
	 */
	int WHEEL = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHEEL__NAME = 0;

	/**
	 * The feature id for the '<em><b>Fastening</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHEEL__FASTENING = 1;

	/**
	 * The feature id for the '<em><b>Rim</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHEEL__RIM = 2;

	/**
	 * The feature id for the '<em><b>Thread</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHEEL__THREAD = 3;

	/**
	 * The feature id for the '<em><b>Brake</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHEEL__BRAKE = 4;

	/**
	 * The feature id for the '<em><b>Chassis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHEEL__CHASSIS = 5;

	/**
	 * The number of structural features of the '<em>Wheel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHEEL_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Wheel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHEEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.controlElementImpl <em>control Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.controlElementImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getcontrolElement()
	 * @generated
	 */
	int CONTROL_ELEMENT = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_ELEMENT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_ELEMENT__TYPE = 1;

	/**
	 * The number of structural features of the '<em>control Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_ELEMENT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>control Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTROL_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.taxAreaImpl <em>tax Area</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.taxAreaImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#gettaxArea()
	 * @generated
	 */
	int TAX_AREA = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAX_AREA__NAME = 0;

	/**
	 * The feature id for the '<em><b>Controlelement</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAX_AREA__CONTROLELEMENT = 1;

	/**
	 * The feature id for the '<em><b>Informationfacility</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAX_AREA__INFORMATIONFACILITY = 2;

	/**
	 * The feature id for the '<em><b>Door</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAX_AREA__DOOR = 3;

	/**
	 * The feature id for the '<em><b>Safetydevice</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAX_AREA__SAFETYDEVICE = 4;

	/**
	 * The feature id for the '<em><b>Window</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAX_AREA__WINDOW = 5;

	/**
	 * The number of structural features of the '<em>tax Area</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAX_AREA_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>tax Area</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TAX_AREA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.seatImpl <em>seat</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.seatImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getseat()
	 * @generated
	 */
	int SEAT = 5;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEAT__TYPE = 0;

	/**
	 * The number of structural features of the '<em>seat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEAT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>seat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SEAT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.loungeAreaImpl <em>lounge Area</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.loungeAreaImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getloungeArea()
	 * @generated
	 */
	int LOUNGE_AREA = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOUNGE_AREA__NAME = 0;

	/**
	 * The feature id for the '<em><b>Window</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOUNGE_AREA__WINDOW = 1;

	/**
	 * The feature id for the '<em><b>Door</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOUNGE_AREA__DOOR = 2;

	/**
	 * The number of structural features of the '<em>lounge Area</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOUNGE_AREA_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>lounge Area</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOUNGE_AREA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.personImpl <em>person</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.personImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getperson()
	 * @generated
	 */
	int PERSON = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__NAME = 0;

	/**
	 * The feature id for the '<em><b>Seat</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON__SEAT = 1;

	/**
	 * The number of structural features of the '<em>person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERSON_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.doorImpl <em>door</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.doorImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getdoor()
	 * @generated
	 */
	int DOOR = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR__NAME = 0;

	/**
	 * The feature id for the '<em><b>Window</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR__WINDOW = 1;

	/**
	 * The feature id for the '<em><b>Controlelement</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR__CONTROLELEMENT = 2;

	/**
	 * The number of structural features of the '<em>door</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>door</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.windowImpl <em>window</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.windowImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getwindow()
	 * @generated
	 */
	int WINDOW = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WINDOW__NAME = 0;

	/**
	 * The feature id for the '<em><b>Movable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WINDOW__MOVABLE = 1;

	/**
	 * The number of structural features of the '<em>window</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WINDOW_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>window</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WINDOW_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.safetyDeviceImpl <em>safety Device</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.safetyDeviceImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getsafetyDevice()
	 * @generated
	 */
	int SAFETY_DEVICE = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAFETY_DEVICE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAFETY_DEVICE__TYPE = 1;

	/**
	 * The number of structural features of the '<em>safety Device</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAFETY_DEVICE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>safety Device</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAFETY_DEVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.driveImpl <em>drive</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.driveImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getdrive()
	 * @generated
	 */
	int DRIVE = 11;

	/**
	 * The feature id for the '<em><b>Fuel</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE__FUEL = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE__NAME = 1;

	/**
	 * The number of structural features of the '<em>drive</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>drive</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl <em>meansof Transportation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getmeansofTransportation()
	 * @generated
	 */
	int MEANSOF_TRANSPORTATION = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEANSOF_TRANSPORTATION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Chassis</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEANSOF_TRANSPORTATION__CHASSIS = 1;

	/**
	 * The feature id for the '<em><b>Person</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEANSOF_TRANSPORTATION__PERSON = 2;

	/**
	 * The feature id for the '<em><b>Powertransmission</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEANSOF_TRANSPORTATION__POWERTRANSMISSION = 3;

	/**
	 * The feature id for the '<em><b>Drive</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEANSOF_TRANSPORTATION__DRIVE = 4;

	/**
	 * The feature id for the '<em><b>Namufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEANSOF_TRANSPORTATION__NAMUFACTURER = 5;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEANSOF_TRANSPORTATION__PRICE = 6;

	/**
	 * The feature id for the '<em><b>Wheel</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEANSOF_TRANSPORTATION__WHEEL = 7;

	/**
	 * The number of structural features of the '<em>meansof Transportation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEANSOF_TRANSPORTATION_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>meansof Transportation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEANSOF_TRANSPORTATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.brakeImpl <em>brake</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.brakeImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getbrake()
	 * @generated
	 */
	int BRAKE = 13;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BRAKE__TYPE = 0;

	/**
	 * The number of structural features of the '<em>brake</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BRAKE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>brake</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BRAKE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.vehicleModelImpl <em>vehicle Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.vehicleModelImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getvehicleModel()
	 * @generated
	 */
	int VEHICLE_MODEL = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_MODEL__NAME = 0;

	/**
	 * The feature id for the '<em><b>Meansoftransportation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_MODEL__MEANSOFTRANSPORTATION = 1;

	/**
	 * The number of structural features of the '<em>vehicle Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_MODEL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>vehicle Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VEHICLE_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.powerTransmissionImpl <em>power Transmission</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.powerTransmissionImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getpowerTransmission()
	 * @generated
	 */
	int POWER_TRANSMISSION = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POWER_TRANSMISSION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Wide</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POWER_TRANSMISSION__WIDE = 1;

	/**
	 * The number of structural features of the '<em>power Transmission</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POWER_TRANSMISSION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>power Transmission</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POWER_TRANSMISSION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.luggageRangeImpl <em>luggage Range</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.luggageRangeImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getluggageRange()
	 * @generated
	 */
	int LUGGAGE_RANGE = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUGGAGE_RANGE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Window</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUGGAGE_RANGE__WINDOW = 1;

	/**
	 * The feature id for the '<em><b>Door</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUGGAGE_RANGE__DOOR = 2;

	/**
	 * The number of structural features of the '<em>luggage Range</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUGGAGE_RANGE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>luggage Range</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUGGAGE_RANGE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.informationFacilityImpl <em>information Facility</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.informationFacilityImpl
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getinformationFacility()
	 * @generated
	 */
	int INFORMATION_FACILITY = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_FACILITY__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_FACILITY__TYPE = 1;

	/**
	 * The number of structural features of the '<em>information Facility</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_FACILITY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>information Facility</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFORMATION_FACILITY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories <em>exterior Accessories</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getexteriorAccessories()
	 * @generated
	 */
	int EXTERIOR_ACCESSORIES = 18;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.taxType <em>tax Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxType
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#gettaxType()
	 * @generated
	 */
	int TAX_TYPE = 19;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.seatType <em>seat Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.seatType
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getseatType()
	 * @generated
	 */
	int SEAT_TYPE = 20;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.InfoArt <em>Info Art</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.InfoArt
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getInfoArt()
	 * @generated
	 */
	int INFO_ART = 21;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.fuelType <em>fuel Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.fuelType
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getfuelType()
	 * @generated
	 */
	int FUEL_TYPE = 22;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.brakeType <em>brake Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.brakeType
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getbrakeType()
	 * @generated
	 */
	int BRAKE_TYPE = 23;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.safetyType <em>safety Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.safetyType
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getsafetyType()
	 * @generated
	 */
	int SAFETY_TYPE = 24;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.design <em>design</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.design
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getdesign()
	 * @generated
	 */
	int DESIGN = 25;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.rimType <em>rim Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.rimType
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getrimType()
	 * @generated
	 */
	int RIM_TYPE = 26;

	/**
	 * The meta object id for the '{@link org.rm2pt.vehicle.metamodel.vehicle.threadType <em>thread Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.vehicle.metamodel.vehicle.threadType
	 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getthreadType()
	 * @generated
	 */
	int THREAD_TYPE = 27;

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.supportElement <em>support Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>support Element</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.supportElement
	 * @generated
	 */
	EClass getsupportElement();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.supportElement#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.supportElement#getName()
	 * @see #getsupportElement()
	 * @generated
	 */
	EAttribute getsupportElement_Name();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis <em>chassis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>chassis</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis
	 * @generated
	 */
	EClass getchassis();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getAccessories <em>Accessories</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Accessories</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis#getAccessories()
	 * @see #getchassis()
	 * @generated
	 */
	EAttribute getchassis_Accessories();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis#getName()
	 * @see #getchassis()
	 * @generated
	 */
	EAttribute getchassis_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getLoadBearingElement <em>Load Bearing Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Load Bearing Element</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis#getLoadBearingElement()
	 * @see #getchassis()
	 * @generated
	 */
	EReference getchassis_LoadBearingElement();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getTransportrange <em>Transportrange</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Transportrange</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis#getTransportrange()
	 * @see #getchassis()
	 * @generated
	 */
	EReference getchassis_Transportrange();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getWindow <em>Window</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Window</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis#getWindow()
	 * @see #getchassis()
	 * @generated
	 */
	EReference getchassis_Window();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getDoor <em>Door</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Door</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis#getDoor()
	 * @see #getchassis()
	 * @generated
	 */
	EReference getchassis_Door();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getInformationfacility <em>Informationfacility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Informationfacility</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis#getInformationfacility()
	 * @see #getchassis()
	 * @generated
	 */
	EReference getchassis_Informationfacility();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getStayingpossibility <em>Stayingpossibility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Stayingpossibility</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis#getStayingpossibility()
	 * @see #getchassis()
	 * @generated
	 */
	EReference getchassis_Stayingpossibility();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getSit <em>Sit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sit</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis#getSit()
	 * @see #getchassis()
	 * @generated
	 */
	EReference getchassis_Sit();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getSafetydevice <em>Safetydevice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Safetydevice</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis#getSafetydevice()
	 * @see #getchassis()
	 * @generated
	 */
	EReference getchassis_Safetydevice();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel <em>Wheel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Wheel</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.Wheel
	 * @generated
	 */
	EClass getWheel();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.Wheel#getName()
	 * @see #getWheel()
	 * @generated
	 */
	EAttribute getWheel_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getFastening <em>Fastening</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Fastening</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.Wheel#getFastening()
	 * @see #getWheel()
	 * @generated
	 */
	EAttribute getWheel_Fastening();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getRim <em>Rim</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rim</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.Wheel#getRim()
	 * @see #getWheel()
	 * @generated
	 */
	EAttribute getWheel_Rim();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getThread <em>Thread</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Thread</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.Wheel#getThread()
	 * @see #getWheel()
	 * @generated
	 */
	EAttribute getWheel_Thread();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getBrake <em>Brake</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Brake</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.Wheel#getBrake()
	 * @see #getWheel()
	 * @generated
	 */
	EReference getWheel_Brake();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getChassis <em>Chassis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Chassis</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.Wheel#getChassis()
	 * @see #getWheel()
	 * @generated
	 */
	EReference getWheel_Chassis();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.controlElement <em>control Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>control Element</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.controlElement
	 * @generated
	 */
	EClass getcontrolElement();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.controlElement#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.controlElement#getName()
	 * @see #getcontrolElement()
	 * @generated
	 */
	EAttribute getcontrolElement_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.controlElement#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.controlElement#getType()
	 * @see #getcontrolElement()
	 * @generated
	 */
	EAttribute getcontrolElement_Type();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea <em>tax Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>tax Area</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxArea
	 * @generated
	 */
	EClass gettaxArea();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxArea#getName()
	 * @see #gettaxArea()
	 * @generated
	 */
	EAttribute gettaxArea_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getControlelement <em>Controlelement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Controlelement</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxArea#getControlelement()
	 * @see #gettaxArea()
	 * @generated
	 */
	EReference gettaxArea_Controlelement();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getInformationfacility <em>Informationfacility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Informationfacility</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxArea#getInformationfacility()
	 * @see #gettaxArea()
	 * @generated
	 */
	EReference gettaxArea_Informationfacility();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getDoor <em>Door</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Door</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxArea#getDoor()
	 * @see #gettaxArea()
	 * @generated
	 */
	EReference gettaxArea_Door();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getSafetydevice <em>Safetydevice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Safetydevice</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxArea#getSafetydevice()
	 * @see #gettaxArea()
	 * @generated
	 */
	EReference gettaxArea_Safetydevice();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getWindow <em>Window</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Window</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxArea#getWindow()
	 * @see #gettaxArea()
	 * @generated
	 */
	EReference gettaxArea_Window();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.seat <em>seat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>seat</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.seat
	 * @generated
	 */
	EClass getseat();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.seat#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.seat#getType()
	 * @see #getseat()
	 * @generated
	 */
	EAttribute getseat_Type();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.loungeArea <em>lounge Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>lounge Area</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.loungeArea
	 * @generated
	 */
	EClass getloungeArea();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.loungeArea#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.loungeArea#getName()
	 * @see #getloungeArea()
	 * @generated
	 */
	EAttribute getloungeArea_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.loungeArea#getWindow <em>Window</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Window</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.loungeArea#getWindow()
	 * @see #getloungeArea()
	 * @generated
	 */
	EReference getloungeArea_Window();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.loungeArea#getDoor <em>Door</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Door</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.loungeArea#getDoor()
	 * @see #getloungeArea()
	 * @generated
	 */
	EReference getloungeArea_Door();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.person <em>person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>person</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.person
	 * @generated
	 */
	EClass getperson();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.person#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.person#getName()
	 * @see #getperson()
	 * @generated
	 */
	EAttribute getperson_Name();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.vehicle.metamodel.vehicle.person#getSeat <em>Seat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Seat</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.person#getSeat()
	 * @see #getperson()
	 * @generated
	 */
	EReference getperson_Seat();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.door <em>door</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>door</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.door
	 * @generated
	 */
	EClass getdoor();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.door#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.door#getName()
	 * @see #getdoor()
	 * @generated
	 */
	EAttribute getdoor_Name();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.vehicle.metamodel.vehicle.door#getWindow <em>Window</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Window</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.door#getWindow()
	 * @see #getdoor()
	 * @generated
	 */
	EReference getdoor_Window();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.door#getControlelement <em>Controlelement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Controlelement</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.door#getControlelement()
	 * @see #getdoor()
	 * @generated
	 */
	EReference getdoor_Controlelement();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.window <em>window</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>window</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.window
	 * @generated
	 */
	EClass getwindow();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.window#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.window#getName()
	 * @see #getwindow()
	 * @generated
	 */
	EAttribute getwindow_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.window#isMovable <em>Movable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Movable</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.window#isMovable()
	 * @see #getwindow()
	 * @generated
	 */
	EAttribute getwindow_Movable();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.safetyDevice <em>safety Device</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>safety Device</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.safetyDevice
	 * @generated
	 */
	EClass getsafetyDevice();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.safetyDevice#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.safetyDevice#getName()
	 * @see #getsafetyDevice()
	 * @generated
	 */
	EAttribute getsafetyDevice_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.safetyDevice#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.safetyDevice#getType()
	 * @see #getsafetyDevice()
	 * @generated
	 */
	EAttribute getsafetyDevice_Type();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.drive <em>drive</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>drive</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.drive
	 * @generated
	 */
	EClass getdrive();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.drive#getFuel <em>Fuel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Fuel</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.drive#getFuel()
	 * @see #getdrive()
	 * @generated
	 */
	EAttribute getdrive_Fuel();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.drive#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.drive#getName()
	 * @see #getdrive()
	 * @generated
	 */
	EAttribute getdrive_Name();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation <em>meansof Transportation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>meansof Transportation</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation
	 * @generated
	 */
	EClass getmeansofTransportation();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getName()
	 * @see #getmeansofTransportation()
	 * @generated
	 */
	EAttribute getmeansofTransportation_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getChassis <em>Chassis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Chassis</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getChassis()
	 * @see #getmeansofTransportation()
	 * @generated
	 */
	EReference getmeansofTransportation_Chassis();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getPerson <em>Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Person</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getPerson()
	 * @see #getmeansofTransportation()
	 * @generated
	 */
	EReference getmeansofTransportation_Person();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getPowertransmission <em>Powertransmission</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Powertransmission</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getPowertransmission()
	 * @see #getmeansofTransportation()
	 * @generated
	 */
	EReference getmeansofTransportation_Powertransmission();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getDrive <em>Drive</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Drive</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getDrive()
	 * @see #getmeansofTransportation()
	 * @generated
	 */
	EReference getmeansofTransportation_Drive();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getNamufacturer <em>Namufacturer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Namufacturer</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getNamufacturer()
	 * @see #getmeansofTransportation()
	 * @generated
	 */
	EAttribute getmeansofTransportation_Namufacturer();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getPrice <em>Price</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Price</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getPrice()
	 * @see #getmeansofTransportation()
	 * @generated
	 */
	EAttribute getmeansofTransportation_Price();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getWheel <em>Wheel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Wheel</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getWheel()
	 * @see #getmeansofTransportation()
	 * @generated
	 */
	EReference getmeansofTransportation_Wheel();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.brake <em>brake</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>brake</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.brake
	 * @generated
	 */
	EClass getbrake();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.brake#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.brake#getType()
	 * @see #getbrake()
	 * @generated
	 */
	EAttribute getbrake_Type();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.vehicleModel <em>vehicle Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>vehicle Model</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.vehicleModel
	 * @generated
	 */
	EClass getvehicleModel();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.vehicleModel#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.vehicleModel#getName()
	 * @see #getvehicleModel()
	 * @generated
	 */
	EAttribute getvehicleModel_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.vehicleModel#getMeansoftransportation <em>Meansoftransportation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Meansoftransportation</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.vehicleModel#getMeansoftransportation()
	 * @see #getvehicleModel()
	 * @generated
	 */
	EReference getvehicleModel_Meansoftransportation();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.powerTransmission <em>power Transmission</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>power Transmission</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.powerTransmission
	 * @generated
	 */
	EClass getpowerTransmission();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.powerTransmission#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.powerTransmission#getName()
	 * @see #getpowerTransmission()
	 * @generated
	 */
	EAttribute getpowerTransmission_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.powerTransmission#isWide <em>Wide</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Wide</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.powerTransmission#isWide()
	 * @see #getpowerTransmission()
	 * @generated
	 */
	EAttribute getpowerTransmission_Wide();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.luggageRange <em>luggage Range</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>luggage Range</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.luggageRange
	 * @generated
	 */
	EClass getluggageRange();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.luggageRange#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.luggageRange#getName()
	 * @see #getluggageRange()
	 * @generated
	 */
	EAttribute getluggageRange_Name();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.luggageRange#getWindow <em>Window</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Window</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.luggageRange#getWindow()
	 * @see #getluggageRange()
	 * @generated
	 */
	EReference getluggageRange_Window();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.vehicle.metamodel.vehicle.luggageRange#getDoor <em>Door</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Door</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.luggageRange#getDoor()
	 * @see #getluggageRange()
	 * @generated
	 */
	EReference getluggageRange_Door();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.vehicle.metamodel.vehicle.informationFacility <em>information Facility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>information Facility</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.informationFacility
	 * @generated
	 */
	EClass getinformationFacility();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.informationFacility#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.informationFacility#getName()
	 * @see #getinformationFacility()
	 * @generated
	 */
	EAttribute getinformationFacility_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.vehicle.metamodel.vehicle.informationFacility#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.informationFacility#getType()
	 * @see #getinformationFacility()
	 * @generated
	 */
	EAttribute getinformationFacility_Type();

	/**
	 * Returns the meta object for enum '{@link org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories <em>exterior Accessories</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>exterior Accessories</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories
	 * @generated
	 */
	EEnum getexteriorAccessories();

	/**
	 * Returns the meta object for enum '{@link org.rm2pt.vehicle.metamodel.vehicle.taxType <em>tax Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>tax Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxType
	 * @generated
	 */
	EEnum gettaxType();

	/**
	 * Returns the meta object for enum '{@link org.rm2pt.vehicle.metamodel.vehicle.seatType <em>seat Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>seat Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.seatType
	 * @generated
	 */
	EEnum getseatType();

	/**
	 * Returns the meta object for enum '{@link org.rm2pt.vehicle.metamodel.vehicle.InfoArt <em>Info Art</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Info Art</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.InfoArt
	 * @generated
	 */
	EEnum getInfoArt();

	/**
	 * Returns the meta object for enum '{@link org.rm2pt.vehicle.metamodel.vehicle.fuelType <em>fuel Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>fuel Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.fuelType
	 * @generated
	 */
	EEnum getfuelType();

	/**
	 * Returns the meta object for enum '{@link org.rm2pt.vehicle.metamodel.vehicle.brakeType <em>brake Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>brake Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.brakeType
	 * @generated
	 */
	EEnum getbrakeType();

	/**
	 * Returns the meta object for enum '{@link org.rm2pt.vehicle.metamodel.vehicle.safetyType <em>safety Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>safety Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.safetyType
	 * @generated
	 */
	EEnum getsafetyType();

	/**
	 * Returns the meta object for enum '{@link org.rm2pt.vehicle.metamodel.vehicle.design <em>design</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>design</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.design
	 * @generated
	 */
	EEnum getdesign();

	/**
	 * Returns the meta object for enum '{@link org.rm2pt.vehicle.metamodel.vehicle.rimType <em>rim Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>rim Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.rimType
	 * @generated
	 */
	EEnum getrimType();

	/**
	 * Returns the meta object for enum '{@link org.rm2pt.vehicle.metamodel.vehicle.threadType <em>thread Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>thread Type</em>'.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.threadType
	 * @generated
	 */
	EEnum getthreadType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	VehicleFactory getVehicleFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.supportElementImpl <em>support Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.supportElementImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getsupportElement()
		 * @generated
		 */
		EClass SUPPORT_ELEMENT = eINSTANCE.getsupportElement();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUPPORT_ELEMENT__NAME = eINSTANCE.getsupportElement_Name();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl <em>chassis</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getchassis()
		 * @generated
		 */
		EClass CHASSIS = eINSTANCE.getchassis();

		/**
		 * The meta object literal for the '<em><b>Accessories</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CHASSIS__ACCESSORIES = eINSTANCE.getchassis_Accessories();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CHASSIS__NAME = eINSTANCE.getchassis_Name();

		/**
		 * The meta object literal for the '<em><b>Load Bearing Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHASSIS__LOAD_BEARING_ELEMENT = eINSTANCE.getchassis_LoadBearingElement();

		/**
		 * The meta object literal for the '<em><b>Transportrange</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHASSIS__TRANSPORTRANGE = eINSTANCE.getchassis_Transportrange();

		/**
		 * The meta object literal for the '<em><b>Window</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHASSIS__WINDOW = eINSTANCE.getchassis_Window();

		/**
		 * The meta object literal for the '<em><b>Door</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHASSIS__DOOR = eINSTANCE.getchassis_Door();

		/**
		 * The meta object literal for the '<em><b>Informationfacility</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHASSIS__INFORMATIONFACILITY = eINSTANCE.getchassis_Informationfacility();

		/**
		 * The meta object literal for the '<em><b>Stayingpossibility</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHASSIS__STAYINGPOSSIBILITY = eINSTANCE.getchassis_Stayingpossibility();

		/**
		 * The meta object literal for the '<em><b>Sit</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHASSIS__SIT = eINSTANCE.getchassis_Sit();

		/**
		 * The meta object literal for the '<em><b>Safetydevice</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHASSIS__SAFETYDEVICE = eINSTANCE.getchassis_Safetydevice();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.WheelImpl <em>Wheel</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.WheelImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getWheel()
		 * @generated
		 */
		EClass WHEEL = eINSTANCE.getWheel();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WHEEL__NAME = eINSTANCE.getWheel_Name();

		/**
		 * The meta object literal for the '<em><b>Fastening</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WHEEL__FASTENING = eINSTANCE.getWheel_Fastening();

		/**
		 * The meta object literal for the '<em><b>Rim</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WHEEL__RIM = eINSTANCE.getWheel_Rim();

		/**
		 * The meta object literal for the '<em><b>Thread</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WHEEL__THREAD = eINSTANCE.getWheel_Thread();

		/**
		 * The meta object literal for the '<em><b>Brake</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WHEEL__BRAKE = eINSTANCE.getWheel_Brake();

		/**
		 * The meta object literal for the '<em><b>Chassis</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WHEEL__CHASSIS = eINSTANCE.getWheel_Chassis();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.controlElementImpl <em>control Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.controlElementImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getcontrolElement()
		 * @generated
		 */
		EClass CONTROL_ELEMENT = eINSTANCE.getcontrolElement();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_ELEMENT__NAME = eINSTANCE.getcontrolElement_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTROL_ELEMENT__TYPE = eINSTANCE.getcontrolElement_Type();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.taxAreaImpl <em>tax Area</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.taxAreaImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#gettaxArea()
		 * @generated
		 */
		EClass TAX_AREA = eINSTANCE.gettaxArea();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TAX_AREA__NAME = eINSTANCE.gettaxArea_Name();

		/**
		 * The meta object literal for the '<em><b>Controlelement</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAX_AREA__CONTROLELEMENT = eINSTANCE.gettaxArea_Controlelement();

		/**
		 * The meta object literal for the '<em><b>Informationfacility</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAX_AREA__INFORMATIONFACILITY = eINSTANCE.gettaxArea_Informationfacility();

		/**
		 * The meta object literal for the '<em><b>Door</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAX_AREA__DOOR = eINSTANCE.gettaxArea_Door();

		/**
		 * The meta object literal for the '<em><b>Safetydevice</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAX_AREA__SAFETYDEVICE = eINSTANCE.gettaxArea_Safetydevice();

		/**
		 * The meta object literal for the '<em><b>Window</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TAX_AREA__WINDOW = eINSTANCE.gettaxArea_Window();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.seatImpl <em>seat</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.seatImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getseat()
		 * @generated
		 */
		EClass SEAT = eINSTANCE.getseat();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SEAT__TYPE = eINSTANCE.getseat_Type();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.loungeAreaImpl <em>lounge Area</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.loungeAreaImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getloungeArea()
		 * @generated
		 */
		EClass LOUNGE_AREA = eINSTANCE.getloungeArea();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOUNGE_AREA__NAME = eINSTANCE.getloungeArea_Name();

		/**
		 * The meta object literal for the '<em><b>Window</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOUNGE_AREA__WINDOW = eINSTANCE.getloungeArea_Window();

		/**
		 * The meta object literal for the '<em><b>Door</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LOUNGE_AREA__DOOR = eINSTANCE.getloungeArea_Door();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.personImpl <em>person</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.personImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getperson()
		 * @generated
		 */
		EClass PERSON = eINSTANCE.getperson();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERSON__NAME = eINSTANCE.getperson_Name();

		/**
		 * The meta object literal for the '<em><b>Seat</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERSON__SEAT = eINSTANCE.getperson_Seat();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.doorImpl <em>door</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.doorImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getdoor()
		 * @generated
		 */
		EClass DOOR = eINSTANCE.getdoor();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOOR__NAME = eINSTANCE.getdoor_Name();

		/**
		 * The meta object literal for the '<em><b>Window</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOOR__WINDOW = eINSTANCE.getdoor_Window();

		/**
		 * The meta object literal for the '<em><b>Controlelement</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOOR__CONTROLELEMENT = eINSTANCE.getdoor_Controlelement();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.windowImpl <em>window</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.windowImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getwindow()
		 * @generated
		 */
		EClass WINDOW = eINSTANCE.getwindow();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WINDOW__NAME = eINSTANCE.getwindow_Name();

		/**
		 * The meta object literal for the '<em><b>Movable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WINDOW__MOVABLE = eINSTANCE.getwindow_Movable();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.safetyDeviceImpl <em>safety Device</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.safetyDeviceImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getsafetyDevice()
		 * @generated
		 */
		EClass SAFETY_DEVICE = eINSTANCE.getsafetyDevice();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SAFETY_DEVICE__NAME = eINSTANCE.getsafetyDevice_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SAFETY_DEVICE__TYPE = eINSTANCE.getsafetyDevice_Type();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.driveImpl <em>drive</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.driveImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getdrive()
		 * @generated
		 */
		EClass DRIVE = eINSTANCE.getdrive();

		/**
		 * The meta object literal for the '<em><b>Fuel</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRIVE__FUEL = eINSTANCE.getdrive_Fuel();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRIVE__NAME = eINSTANCE.getdrive_Name();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl <em>meansof Transportation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getmeansofTransportation()
		 * @generated
		 */
		EClass MEANSOF_TRANSPORTATION = eINSTANCE.getmeansofTransportation();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEANSOF_TRANSPORTATION__NAME = eINSTANCE.getmeansofTransportation_Name();

		/**
		 * The meta object literal for the '<em><b>Chassis</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MEANSOF_TRANSPORTATION__CHASSIS = eINSTANCE.getmeansofTransportation_Chassis();

		/**
		 * The meta object literal for the '<em><b>Person</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MEANSOF_TRANSPORTATION__PERSON = eINSTANCE.getmeansofTransportation_Person();

		/**
		 * The meta object literal for the '<em><b>Powertransmission</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MEANSOF_TRANSPORTATION__POWERTRANSMISSION = eINSTANCE.getmeansofTransportation_Powertransmission();

		/**
		 * The meta object literal for the '<em><b>Drive</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MEANSOF_TRANSPORTATION__DRIVE = eINSTANCE.getmeansofTransportation_Drive();

		/**
		 * The meta object literal for the '<em><b>Namufacturer</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEANSOF_TRANSPORTATION__NAMUFACTURER = eINSTANCE.getmeansofTransportation_Namufacturer();

		/**
		 * The meta object literal for the '<em><b>Price</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEANSOF_TRANSPORTATION__PRICE = eINSTANCE.getmeansofTransportation_Price();

		/**
		 * The meta object literal for the '<em><b>Wheel</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MEANSOF_TRANSPORTATION__WHEEL = eINSTANCE.getmeansofTransportation_Wheel();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.brakeImpl <em>brake</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.brakeImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getbrake()
		 * @generated
		 */
		EClass BRAKE = eINSTANCE.getbrake();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BRAKE__TYPE = eINSTANCE.getbrake_Type();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.vehicleModelImpl <em>vehicle Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.vehicleModelImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getvehicleModel()
		 * @generated
		 */
		EClass VEHICLE_MODEL = eINSTANCE.getvehicleModel();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VEHICLE_MODEL__NAME = eINSTANCE.getvehicleModel_Name();

		/**
		 * The meta object literal for the '<em><b>Meansoftransportation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VEHICLE_MODEL__MEANSOFTRANSPORTATION = eINSTANCE.getvehicleModel_Meansoftransportation();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.powerTransmissionImpl <em>power Transmission</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.powerTransmissionImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getpowerTransmission()
		 * @generated
		 */
		EClass POWER_TRANSMISSION = eINSTANCE.getpowerTransmission();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POWER_TRANSMISSION__NAME = eINSTANCE.getpowerTransmission_Name();

		/**
		 * The meta object literal for the '<em><b>Wide</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POWER_TRANSMISSION__WIDE = eINSTANCE.getpowerTransmission_Wide();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.luggageRangeImpl <em>luggage Range</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.luggageRangeImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getluggageRange()
		 * @generated
		 */
		EClass LUGGAGE_RANGE = eINSTANCE.getluggageRange();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LUGGAGE_RANGE__NAME = eINSTANCE.getluggageRange_Name();

		/**
		 * The meta object literal for the '<em><b>Window</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LUGGAGE_RANGE__WINDOW = eINSTANCE.getluggageRange_Window();

		/**
		 * The meta object literal for the '<em><b>Door</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LUGGAGE_RANGE__DOOR = eINSTANCE.getluggageRange_Door();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.impl.informationFacilityImpl <em>information Facility</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.informationFacilityImpl
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getinformationFacility()
		 * @generated
		 */
		EClass INFORMATION_FACILITY = eINSTANCE.getinformationFacility();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFORMATION_FACILITY__NAME = eINSTANCE.getinformationFacility_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INFORMATION_FACILITY__TYPE = eINSTANCE.getinformationFacility_Type();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories <em>exterior Accessories</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getexteriorAccessories()
		 * @generated
		 */
		EEnum EXTERIOR_ACCESSORIES = eINSTANCE.getexteriorAccessories();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.taxType <em>tax Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.taxType
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#gettaxType()
		 * @generated
		 */
		EEnum TAX_TYPE = eINSTANCE.gettaxType();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.seatType <em>seat Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.seatType
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getseatType()
		 * @generated
		 */
		EEnum SEAT_TYPE = eINSTANCE.getseatType();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.InfoArt <em>Info Art</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.InfoArt
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getInfoArt()
		 * @generated
		 */
		EEnum INFO_ART = eINSTANCE.getInfoArt();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.fuelType <em>fuel Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.fuelType
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getfuelType()
		 * @generated
		 */
		EEnum FUEL_TYPE = eINSTANCE.getfuelType();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.brakeType <em>brake Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.brakeType
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getbrakeType()
		 * @generated
		 */
		EEnum BRAKE_TYPE = eINSTANCE.getbrakeType();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.safetyType <em>safety Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.safetyType
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getsafetyType()
		 * @generated
		 */
		EEnum SAFETY_TYPE = eINSTANCE.getsafetyType();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.design <em>design</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.design
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getdesign()
		 * @generated
		 */
		EEnum DESIGN = eINSTANCE.getdesign();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.rimType <em>rim Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.rimType
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getrimType()
		 * @generated
		 */
		EEnum RIM_TYPE = eINSTANCE.getrimType();

		/**
		 * The meta object literal for the '{@link org.rm2pt.vehicle.metamodel.vehicle.threadType <em>thread Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.vehicle.metamodel.vehicle.threadType
		 * @see org.rm2pt.vehicle.metamodel.vehicle.impl.VehiclePackageImpl#getthreadType()
		 * @generated
		 */
		EEnum THREAD_TYPE = eINSTANCE.getthreadType();

	}

} //VehiclePackage
