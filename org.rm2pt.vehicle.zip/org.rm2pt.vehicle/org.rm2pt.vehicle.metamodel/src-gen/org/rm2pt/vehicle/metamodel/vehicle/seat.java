/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>seat</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.seat#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getseat()
 * @model
 * @generated
 */
public interface seat extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link org.rm2pt.vehicle.metamodel.vehicle.seatType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.seatType
	 * @see #setType(seatType)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getseat_Type()
	 * @model
	 * @generated
	 */
	seatType getType();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.seat#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.seatType
	 * @see #getType()
	 * @generated
	 */
	void setType(seatType value);

} // seat
