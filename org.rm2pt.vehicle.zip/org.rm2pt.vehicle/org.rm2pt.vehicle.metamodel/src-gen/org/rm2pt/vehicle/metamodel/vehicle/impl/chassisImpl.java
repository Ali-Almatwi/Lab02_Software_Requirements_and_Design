/**
 */
package org.rm2pt.vehicle.metamodel.vehicle.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage;
import org.rm2pt.vehicle.metamodel.vehicle.chassis;
import org.rm2pt.vehicle.metamodel.vehicle.door;
import org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories;
import org.rm2pt.vehicle.metamodel.vehicle.informationFacility;
import org.rm2pt.vehicle.metamodel.vehicle.loungeArea;
import org.rm2pt.vehicle.metamodel.vehicle.luggageRange;
import org.rm2pt.vehicle.metamodel.vehicle.safetyDevice;
import org.rm2pt.vehicle.metamodel.vehicle.seat;
import org.rm2pt.vehicle.metamodel.vehicle.supportElement;
import org.rm2pt.vehicle.metamodel.vehicle.window;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>chassis</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl#getAccessories <em>Accessories</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl#getLoadBearingElement <em>Load Bearing Element</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl#getTransportrange <em>Transportrange</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl#getWindow <em>Window</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl#getDoor <em>Door</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl#getInformationfacility <em>Informationfacility</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl#getStayingpossibility <em>Stayingpossibility</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl#getSit <em>Sit</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.chassisImpl#getSafetydevice <em>Safetydevice</em>}</li>
 * </ul>
 *
 * @generated
 */
public class chassisImpl extends MinimalEObjectImpl.Container implements chassis {
	/**
	 * The default value of the '{@link #getAccessories() <em>Accessories</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccessories()
	 * @generated
	 * @ordered
	 */
	protected static final exteriorAccessories ACCESSORIES_EDEFAULT = exteriorAccessories.CAMERA;

	/**
	 * The cached value of the '{@link #getAccessories() <em>Accessories</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAccessories()
	 * @generated
	 * @ordered
	 */
	protected exteriorAccessories accessories = ACCESSORIES_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getLoadBearingElement() <em>Load Bearing Element</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLoadBearingElement()
	 * @generated
	 * @ordered
	 */
	protected EList<supportElement> loadBearingElement;

	/**
	 * The cached value of the '{@link #getTransportrange() <em>Transportrange</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransportrange()
	 * @generated
	 * @ordered
	 */
	protected EList<luggageRange> transportrange;

	/**
	 * The cached value of the '{@link #getWindow() <em>Window</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWindow()
	 * @generated
	 * @ordered
	 */
	protected EList<window> window;

	/**
	 * The cached value of the '{@link #getDoor() <em>Door</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoor()
	 * @generated
	 * @ordered
	 */
	protected EList<door> door;

	/**
	 * The cached value of the '{@link #getInformationfacility() <em>Informationfacility</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInformationfacility()
	 * @generated
	 * @ordered
	 */
	protected EList<informationFacility> informationfacility;

	/**
	 * The cached value of the '{@link #getStayingpossibility() <em>Stayingpossibility</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStayingpossibility()
	 * @generated
	 * @ordered
	 */
	protected EList<loungeArea> stayingpossibility;

	/**
	 * The cached value of the '{@link #getSit() <em>Sit</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSit()
	 * @generated
	 * @ordered
	 */
	protected EList<seat> sit;

	/**
	 * The cached value of the '{@link #getSafetydevice() <em>Safetydevice</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSafetydevice()
	 * @generated
	 * @ordered
	 */
	protected EList<safetyDevice> safetydevice;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected chassisImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return VehiclePackage.Literals.CHASSIS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public exteriorAccessories getAccessories() {
		return accessories;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAccessories(exteriorAccessories newAccessories) {
		exteriorAccessories oldAccessories = accessories;
		accessories = newAccessories == null ? ACCESSORIES_EDEFAULT : newAccessories;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.CHASSIS__ACCESSORIES, oldAccessories,
					accessories));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.CHASSIS__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<supportElement> getLoadBearingElement() {
		if (loadBearingElement == null) {
			loadBearingElement = new EObjectContainmentEList<supportElement>(supportElement.class, this,
					VehiclePackage.CHASSIS__LOAD_BEARING_ELEMENT);
		}
		return loadBearingElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<luggageRange> getTransportrange() {
		if (transportrange == null) {
			transportrange = new EObjectContainmentEList<luggageRange>(luggageRange.class, this,
					VehiclePackage.CHASSIS__TRANSPORTRANGE);
		}
		return transportrange;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<window> getWindow() {
		if (window == null) {
			window = new EObjectContainmentEList<window>(window.class, this, VehiclePackage.CHASSIS__WINDOW);
		}
		return window;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<door> getDoor() {
		if (door == null) {
			door = new EObjectContainmentEList<door>(door.class, this, VehiclePackage.CHASSIS__DOOR);
		}
		return door;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<informationFacility> getInformationfacility() {
		if (informationfacility == null) {
			informationfacility = new EObjectContainmentEList<informationFacility>(informationFacility.class, this,
					VehiclePackage.CHASSIS__INFORMATIONFACILITY);
		}
		return informationfacility;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<loungeArea> getStayingpossibility() {
		if (stayingpossibility == null) {
			stayingpossibility = new EObjectContainmentEList<loungeArea>(loungeArea.class, this,
					VehiclePackage.CHASSIS__STAYINGPOSSIBILITY);
		}
		return stayingpossibility;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<seat> getSit() {
		if (sit == null) {
			sit = new EObjectContainmentEList<seat>(seat.class, this, VehiclePackage.CHASSIS__SIT);
		}
		return sit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<safetyDevice> getSafetydevice() {
		if (safetydevice == null) {
			safetydevice = new EObjectResolvingEList<safetyDevice>(safetyDevice.class, this,
					VehiclePackage.CHASSIS__SAFETYDEVICE);
		}
		return safetydevice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case VehiclePackage.CHASSIS__LOAD_BEARING_ELEMENT:
			return ((InternalEList<?>) getLoadBearingElement()).basicRemove(otherEnd, msgs);
		case VehiclePackage.CHASSIS__TRANSPORTRANGE:
			return ((InternalEList<?>) getTransportrange()).basicRemove(otherEnd, msgs);
		case VehiclePackage.CHASSIS__WINDOW:
			return ((InternalEList<?>) getWindow()).basicRemove(otherEnd, msgs);
		case VehiclePackage.CHASSIS__DOOR:
			return ((InternalEList<?>) getDoor()).basicRemove(otherEnd, msgs);
		case VehiclePackage.CHASSIS__INFORMATIONFACILITY:
			return ((InternalEList<?>) getInformationfacility()).basicRemove(otherEnd, msgs);
		case VehiclePackage.CHASSIS__STAYINGPOSSIBILITY:
			return ((InternalEList<?>) getStayingpossibility()).basicRemove(otherEnd, msgs);
		case VehiclePackage.CHASSIS__SIT:
			return ((InternalEList<?>) getSit()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case VehiclePackage.CHASSIS__ACCESSORIES:
			return getAccessories();
		case VehiclePackage.CHASSIS__NAME:
			return getName();
		case VehiclePackage.CHASSIS__LOAD_BEARING_ELEMENT:
			return getLoadBearingElement();
		case VehiclePackage.CHASSIS__TRANSPORTRANGE:
			return getTransportrange();
		case VehiclePackage.CHASSIS__WINDOW:
			return getWindow();
		case VehiclePackage.CHASSIS__DOOR:
			return getDoor();
		case VehiclePackage.CHASSIS__INFORMATIONFACILITY:
			return getInformationfacility();
		case VehiclePackage.CHASSIS__STAYINGPOSSIBILITY:
			return getStayingpossibility();
		case VehiclePackage.CHASSIS__SIT:
			return getSit();
		case VehiclePackage.CHASSIS__SAFETYDEVICE:
			return getSafetydevice();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case VehiclePackage.CHASSIS__ACCESSORIES:
			setAccessories((exteriorAccessories) newValue);
			return;
		case VehiclePackage.CHASSIS__NAME:
			setName((String) newValue);
			return;
		case VehiclePackage.CHASSIS__LOAD_BEARING_ELEMENT:
			getLoadBearingElement().clear();
			getLoadBearingElement().addAll((Collection<? extends supportElement>) newValue);
			return;
		case VehiclePackage.CHASSIS__TRANSPORTRANGE:
			getTransportrange().clear();
			getTransportrange().addAll((Collection<? extends luggageRange>) newValue);
			return;
		case VehiclePackage.CHASSIS__WINDOW:
			getWindow().clear();
			getWindow().addAll((Collection<? extends window>) newValue);
			return;
		case VehiclePackage.CHASSIS__DOOR:
			getDoor().clear();
			getDoor().addAll((Collection<? extends door>) newValue);
			return;
		case VehiclePackage.CHASSIS__INFORMATIONFACILITY:
			getInformationfacility().clear();
			getInformationfacility().addAll((Collection<? extends informationFacility>) newValue);
			return;
		case VehiclePackage.CHASSIS__STAYINGPOSSIBILITY:
			getStayingpossibility().clear();
			getStayingpossibility().addAll((Collection<? extends loungeArea>) newValue);
			return;
		case VehiclePackage.CHASSIS__SIT:
			getSit().clear();
			getSit().addAll((Collection<? extends seat>) newValue);
			return;
		case VehiclePackage.CHASSIS__SAFETYDEVICE:
			getSafetydevice().clear();
			getSafetydevice().addAll((Collection<? extends safetyDevice>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case VehiclePackage.CHASSIS__ACCESSORIES:
			setAccessories(ACCESSORIES_EDEFAULT);
			return;
		case VehiclePackage.CHASSIS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case VehiclePackage.CHASSIS__LOAD_BEARING_ELEMENT:
			getLoadBearingElement().clear();
			return;
		case VehiclePackage.CHASSIS__TRANSPORTRANGE:
			getTransportrange().clear();
			return;
		case VehiclePackage.CHASSIS__WINDOW:
			getWindow().clear();
			return;
		case VehiclePackage.CHASSIS__DOOR:
			getDoor().clear();
			return;
		case VehiclePackage.CHASSIS__INFORMATIONFACILITY:
			getInformationfacility().clear();
			return;
		case VehiclePackage.CHASSIS__STAYINGPOSSIBILITY:
			getStayingpossibility().clear();
			return;
		case VehiclePackage.CHASSIS__SIT:
			getSit().clear();
			return;
		case VehiclePackage.CHASSIS__SAFETYDEVICE:
			getSafetydevice().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case VehiclePackage.CHASSIS__ACCESSORIES:
			return accessories != ACCESSORIES_EDEFAULT;
		case VehiclePackage.CHASSIS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case VehiclePackage.CHASSIS__LOAD_BEARING_ELEMENT:
			return loadBearingElement != null && !loadBearingElement.isEmpty();
		case VehiclePackage.CHASSIS__TRANSPORTRANGE:
			return transportrange != null && !transportrange.isEmpty();
		case VehiclePackage.CHASSIS__WINDOW:
			return window != null && !window.isEmpty();
		case VehiclePackage.CHASSIS__DOOR:
			return door != null && !door.isEmpty();
		case VehiclePackage.CHASSIS__INFORMATIONFACILITY:
			return informationfacility != null && !informationfacility.isEmpty();
		case VehiclePackage.CHASSIS__STAYINGPOSSIBILITY:
			return stayingpossibility != null && !stayingpossibility.isEmpty();
		case VehiclePackage.CHASSIS__SIT:
			return sit != null && !sit.isEmpty();
		case VehiclePackage.CHASSIS__SAFETYDEVICE:
			return safetydevice != null && !safetydevice.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Accessories: ");
		result.append(accessories);
		result.append(", name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //chassisImpl
