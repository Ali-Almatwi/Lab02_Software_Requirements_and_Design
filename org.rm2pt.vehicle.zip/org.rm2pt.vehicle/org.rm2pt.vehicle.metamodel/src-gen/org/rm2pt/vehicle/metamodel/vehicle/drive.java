/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>drive</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.drive#getFuel <em>Fuel</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.drive#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getdrive()
 * @model
 * @generated
 */
public interface drive extends EObject {
	/**
	 * Returns the value of the '<em><b>Fuel</b></em>' attribute.
	 * The default value is <code>"noCombustion"</code>.
	 * The literals are from the enumeration {@link org.rm2pt.vehicle.metamodel.vehicle.fuelType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fuel</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.fuelType
	 * @see #setFuel(fuelType)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getdrive_Fuel()
	 * @model default="noCombustion"
	 * @generated
	 */
	fuelType getFuel();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.drive#getFuel <em>Fuel</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fuel</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.fuelType
	 * @see #getFuel()
	 * @generated
	 */
	void setFuel(fuelType value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getdrive_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.drive#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // drive
