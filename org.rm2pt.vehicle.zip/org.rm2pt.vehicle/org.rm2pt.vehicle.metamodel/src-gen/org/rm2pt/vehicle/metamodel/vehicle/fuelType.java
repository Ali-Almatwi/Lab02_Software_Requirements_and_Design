/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>fuel Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getfuelType()
 * @model
 * @generated
 */
public enum fuelType implements Enumerator {
	/**
	 * The '<em><b>No Combustion</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NO_COMBUSTION_VALUE
	 * @generated
	 * @ordered
	 */
	NO_COMBUSTION(0, "noCombustion", "noCombustion"),

	/**
	 * The '<em><b>Petrol</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PETROL_VALUE
	 * @generated
	 * @ordered
	 */
	PETROL(1, "petrol", "petrol"),

	/**
	 * The '<em><b>Diesel</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DIESEL_VALUE
	 * @generated
	 * @ordered
	 */
	DIESEL(2, "diesel", "diesel");

	/**
	 * The '<em><b>No Combustion</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NO_COMBUSTION
	 * @model name="noCombustion"
	 * @generated
	 * @ordered
	 */
	public static final int NO_COMBUSTION_VALUE = 0;

	/**
	 * The '<em><b>Petrol</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PETROL
	 * @model name="petrol"
	 * @generated
	 * @ordered
	 */
	public static final int PETROL_VALUE = 1;

	/**
	 * The '<em><b>Diesel</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DIESEL
	 * @model name="diesel"
	 * @generated
	 * @ordered
	 */
	public static final int DIESEL_VALUE = 2;

	/**
	 * An array of all the '<em><b>fuel Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final fuelType[] VALUES_ARRAY = new fuelType[] { NO_COMBUSTION, PETROL, DIESEL, };

	/**
	 * A public read-only list of all the '<em><b>fuel Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<fuelType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>fuel Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static fuelType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			fuelType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>fuel Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static fuelType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			fuelType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>fuel Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static fuelType get(int value) {
		switch (value) {
		case NO_COMBUSTION_VALUE:
			return NO_COMBUSTION;
		case PETROL_VALUE:
			return PETROL;
		case DIESEL_VALUE:
			return DIESEL;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private fuelType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //fuelType
