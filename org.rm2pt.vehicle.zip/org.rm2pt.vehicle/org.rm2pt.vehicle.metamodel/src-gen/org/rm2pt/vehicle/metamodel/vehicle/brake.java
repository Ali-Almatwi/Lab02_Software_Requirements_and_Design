/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>brake</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.brake#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getbrake()
 * @model
 * @generated
 */
public interface brake extends EObject {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link org.rm2pt.vehicle.metamodel.vehicle.brakeType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.brakeType
	 * @see #setType(brakeType)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getbrake_Type()
	 * @model
	 * @generated
	 */
	brakeType getType();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.brake#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.brakeType
	 * @see #getType()
	 * @generated
	 */
	void setType(brakeType value);

} // brake
