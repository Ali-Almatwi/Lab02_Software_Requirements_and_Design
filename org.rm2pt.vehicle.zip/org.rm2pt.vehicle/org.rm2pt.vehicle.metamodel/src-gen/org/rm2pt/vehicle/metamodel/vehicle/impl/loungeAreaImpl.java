/**
 */
package org.rm2pt.vehicle.metamodel.vehicle.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage;
import org.rm2pt.vehicle.metamodel.vehicle.door;
import org.rm2pt.vehicle.metamodel.vehicle.loungeArea;
import org.rm2pt.vehicle.metamodel.vehicle.window;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>lounge Area</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.loungeAreaImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.loungeAreaImpl#getWindow <em>Window</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.loungeAreaImpl#getDoor <em>Door</em>}</li>
 * </ul>
 *
 * @generated
 */
public class loungeAreaImpl extends MinimalEObjectImpl.Container implements loungeArea {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getWindow() <em>Window</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWindow()
	 * @generated
	 * @ordered
	 */
	protected EList<window> window;

	/**
	 * The cached value of the '{@link #getDoor() <em>Door</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoor()
	 * @generated
	 * @ordered
	 */
	protected EList<door> door;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected loungeAreaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return VehiclePackage.Literals.LOUNGE_AREA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.LOUNGE_AREA__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<window> getWindow() {
		if (window == null) {
			window = new EObjectContainmentEList<window>(window.class, this, VehiclePackage.LOUNGE_AREA__WINDOW);
		}
		return window;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<door> getDoor() {
		if (door == null) {
			door = new EObjectResolvingEList<door>(door.class, this, VehiclePackage.LOUNGE_AREA__DOOR);
		}
		return door;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case VehiclePackage.LOUNGE_AREA__WINDOW:
			return ((InternalEList<?>) getWindow()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case VehiclePackage.LOUNGE_AREA__NAME:
			return getName();
		case VehiclePackage.LOUNGE_AREA__WINDOW:
			return getWindow();
		case VehiclePackage.LOUNGE_AREA__DOOR:
			return getDoor();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case VehiclePackage.LOUNGE_AREA__NAME:
			setName((String) newValue);
			return;
		case VehiclePackage.LOUNGE_AREA__WINDOW:
			getWindow().clear();
			getWindow().addAll((Collection<? extends window>) newValue);
			return;
		case VehiclePackage.LOUNGE_AREA__DOOR:
			getDoor().clear();
			getDoor().addAll((Collection<? extends door>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case VehiclePackage.LOUNGE_AREA__NAME:
			setName(NAME_EDEFAULT);
			return;
		case VehiclePackage.LOUNGE_AREA__WINDOW:
			getWindow().clear();
			return;
		case VehiclePackage.LOUNGE_AREA__DOOR:
			getDoor().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case VehiclePackage.LOUNGE_AREA__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case VehiclePackage.LOUNGE_AREA__WINDOW:
			return window != null && !window.isEmpty();
		case VehiclePackage.LOUNGE_AREA__DOOR:
			return door != null && !door.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //loungeAreaImpl
