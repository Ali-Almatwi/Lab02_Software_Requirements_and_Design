/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>safety Device</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.safetyDevice#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.safetyDevice#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getsafetyDevice()
 * @model
 * @generated
 */
public interface safetyDevice extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getsafetyDevice_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.safetyDevice#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link org.rm2pt.vehicle.metamodel.vehicle.safetyType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.safetyType
	 * @see #setType(safetyType)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getsafetyDevice_Type()
	 * @model
	 * @generated
	 */
	safetyType getType();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.safetyDevice#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.safetyType
	 * @see #getType()
	 * @generated
	 */
	void setType(safetyType value);

} // safetyDevice
