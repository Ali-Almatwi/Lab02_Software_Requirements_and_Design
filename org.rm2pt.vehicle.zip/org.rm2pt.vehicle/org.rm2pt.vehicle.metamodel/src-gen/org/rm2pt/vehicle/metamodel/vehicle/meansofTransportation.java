/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>meansof Transportation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getChassis <em>Chassis</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getPerson <em>Person</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getPowertransmission <em>Powertransmission</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getDrive <em>Drive</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getNamufacturer <em>Namufacturer</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getPrice <em>Price</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getWheel <em>Wheel</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getmeansofTransportation()
 * @model
 * @generated
 */
public interface meansofTransportation extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getmeansofTransportation_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Chassis</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.chassis}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Chassis</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getmeansofTransportation_Chassis()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<chassis> getChassis();

	/**
	 * Returns the value of the '<em><b>Person</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.person}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Person</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getmeansofTransportation_Person()
	 * @model containment="true"
	 * @generated
	 */
	EList<person> getPerson();

	/**
	 * Returns the value of the '<em><b>Powertransmission</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.powerTransmission}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Powertransmission</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getmeansofTransportation_Powertransmission()
	 * @model containment="true"
	 * @generated
	 */
	EList<powerTransmission> getPowertransmission();

	/**
	 * Returns the value of the '<em><b>Drive</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.drive}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Drive</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getmeansofTransportation_Drive()
	 * @model containment="true"
	 * @generated
	 */
	EList<drive> getDrive();

	/**
	 * Returns the value of the '<em><b>Namufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Namufacturer</em>' attribute.
	 * @see #setNamufacturer(String)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getmeansofTransportation_Namufacturer()
	 * @model
	 * @generated
	 */
	String getNamufacturer();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getNamufacturer <em>Namufacturer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Namufacturer</em>' attribute.
	 * @see #getNamufacturer()
	 * @generated
	 */
	void setNamufacturer(String value);

	/**
	 * Returns the value of the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Price</em>' attribute.
	 * @see #setPrice(int)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getmeansofTransportation_Price()
	 * @model
	 * @generated
	 */
	int getPrice();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation#getPrice <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Price</em>' attribute.
	 * @see #getPrice()
	 * @generated
	 */
	void setPrice(int value);

	/**
	 * Returns the value of the '<em><b>Wheel</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.Wheel}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Wheel</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getmeansofTransportation_Wheel()
	 * @model containment="true"
	 * @generated
	 */
	EList<Wheel> getWheel();

} // meansofTransportation
