/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Wheel</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getFastening <em>Fastening</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getRim <em>Rim</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getThread <em>Thread</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getBrake <em>Brake</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getChassis <em>Chassis</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getWheel()
 * @model
 * @generated
 */
public interface Wheel extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getWheel_Name()
	 * @model default="" required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Fastening</b></em>' attribute.
	 * The literals are from the enumeration {@link org.rm2pt.vehicle.metamodel.vehicle.design}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fastening</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.design
	 * @see #setFastening(design)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getWheel_Fastening()
	 * @model
	 * @generated
	 */
	design getFastening();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getFastening <em>Fastening</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fastening</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.design
	 * @see #getFastening()
	 * @generated
	 */
	void setFastening(design value);

	/**
	 * Returns the value of the '<em><b>Rim</b></em>' attribute.
	 * The default value is <code>"steel"</code>.
	 * The literals are from the enumeration {@link org.rm2pt.vehicle.metamodel.vehicle.rimType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rim</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.rimType
	 * @see #setRim(rimType)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getWheel_Rim()
	 * @model default="steel"
	 * @generated
	 */
	rimType getRim();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getRim <em>Rim</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rim</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.rimType
	 * @see #getRim()
	 * @generated
	 */
	void setRim(rimType value);

	/**
	 * Returns the value of the '<em><b>Thread</b></em>' attribute.
	 * The literals are from the enumeration {@link org.rm2pt.vehicle.metamodel.vehicle.threadType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Thread</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.threadType
	 * @see #setThread(threadType)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getWheel_Thread()
	 * @model
	 * @generated
	 */
	threadType getThread();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getThread <em>Thread</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Thread</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.threadType
	 * @see #getThread()
	 * @generated
	 */
	void setThread(threadType value);

	/**
	 * Returns the value of the '<em><b>Brake</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.brake}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Brake</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getWheel_Brake()
	 * @model containment="true"
	 * @generated
	 */
	EList<brake> getBrake();

	/**
	 * Returns the value of the '<em><b>Chassis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Chassis</em>' reference.
	 * @see #setChassis(chassis)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getWheel_Chassis()
	 * @model required="true"
	 * @generated
	 */
	chassis getChassis();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel#getChassis <em>Chassis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Chassis</em>' reference.
	 * @see #getChassis()
	 * @generated
	 */
	void setChassis(chassis value);

} // Wheel
