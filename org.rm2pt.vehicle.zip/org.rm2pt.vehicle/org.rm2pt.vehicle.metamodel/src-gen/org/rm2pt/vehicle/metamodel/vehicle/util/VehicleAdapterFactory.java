/**
 */
package org.rm2pt.vehicle.metamodel.vehicle.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import org.rm2pt.vehicle.metamodel.vehicle.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage
 * @generated
 */
public class VehicleAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static VehiclePackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = VehiclePackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VehicleSwitch<Adapter> modelSwitch = new VehicleSwitch<Adapter>() {
		@Override
		public Adapter casesupportElement(supportElement object) {
			return createsupportElementAdapter();
		}

		@Override
		public Adapter casechassis(chassis object) {
			return createchassisAdapter();
		}

		@Override
		public Adapter caseWheel(Wheel object) {
			return createWheelAdapter();
		}

		@Override
		public Adapter casecontrolElement(controlElement object) {
			return createcontrolElementAdapter();
		}

		@Override
		public Adapter casetaxArea(taxArea object) {
			return createtaxAreaAdapter();
		}

		@Override
		public Adapter caseseat(seat object) {
			return createseatAdapter();
		}

		@Override
		public Adapter caseloungeArea(loungeArea object) {
			return createloungeAreaAdapter();
		}

		@Override
		public Adapter caseperson(person object) {
			return createpersonAdapter();
		}

		@Override
		public Adapter casedoor(door object) {
			return createdoorAdapter();
		}

		@Override
		public Adapter casewindow(window object) {
			return createwindowAdapter();
		}

		@Override
		public Adapter casesafetyDevice(safetyDevice object) {
			return createsafetyDeviceAdapter();
		}

		@Override
		public Adapter casedrive(drive object) {
			return createdriveAdapter();
		}

		@Override
		public Adapter casemeansofTransportation(meansofTransportation object) {
			return createmeansofTransportationAdapter();
		}

		@Override
		public Adapter casebrake(brake object) {
			return createbrakeAdapter();
		}

		@Override
		public Adapter casevehicleModel(vehicleModel object) {
			return createvehicleModelAdapter();
		}

		@Override
		public Adapter casepowerTransmission(powerTransmission object) {
			return createpowerTransmissionAdapter();
		}

		@Override
		public Adapter caseluggageRange(luggageRange object) {
			return createluggageRangeAdapter();
		}

		@Override
		public Adapter caseinformationFacility(informationFacility object) {
			return createinformationFacilityAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.supportElement <em>support Element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.supportElement
	 * @generated
	 */
	public Adapter createsupportElementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis <em>chassis</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.chassis
	 * @generated
	 */
	public Adapter createchassisAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.Wheel <em>Wheel</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.Wheel
	 * @generated
	 */
	public Adapter createWheelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.controlElement <em>control Element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.controlElement
	 * @generated
	 */
	public Adapter createcontrolElementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea <em>tax Area</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxArea
	 * @generated
	 */
	public Adapter createtaxAreaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.seat <em>seat</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.seat
	 * @generated
	 */
	public Adapter createseatAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.loungeArea <em>lounge Area</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.loungeArea
	 * @generated
	 */
	public Adapter createloungeAreaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.person <em>person</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.person
	 * @generated
	 */
	public Adapter createpersonAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.door <em>door</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.door
	 * @generated
	 */
	public Adapter createdoorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.window <em>window</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.window
	 * @generated
	 */
	public Adapter createwindowAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.safetyDevice <em>safety Device</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.safetyDevice
	 * @generated
	 */
	public Adapter createsafetyDeviceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.drive <em>drive</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.drive
	 * @generated
	 */
	public Adapter createdriveAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation <em>meansof Transportation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation
	 * @generated
	 */
	public Adapter createmeansofTransportationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.brake <em>brake</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.brake
	 * @generated
	 */
	public Adapter createbrakeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.vehicleModel <em>vehicle Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.vehicleModel
	 * @generated
	 */
	public Adapter createvehicleModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.powerTransmission <em>power Transmission</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.powerTransmission
	 * @generated
	 */
	public Adapter createpowerTransmissionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.luggageRange <em>luggage Range</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.luggageRange
	 * @generated
	 */
	public Adapter createluggageRangeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.rm2pt.vehicle.metamodel.vehicle.informationFacility <em>information Facility</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.informationFacility
	 * @generated
	 */
	public Adapter createinformationFacilityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //VehicleAdapterFactory
