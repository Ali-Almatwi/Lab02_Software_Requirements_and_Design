/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>tax Area</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getControlelement <em>Controlelement</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getInformationfacility <em>Informationfacility</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getDoor <em>Door</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getSafetydevice <em>Safetydevice</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getWindow <em>Window</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#gettaxArea()
 * @model
 * @generated
 */
public interface taxArea extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#gettaxArea_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Controlelement</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.controlElement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controlelement</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#gettaxArea_Controlelement()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<controlElement> getControlelement();

	/**
	 * Returns the value of the '<em><b>Informationfacility</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Informationfacility</em>' reference.
	 * @see #setInformationfacility(informationFacility)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#gettaxArea_Informationfacility()
	 * @model
	 * @generated
	 */
	informationFacility getInformationfacility();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.taxArea#getInformationfacility <em>Informationfacility</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Informationfacility</em>' reference.
	 * @see #getInformationfacility()
	 * @generated
	 */
	void setInformationfacility(informationFacility value);

	/**
	 * Returns the value of the '<em><b>Door</b></em>' reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.door}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Door</em>' reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#gettaxArea_Door()
	 * @model
	 * @generated
	 */
	EList<door> getDoor();

	/**
	 * Returns the value of the '<em><b>Safetydevice</b></em>' reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.safetyDevice}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Safetydevice</em>' reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#gettaxArea_Safetydevice()
	 * @model
	 * @generated
	 */
	EList<safetyDevice> getSafetydevice();

	/**
	 * Returns the value of the '<em><b>Window</b></em>' reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.window}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Window</em>' reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#gettaxArea_Window()
	 * @model
	 * @generated
	 */
	EList<window> getWindow();

} // taxArea
