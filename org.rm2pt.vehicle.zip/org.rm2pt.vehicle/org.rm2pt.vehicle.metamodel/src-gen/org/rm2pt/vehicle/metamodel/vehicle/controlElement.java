/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>control Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.controlElement#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.controlElement#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getcontrolElement()
 * @model
 * @generated
 */
public interface controlElement extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getcontrolElement_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.controlElement#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link org.rm2pt.vehicle.metamodel.vehicle.taxType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxType
	 * @see #setType(taxType)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getcontrolElement_Type()
	 * @model required="true"
	 * @generated
	 */
	taxType getType();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.controlElement#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.taxType
	 * @see #getType()
	 * @generated
	 */
	void setType(taxType value);

} // controlElement
