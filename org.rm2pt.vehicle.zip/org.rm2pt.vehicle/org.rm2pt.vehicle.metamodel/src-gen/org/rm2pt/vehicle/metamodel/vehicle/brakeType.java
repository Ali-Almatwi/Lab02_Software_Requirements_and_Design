/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>brake Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getbrakeType()
 * @model
 * @generated
 */
public enum brakeType implements Enumerator {
	/**
	 * The '<em><b>Disc Brake</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DISC_BRAKE_VALUE
	 * @generated
	 * @ordered
	 */
	DISC_BRAKE(0, "discBrake", "discBrake"),

	/**
	 * The '<em><b>Drum Brake</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DRUM_BRAKE_VALUE
	 * @generated
	 * @ordered
	 */
	DRUM_BRAKE(1, "drumBrake", "drumBrake");

	/**
	 * The '<em><b>Disc Brake</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DISC_BRAKE
	 * @model name="discBrake"
	 * @generated
	 * @ordered
	 */
	public static final int DISC_BRAKE_VALUE = 0;

	/**
	 * The '<em><b>Drum Brake</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DRUM_BRAKE
	 * @model name="drumBrake"
	 * @generated
	 * @ordered
	 */
	public static final int DRUM_BRAKE_VALUE = 1;

	/**
	 * An array of all the '<em><b>brake Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final brakeType[] VALUES_ARRAY = new brakeType[] { DISC_BRAKE, DRUM_BRAKE, };

	/**
	 * A public read-only list of all the '<em><b>brake Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<brakeType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>brake Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static brakeType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			brakeType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>brake Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static brakeType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			brakeType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>brake Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static brakeType get(int value) {
		switch (value) {
		case DISC_BRAKE_VALUE:
			return DISC_BRAKE;
		case DRUM_BRAKE_VALUE:
			return DRUM_BRAKE;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private brakeType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //brakeType
