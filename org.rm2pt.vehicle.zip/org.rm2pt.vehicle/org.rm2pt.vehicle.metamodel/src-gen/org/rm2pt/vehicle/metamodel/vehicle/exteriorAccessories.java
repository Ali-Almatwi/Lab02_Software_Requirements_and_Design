/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>exterior Accessories</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getexteriorAccessories()
 * @model
 * @generated
 */
public enum exteriorAccessories implements Enumerator {
	/**
	 * The '<em><b>Camera</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CAMERA_VALUE
	 * @generated
	 * @ordered
	 */
	CAMERA(0, "camera", "camera"),

	/**
	 * The '<em><b>Light</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LIGHT_VALUE
	 * @generated
	 * @ordered
	 */
	LIGHT(1, "light", "light"),

	/**
	 * The '<em><b>Mirror</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MIRROR_VALUE
	 * @generated
	 * @ordered
	 */
	MIRROR(2, "mirror", "mirror"),

	/**
	 * The '<em><b>Wing</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WING_VALUE
	 * @generated
	 * @ordered
	 */
	WING(3, "wing", "wing");

	/**
	 * The '<em><b>Camera</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CAMERA
	 * @model name="camera"
	 * @generated
	 * @ordered
	 */
	public static final int CAMERA_VALUE = 0;

	/**
	 * The '<em><b>Light</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LIGHT
	 * @model name="light"
	 * @generated
	 * @ordered
	 */
	public static final int LIGHT_VALUE = 1;

	/**
	 * The '<em><b>Mirror</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MIRROR
	 * @model name="mirror"
	 * @generated
	 * @ordered
	 */
	public static final int MIRROR_VALUE = 2;

	/**
	 * The '<em><b>Wing</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WING
	 * @model name="wing"
	 * @generated
	 * @ordered
	 */
	public static final int WING_VALUE = 3;

	/**
	 * An array of all the '<em><b>exterior Accessories</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final exteriorAccessories[] VALUES_ARRAY = new exteriorAccessories[] { CAMERA, LIGHT, MIRROR,
			WING, };

	/**
	 * A public read-only list of all the '<em><b>exterior Accessories</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<exteriorAccessories> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>exterior Accessories</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static exteriorAccessories get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			exteriorAccessories result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>exterior Accessories</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static exteriorAccessories getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			exteriorAccessories result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>exterior Accessories</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static exteriorAccessories get(int value) {
		switch (value) {
		case CAMERA_VALUE:
			return CAMERA;
		case LIGHT_VALUE:
			return LIGHT;
		case MIRROR_VALUE:
			return MIRROR;
		case WING_VALUE:
			return WING;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private exteriorAccessories(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //exteriorAccessories
