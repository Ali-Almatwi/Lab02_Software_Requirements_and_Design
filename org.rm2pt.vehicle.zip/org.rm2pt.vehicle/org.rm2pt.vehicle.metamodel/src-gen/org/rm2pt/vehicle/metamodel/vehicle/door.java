/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>door</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.door#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.door#getWindow <em>Window</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.door#getControlelement <em>Controlelement</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getdoor()
 * @model
 * @generated
 */
public interface door extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getdoor_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.door#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Window</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Window</em>' reference.
	 * @see #setWindow(window)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getdoor_Window()
	 * @model
	 * @generated
	 */
	window getWindow();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.door#getWindow <em>Window</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Window</em>' reference.
	 * @see #getWindow()
	 * @generated
	 */
	void setWindow(window value);

	/**
	 * Returns the value of the '<em><b>Controlelement</b></em>' reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.controlElement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controlelement</em>' reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getdoor_Controlelement()
	 * @model
	 * @generated
	 */
	EList<controlElement> getControlelement();

} // door
