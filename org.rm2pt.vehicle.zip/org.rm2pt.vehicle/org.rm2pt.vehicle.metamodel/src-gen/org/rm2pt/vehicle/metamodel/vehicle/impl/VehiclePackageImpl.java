/**
 */
package org.rm2pt.vehicle.metamodel.vehicle.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.rm2pt.vehicle.metamodel.vehicle.InfoArt;
import org.rm2pt.vehicle.metamodel.vehicle.VehicleFactory;
import org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage;
import org.rm2pt.vehicle.metamodel.vehicle.Wheel;
import org.rm2pt.vehicle.metamodel.vehicle.brake;
import org.rm2pt.vehicle.metamodel.vehicle.brakeType;
import org.rm2pt.vehicle.metamodel.vehicle.chassis;
import org.rm2pt.vehicle.metamodel.vehicle.controlElement;
import org.rm2pt.vehicle.metamodel.vehicle.design;
import org.rm2pt.vehicle.metamodel.vehicle.door;
import org.rm2pt.vehicle.metamodel.vehicle.drive;
import org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories;
import org.rm2pt.vehicle.metamodel.vehicle.fuelType;
import org.rm2pt.vehicle.metamodel.vehicle.informationFacility;
import org.rm2pt.vehicle.metamodel.vehicle.loungeArea;
import org.rm2pt.vehicle.metamodel.vehicle.luggageRange;
import org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation;
import org.rm2pt.vehicle.metamodel.vehicle.person;
import org.rm2pt.vehicle.metamodel.vehicle.powerTransmission;
import org.rm2pt.vehicle.metamodel.vehicle.rimType;
import org.rm2pt.vehicle.metamodel.vehicle.safetyDevice;
import org.rm2pt.vehicle.metamodel.vehicle.safetyType;
import org.rm2pt.vehicle.metamodel.vehicle.seat;
import org.rm2pt.vehicle.metamodel.vehicle.seatType;
import org.rm2pt.vehicle.metamodel.vehicle.supportElement;
import org.rm2pt.vehicle.metamodel.vehicle.taxArea;
import org.rm2pt.vehicle.metamodel.vehicle.taxType;
import org.rm2pt.vehicle.metamodel.vehicle.threadType;
import org.rm2pt.vehicle.metamodel.vehicle.vehicleModel;
import org.rm2pt.vehicle.metamodel.vehicle.window;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class VehiclePackageImpl extends EPackageImpl implements VehiclePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supportElementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass chassisEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass wheelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass controlElementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass taxAreaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass seatEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass loungeAreaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass personEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass doorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass windowEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass safetyDeviceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass driveEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass meansofTransportationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass brakeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass vehicleModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass powerTransmissionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass luggageRangeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass informationFacilityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum exteriorAccessoriesEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum taxTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum seatTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum infoArtEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum fuelTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum brakeTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum safetyTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum designEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum rimTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum threadTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private VehiclePackageImpl() {
		super(eNS_URI, VehicleFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link VehiclePackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static VehiclePackage init() {
		if (isInited)
			return (VehiclePackage) EPackage.Registry.INSTANCE.getEPackage(VehiclePackage.eNS_URI);

		// Obtain or create and register package
		Object registeredVehiclePackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		VehiclePackageImpl theVehiclePackage = registeredVehiclePackage instanceof VehiclePackageImpl
				? (VehiclePackageImpl) registeredVehiclePackage
				: new VehiclePackageImpl();

		isInited = true;

		// Create package meta-data objects
		theVehiclePackage.createPackageContents();

		// Initialize created meta-data
		theVehiclePackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theVehiclePackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(VehiclePackage.eNS_URI, theVehiclePackage);
		return theVehiclePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getsupportElement() {
		return supportElementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getsupportElement_Name() {
		return (EAttribute) supportElementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getchassis() {
		return chassisEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getchassis_Accessories() {
		return (EAttribute) chassisEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getchassis_Name() {
		return (EAttribute) chassisEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getchassis_LoadBearingElement() {
		return (EReference) chassisEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getchassis_Transportrange() {
		return (EReference) chassisEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getchassis_Window() {
		return (EReference) chassisEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getchassis_Door() {
		return (EReference) chassisEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getchassis_Informationfacility() {
		return (EReference) chassisEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getchassis_Stayingpossibility() {
		return (EReference) chassisEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getchassis_Sit() {
		return (EReference) chassisEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getchassis_Safetydevice() {
		return (EReference) chassisEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWheel() {
		return wheelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWheel_Name() {
		return (EAttribute) wheelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWheel_Fastening() {
		return (EAttribute) wheelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWheel_Rim() {
		return (EAttribute) wheelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWheel_Thread() {
		return (EAttribute) wheelEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWheel_Brake() {
		return (EReference) wheelEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWheel_Chassis() {
		return (EReference) wheelEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getcontrolElement() {
		return controlElementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getcontrolElement_Name() {
		return (EAttribute) controlElementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getcontrolElement_Type() {
		return (EAttribute) controlElementEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass gettaxArea() {
		return taxAreaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute gettaxArea_Name() {
		return (EAttribute) taxAreaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference gettaxArea_Controlelement() {
		return (EReference) taxAreaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference gettaxArea_Informationfacility() {
		return (EReference) taxAreaEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference gettaxArea_Door() {
		return (EReference) taxAreaEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference gettaxArea_Safetydevice() {
		return (EReference) taxAreaEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference gettaxArea_Window() {
		return (EReference) taxAreaEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getseat() {
		return seatEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getseat_Type() {
		return (EAttribute) seatEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getloungeArea() {
		return loungeAreaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getloungeArea_Name() {
		return (EAttribute) loungeAreaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getloungeArea_Window() {
		return (EReference) loungeAreaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getloungeArea_Door() {
		return (EReference) loungeAreaEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getperson() {
		return personEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getperson_Name() {
		return (EAttribute) personEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getperson_Seat() {
		return (EReference) personEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getdoor() {
		return doorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getdoor_Name() {
		return (EAttribute) doorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdoor_Window() {
		return (EReference) doorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getdoor_Controlelement() {
		return (EReference) doorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getwindow() {
		return windowEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getwindow_Name() {
		return (EAttribute) windowEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getwindow_Movable() {
		return (EAttribute) windowEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getsafetyDevice() {
		return safetyDeviceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getsafetyDevice_Name() {
		return (EAttribute) safetyDeviceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getsafetyDevice_Type() {
		return (EAttribute) safetyDeviceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getdrive() {
		return driveEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getdrive_Fuel() {
		return (EAttribute) driveEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getdrive_Name() {
		return (EAttribute) driveEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getmeansofTransportation() {
		return meansofTransportationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getmeansofTransportation_Name() {
		return (EAttribute) meansofTransportationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getmeansofTransportation_Chassis() {
		return (EReference) meansofTransportationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getmeansofTransportation_Person() {
		return (EReference) meansofTransportationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getmeansofTransportation_Powertransmission() {
		return (EReference) meansofTransportationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getmeansofTransportation_Drive() {
		return (EReference) meansofTransportationEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getmeansofTransportation_Namufacturer() {
		return (EAttribute) meansofTransportationEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getmeansofTransportation_Price() {
		return (EAttribute) meansofTransportationEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getmeansofTransportation_Wheel() {
		return (EReference) meansofTransportationEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getbrake() {
		return brakeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getbrake_Type() {
		return (EAttribute) brakeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getvehicleModel() {
		return vehicleModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getvehicleModel_Name() {
		return (EAttribute) vehicleModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getvehicleModel_Meansoftransportation() {
		return (EReference) vehicleModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getpowerTransmission() {
		return powerTransmissionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getpowerTransmission_Name() {
		return (EAttribute) powerTransmissionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getpowerTransmission_Wide() {
		return (EAttribute) powerTransmissionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getluggageRange() {
		return luggageRangeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getluggageRange_Name() {
		return (EAttribute) luggageRangeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getluggageRange_Window() {
		return (EReference) luggageRangeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getluggageRange_Door() {
		return (EReference) luggageRangeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getinformationFacility() {
		return informationFacilityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getinformationFacility_Name() {
		return (EAttribute) informationFacilityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getinformationFacility_Type() {
		return (EAttribute) informationFacilityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getexteriorAccessories() {
		return exteriorAccessoriesEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum gettaxType() {
		return taxTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getseatType() {
		return seatTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getInfoArt() {
		return infoArtEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getfuelType() {
		return fuelTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getbrakeType() {
		return brakeTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getsafetyType() {
		return safetyTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getdesign() {
		return designEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getrimType() {
		return rimTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getthreadType() {
		return threadTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleFactory getVehicleFactory() {
		return (VehicleFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		supportElementEClass = createEClass(SUPPORT_ELEMENT);
		createEAttribute(supportElementEClass, SUPPORT_ELEMENT__NAME);

		chassisEClass = createEClass(CHASSIS);
		createEAttribute(chassisEClass, CHASSIS__ACCESSORIES);
		createEAttribute(chassisEClass, CHASSIS__NAME);
		createEReference(chassisEClass, CHASSIS__LOAD_BEARING_ELEMENT);
		createEReference(chassisEClass, CHASSIS__TRANSPORTRANGE);
		createEReference(chassisEClass, CHASSIS__WINDOW);
		createEReference(chassisEClass, CHASSIS__DOOR);
		createEReference(chassisEClass, CHASSIS__INFORMATIONFACILITY);
		createEReference(chassisEClass, CHASSIS__STAYINGPOSSIBILITY);
		createEReference(chassisEClass, CHASSIS__SIT);
		createEReference(chassisEClass, CHASSIS__SAFETYDEVICE);

		wheelEClass = createEClass(WHEEL);
		createEAttribute(wheelEClass, WHEEL__NAME);
		createEAttribute(wheelEClass, WHEEL__FASTENING);
		createEAttribute(wheelEClass, WHEEL__RIM);
		createEAttribute(wheelEClass, WHEEL__THREAD);
		createEReference(wheelEClass, WHEEL__BRAKE);
		createEReference(wheelEClass, WHEEL__CHASSIS);

		controlElementEClass = createEClass(CONTROL_ELEMENT);
		createEAttribute(controlElementEClass, CONTROL_ELEMENT__NAME);
		createEAttribute(controlElementEClass, CONTROL_ELEMENT__TYPE);

		taxAreaEClass = createEClass(TAX_AREA);
		createEAttribute(taxAreaEClass, TAX_AREA__NAME);
		createEReference(taxAreaEClass, TAX_AREA__CONTROLELEMENT);
		createEReference(taxAreaEClass, TAX_AREA__INFORMATIONFACILITY);
		createEReference(taxAreaEClass, TAX_AREA__DOOR);
		createEReference(taxAreaEClass, TAX_AREA__SAFETYDEVICE);
		createEReference(taxAreaEClass, TAX_AREA__WINDOW);

		seatEClass = createEClass(SEAT);
		createEAttribute(seatEClass, SEAT__TYPE);

		loungeAreaEClass = createEClass(LOUNGE_AREA);
		createEAttribute(loungeAreaEClass, LOUNGE_AREA__NAME);
		createEReference(loungeAreaEClass, LOUNGE_AREA__WINDOW);
		createEReference(loungeAreaEClass, LOUNGE_AREA__DOOR);

		personEClass = createEClass(PERSON);
		createEAttribute(personEClass, PERSON__NAME);
		createEReference(personEClass, PERSON__SEAT);

		doorEClass = createEClass(DOOR);
		createEAttribute(doorEClass, DOOR__NAME);
		createEReference(doorEClass, DOOR__WINDOW);
		createEReference(doorEClass, DOOR__CONTROLELEMENT);

		windowEClass = createEClass(WINDOW);
		createEAttribute(windowEClass, WINDOW__NAME);
		createEAttribute(windowEClass, WINDOW__MOVABLE);

		safetyDeviceEClass = createEClass(SAFETY_DEVICE);
		createEAttribute(safetyDeviceEClass, SAFETY_DEVICE__NAME);
		createEAttribute(safetyDeviceEClass, SAFETY_DEVICE__TYPE);

		driveEClass = createEClass(DRIVE);
		createEAttribute(driveEClass, DRIVE__FUEL);
		createEAttribute(driveEClass, DRIVE__NAME);

		meansofTransportationEClass = createEClass(MEANSOF_TRANSPORTATION);
		createEAttribute(meansofTransportationEClass, MEANSOF_TRANSPORTATION__NAME);
		createEReference(meansofTransportationEClass, MEANSOF_TRANSPORTATION__CHASSIS);
		createEReference(meansofTransportationEClass, MEANSOF_TRANSPORTATION__PERSON);
		createEReference(meansofTransportationEClass, MEANSOF_TRANSPORTATION__POWERTRANSMISSION);
		createEReference(meansofTransportationEClass, MEANSOF_TRANSPORTATION__DRIVE);
		createEAttribute(meansofTransportationEClass, MEANSOF_TRANSPORTATION__NAMUFACTURER);
		createEAttribute(meansofTransportationEClass, MEANSOF_TRANSPORTATION__PRICE);
		createEReference(meansofTransportationEClass, MEANSOF_TRANSPORTATION__WHEEL);

		brakeEClass = createEClass(BRAKE);
		createEAttribute(brakeEClass, BRAKE__TYPE);

		vehicleModelEClass = createEClass(VEHICLE_MODEL);
		createEAttribute(vehicleModelEClass, VEHICLE_MODEL__NAME);
		createEReference(vehicleModelEClass, VEHICLE_MODEL__MEANSOFTRANSPORTATION);

		powerTransmissionEClass = createEClass(POWER_TRANSMISSION);
		createEAttribute(powerTransmissionEClass, POWER_TRANSMISSION__NAME);
		createEAttribute(powerTransmissionEClass, POWER_TRANSMISSION__WIDE);

		luggageRangeEClass = createEClass(LUGGAGE_RANGE);
		createEAttribute(luggageRangeEClass, LUGGAGE_RANGE__NAME);
		createEReference(luggageRangeEClass, LUGGAGE_RANGE__WINDOW);
		createEReference(luggageRangeEClass, LUGGAGE_RANGE__DOOR);

		informationFacilityEClass = createEClass(INFORMATION_FACILITY);
		createEAttribute(informationFacilityEClass, INFORMATION_FACILITY__NAME);
		createEAttribute(informationFacilityEClass, INFORMATION_FACILITY__TYPE);

		// Create enums
		exteriorAccessoriesEEnum = createEEnum(EXTERIOR_ACCESSORIES);
		taxTypeEEnum = createEEnum(TAX_TYPE);
		seatTypeEEnum = createEEnum(SEAT_TYPE);
		infoArtEEnum = createEEnum(INFO_ART);
		fuelTypeEEnum = createEEnum(FUEL_TYPE);
		brakeTypeEEnum = createEEnum(BRAKE_TYPE);
		safetyTypeEEnum = createEEnum(SAFETY_TYPE);
		designEEnum = createEEnum(DESIGN);
		rimTypeEEnum = createEEnum(RIM_TYPE);
		threadTypeEEnum = createEEnum(THREAD_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(supportElementEClass, supportElement.class, "supportElement", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getsupportElement_Name(), ecorePackage.getEString(), "name", null, 0, 1, supportElement.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(chassisEClass, chassis.class, "chassis", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getchassis_Accessories(), this.getexteriorAccessories(), "Accessories", "camera", 0, 1,
				chassis.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getchassis_Name(), ecorePackage.getEString(), "name", null, 1, 1, chassis.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getchassis_LoadBearingElement(), this.getsupportElement(), null, "loadBearingElement", null, 0,
				-1, chassis.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getchassis_Transportrange(), this.getluggageRange(), null, "transportrange", null, 0, -1,
				chassis.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getchassis_Window(), this.getwindow(), null, "window", null, 0, -1, chassis.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getchassis_Door(), this.getdoor(), null, "door", null, 0, -1, chassis.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getchassis_Informationfacility(), this.getinformationFacility(), null, "informationfacility",
				null, 0, -1, chassis.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getchassis_Stayingpossibility(), this.getloungeArea(), null, "stayingpossibility", null, 0, -1,
				chassis.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getchassis_Sit(), this.getseat(), null, "sit", null, 0, -1, chassis.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getchassis_Safetydevice(), this.getsafetyDevice(), null, "safetydevice", null, 0, -1,
				chassis.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(wheelEClass, Wheel.class, "Wheel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getWheel_Name(), ecorePackage.getEString(), "name", "", 1, 1, Wheel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWheel_Fastening(), this.getdesign(), "fastening", null, 0, 1, Wheel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWheel_Rim(), this.getrimType(), "rim", "steel", 0, 1, Wheel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWheel_Thread(), this.getthreadType(), "thread", null, 0, 1, Wheel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWheel_Brake(), this.getbrake(), null, "brake", null, 0, -1, Wheel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getWheel_Chassis(), this.getchassis(), null, "chassis", null, 1, 1, Wheel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(controlElementEClass, controlElement.class, "controlElement", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getcontrolElement_Name(), ecorePackage.getEString(), "name", null, 1, 1, controlElement.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getcontrolElement_Type(), this.gettaxType(), "type", null, 1, 1, controlElement.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(taxAreaEClass, taxArea.class, "taxArea", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(gettaxArea_Name(), ecorePackage.getEString(), "name", null, 1, 1, taxArea.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(gettaxArea_Controlelement(), this.getcontrolElement(), null, "controlelement", null, 1, -1,
				taxArea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(gettaxArea_Informationfacility(), this.getinformationFacility(), null, "informationfacility",
				null, 0, 1, taxArea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(gettaxArea_Door(), this.getdoor(), null, "door", null, 0, -1, taxArea.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(gettaxArea_Safetydevice(), this.getsafetyDevice(), null, "safetydevice", null, 0, -1,
				taxArea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(gettaxArea_Window(), this.getwindow(), null, "window", null, 0, -1, taxArea.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(seatEClass, seat.class, "seat", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getseat_Type(), this.getseatType(), "type", null, 0, 1, seat.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(loungeAreaEClass, loungeArea.class, "loungeArea", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getloungeArea_Name(), ecorePackage.getEString(), "name", null, 1, 1, loungeArea.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getloungeArea_Window(), this.getwindow(), null, "window", null, 0, -1, loungeArea.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getloungeArea_Door(), this.getdoor(), null, "door", null, 0, -1, loungeArea.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(personEClass, person.class, "person", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getperson_Name(), ecorePackage.getEString(), "name", null, 1, 1, person.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getperson_Seat(), this.getseat(), null, "seat", null, 0, 1, person.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(doorEClass, door.class, "door", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getdoor_Name(), ecorePackage.getEString(), "name", null, 1, 1, door.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getdoor_Window(), this.getwindow(), null, "window", null, 0, 1, door.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getdoor_Controlelement(), this.getcontrolElement(), null, "controlelement", null, 0, -1,
				door.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(windowEClass, window.class, "window", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getwindow_Name(), ecorePackage.getEString(), "name", null, 0, 1, window.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getwindow_Movable(), ecorePackage.getEBoolean(), "movable", "true", 1, 1, window.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(safetyDeviceEClass, safetyDevice.class, "safetyDevice", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getsafetyDevice_Name(), ecorePackage.getEString(), "name", null, 0, 1, safetyDevice.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getsafetyDevice_Type(), this.getsafetyType(), "type", null, 0, 1, safetyDevice.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(driveEClass, drive.class, "drive", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getdrive_Fuel(), this.getfuelType(), "fuel", "noCombustion", 0, 1, drive.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getdrive_Name(), ecorePackage.getEString(), "name", null, 0, 1, drive.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(meansofTransportationEClass, meansofTransportation.class, "meansofTransportation", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getmeansofTransportation_Name(), ecorePackage.getEString(), "name", null, 1, 1,
				meansofTransportation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getmeansofTransportation_Chassis(), this.getchassis(), null, "chassis", null, 1, -1,
				meansofTransportation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getmeansofTransportation_Person(), this.getperson(), null, "person", null, 0, -1,
				meansofTransportation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getmeansofTransportation_Powertransmission(), this.getpowerTransmission(), null,
				"powertransmission", null, 0, -1, meansofTransportation.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getmeansofTransportation_Drive(), this.getdrive(), null, "drive", null, 0, -1,
				meansofTransportation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getmeansofTransportation_Namufacturer(), ecorePackage.getEString(), "namufacturer", null, 0, 1,
				meansofTransportation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getmeansofTransportation_Price(), ecorePackage.getEInt(), "price", null, 0, 1,
				meansofTransportation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getmeansofTransportation_Wheel(), this.getWheel(), null, "wheel", null, 0, -1,
				meansofTransportation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(brakeEClass, brake.class, "brake", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getbrake_Type(), this.getbrakeType(), "type", null, 0, 1, brake.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(vehicleModelEClass, vehicleModel.class, "vehicleModel", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getvehicleModel_Name(), ecorePackage.getEString(), "name", null, 1, 1, vehicleModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getvehicleModel_Meansoftransportation(), this.getmeansofTransportation(), null,
				"meansoftransportation", null, 0, -1, vehicleModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(powerTransmissionEClass, powerTransmission.class, "powerTransmission", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getpowerTransmission_Name(), ecorePackage.getEString(), "name", null, 1, 1,
				powerTransmission.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getpowerTransmission_Wide(), ecorePackage.getEBoolean(), "wide", "true", 1, 1,
				powerTransmission.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(luggageRangeEClass, luggageRange.class, "luggageRange", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getluggageRange_Name(), ecorePackage.getEString(), "name", null, 1, 1, luggageRange.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getluggageRange_Window(), this.getwindow(), null, "window", null, 0, -1, luggageRange.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getluggageRange_Door(), this.getdoor(), null, "door", null, 0, -1, luggageRange.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(informationFacilityEClass, informationFacility.class, "informationFacility", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getinformationFacility_Name(), ecorePackage.getEString(), "name", null, 0, 1,
				informationFacility.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getinformationFacility_Type(), this.getsafetyType(), "type", null, 0, 1,
				informationFacility.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(exteriorAccessoriesEEnum, exteriorAccessories.class, "exteriorAccessories");
		addEEnumLiteral(exteriorAccessoriesEEnum, exteriorAccessories.CAMERA);
		addEEnumLiteral(exteriorAccessoriesEEnum, exteriorAccessories.LIGHT);
		addEEnumLiteral(exteriorAccessoriesEEnum, exteriorAccessories.MIRROR);
		addEEnumLiteral(exteriorAccessoriesEEnum, exteriorAccessories.WING);

		initEEnum(taxTypeEEnum, taxType.class, "taxType");
		addEEnumLiteral(taxTypeEEnum, taxType.WHEEL);
		addEEnumLiteral(taxTypeEEnum, taxType.PEDAL);
		addEEnumLiteral(taxTypeEEnum, taxType.BUTTON);
		addEEnumLiteral(taxTypeEEnum, taxType.SWITCH);

		initEEnum(seatTypeEEnum, seatType.class, "seatType");
		addEEnumLiteral(seatTypeEEnum, seatType.SINGLE_SEAT);
		addEEnumLiteral(seatTypeEEnum, seatType.DOUBLE_SEAT);
		addEEnumLiteral(seatTypeEEnum, seatType.TRIPPLE_SEAT);
		addEEnumLiteral(seatTypeEEnum, seatType.FOUR_SEAT);

		initEEnum(infoArtEEnum, InfoArt.class, "InfoArt");
		addEEnumLiteral(infoArtEEnum, InfoArt.LAMP);
		addEEnumLiteral(infoArtEEnum, InfoArt.INDICATOR);
		addEEnumLiteral(infoArtEEnum, InfoArt.DISPLAY);

		initEEnum(fuelTypeEEnum, fuelType.class, "fuelType");
		addEEnumLiteral(fuelTypeEEnum, fuelType.NO_COMBUSTION);
		addEEnumLiteral(fuelTypeEEnum, fuelType.PETROL);
		addEEnumLiteral(fuelTypeEEnum, fuelType.DIESEL);

		initEEnum(brakeTypeEEnum, brakeType.class, "brakeType");
		addEEnumLiteral(brakeTypeEEnum, brakeType.DISC_BRAKE);
		addEEnumLiteral(brakeTypeEEnum, brakeType.DRUM_BRAKE);

		initEEnum(safetyTypeEEnum, safetyType.class, "safetyType");
		addEEnumLiteral(safetyTypeEEnum, safetyType.BRAKE);
		addEEnumLiteral(safetyTypeEEnum, safetyType.FASTENING);
		addEEnumLiteral(safetyTypeEEnum, safetyType.SIGN);

		initEEnum(designEEnum, design.class, "design");
		addEEnumLiteral(designEEnum, design.SUSPENSION);
		addEEnumLiteral(designEEnum, design.RIGID_AXIS);
		addEEnumLiteral(designEEnum, design.COMPONENT_AXIS);

		initEEnum(rimTypeEEnum, rimType.class, "rimType");
		addEEnumLiteral(rimTypeEEnum, rimType.STEEL);
		addEEnumLiteral(rimTypeEEnum, rimType.ALUMINIUM);
		addEEnumLiteral(rimTypeEEnum, rimType.OTHER);

		initEEnum(threadTypeEEnum, threadType.class, "threadType");
		addEEnumLiteral(threadTypeEEnum, threadType.RUBBER);
		addEEnumLiteral(threadTypeEEnum, threadType.STEEL);
		addEEnumLiteral(threadTypeEEnum, threadType.OTHER);

		// Create resource
		createResource(eNS_URI);
	}

} //VehiclePackageImpl
