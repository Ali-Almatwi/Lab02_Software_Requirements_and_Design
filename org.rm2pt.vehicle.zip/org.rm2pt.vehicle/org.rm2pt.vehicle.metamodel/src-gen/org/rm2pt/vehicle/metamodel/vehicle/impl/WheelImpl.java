/**
 */
package org.rm2pt.vehicle.metamodel.vehicle.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage;
import org.rm2pt.vehicle.metamodel.vehicle.Wheel;
import org.rm2pt.vehicle.metamodel.vehicle.brake;
import org.rm2pt.vehicle.metamodel.vehicle.chassis;
import org.rm2pt.vehicle.metamodel.vehicle.design;
import org.rm2pt.vehicle.metamodel.vehicle.rimType;
import org.rm2pt.vehicle.metamodel.vehicle.threadType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Wheel</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.WheelImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.WheelImpl#getFastening <em>Fastening</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.WheelImpl#getRim <em>Rim</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.WheelImpl#getThread <em>Thread</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.WheelImpl#getBrake <em>Brake</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.WheelImpl#getChassis <em>Chassis</em>}</li>
 * </ul>
 *
 * @generated
 */
public class WheelImpl extends MinimalEObjectImpl.Container implements Wheel {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getFastening() <em>Fastening</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFastening()
	 * @generated
	 * @ordered
	 */
	protected static final design FASTENING_EDEFAULT = design.SUSPENSION;

	/**
	 * The cached value of the '{@link #getFastening() <em>Fastening</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFastening()
	 * @generated
	 * @ordered
	 */
	protected design fastening = FASTENING_EDEFAULT;

	/**
	 * The default value of the '{@link #getRim() <em>Rim</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRim()
	 * @generated
	 * @ordered
	 */
	protected static final rimType RIM_EDEFAULT = rimType.STEEL;

	/**
	 * The cached value of the '{@link #getRim() <em>Rim</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRim()
	 * @generated
	 * @ordered
	 */
	protected rimType rim = RIM_EDEFAULT;

	/**
	 * The default value of the '{@link #getThread() <em>Thread</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThread()
	 * @generated
	 * @ordered
	 */
	protected static final threadType THREAD_EDEFAULT = threadType.RUBBER;

	/**
	 * The cached value of the '{@link #getThread() <em>Thread</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThread()
	 * @generated
	 * @ordered
	 */
	protected threadType thread = THREAD_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBrake() <em>Brake</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBrake()
	 * @generated
	 * @ordered
	 */
	protected EList<brake> brake;

	/**
	 * The cached value of the '{@link #getChassis() <em>Chassis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChassis()
	 * @generated
	 * @ordered
	 */
	protected chassis chassis;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WheelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return VehiclePackage.Literals.WHEEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.WHEEL__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public design getFastening() {
		return fastening;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFastening(design newFastening) {
		design oldFastening = fastening;
		fastening = newFastening == null ? FASTENING_EDEFAULT : newFastening;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.WHEEL__FASTENING, oldFastening,
					fastening));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public rimType getRim() {
		return rim;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRim(rimType newRim) {
		rimType oldRim = rim;
		rim = newRim == null ? RIM_EDEFAULT : newRim;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.WHEEL__RIM, oldRim, rim));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public threadType getThread() {
		return thread;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setThread(threadType newThread) {
		threadType oldThread = thread;
		thread = newThread == null ? THREAD_EDEFAULT : newThread;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.WHEEL__THREAD, oldThread, thread));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<brake> getBrake() {
		if (brake == null) {
			brake = new EObjectContainmentEList<brake>(brake.class, this, VehiclePackage.WHEEL__BRAKE);
		}
		return brake;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public chassis getChassis() {
		if (chassis != null && chassis.eIsProxy()) {
			InternalEObject oldChassis = (InternalEObject) chassis;
			chassis = (chassis) eResolveProxy(oldChassis);
			if (chassis != oldChassis) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, VehiclePackage.WHEEL__CHASSIS, oldChassis,
							chassis));
			}
		}
		return chassis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public chassis basicGetChassis() {
		return chassis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setChassis(chassis newChassis) {
		chassis oldChassis = chassis;
		chassis = newChassis;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.WHEEL__CHASSIS, oldChassis, chassis));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case VehiclePackage.WHEEL__BRAKE:
			return ((InternalEList<?>) getBrake()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case VehiclePackage.WHEEL__NAME:
			return getName();
		case VehiclePackage.WHEEL__FASTENING:
			return getFastening();
		case VehiclePackage.WHEEL__RIM:
			return getRim();
		case VehiclePackage.WHEEL__THREAD:
			return getThread();
		case VehiclePackage.WHEEL__BRAKE:
			return getBrake();
		case VehiclePackage.WHEEL__CHASSIS:
			if (resolve)
				return getChassis();
			return basicGetChassis();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case VehiclePackage.WHEEL__NAME:
			setName((String) newValue);
			return;
		case VehiclePackage.WHEEL__FASTENING:
			setFastening((design) newValue);
			return;
		case VehiclePackage.WHEEL__RIM:
			setRim((rimType) newValue);
			return;
		case VehiclePackage.WHEEL__THREAD:
			setThread((threadType) newValue);
			return;
		case VehiclePackage.WHEEL__BRAKE:
			getBrake().clear();
			getBrake().addAll((Collection<? extends brake>) newValue);
			return;
		case VehiclePackage.WHEEL__CHASSIS:
			setChassis((chassis) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case VehiclePackage.WHEEL__NAME:
			setName(NAME_EDEFAULT);
			return;
		case VehiclePackage.WHEEL__FASTENING:
			setFastening(FASTENING_EDEFAULT);
			return;
		case VehiclePackage.WHEEL__RIM:
			setRim(RIM_EDEFAULT);
			return;
		case VehiclePackage.WHEEL__THREAD:
			setThread(THREAD_EDEFAULT);
			return;
		case VehiclePackage.WHEEL__BRAKE:
			getBrake().clear();
			return;
		case VehiclePackage.WHEEL__CHASSIS:
			setChassis((chassis) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case VehiclePackage.WHEEL__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case VehiclePackage.WHEEL__FASTENING:
			return fastening != FASTENING_EDEFAULT;
		case VehiclePackage.WHEEL__RIM:
			return rim != RIM_EDEFAULT;
		case VehiclePackage.WHEEL__THREAD:
			return thread != THREAD_EDEFAULT;
		case VehiclePackage.WHEEL__BRAKE:
			return brake != null && !brake.isEmpty();
		case VehiclePackage.WHEEL__CHASSIS:
			return chassis != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", fastening: ");
		result.append(fastening);
		result.append(", rim: ");
		result.append(rim);
		result.append(", thread: ");
		result.append(thread);
		result.append(')');
		return result.toString();
	}

} //WheelImpl
