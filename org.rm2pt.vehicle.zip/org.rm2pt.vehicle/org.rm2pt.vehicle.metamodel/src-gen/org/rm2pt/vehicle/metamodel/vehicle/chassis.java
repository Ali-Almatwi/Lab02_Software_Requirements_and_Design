/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>chassis</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getAccessories <em>Accessories</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getLoadBearingElement <em>Load Bearing Element</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getTransportrange <em>Transportrange</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getWindow <em>Window</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getDoor <em>Door</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getInformationfacility <em>Informationfacility</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getStayingpossibility <em>Stayingpossibility</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getSit <em>Sit</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getSafetydevice <em>Safetydevice</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis()
 * @model
 * @generated
 */
public interface chassis extends EObject {
	/**
	 * Returns the value of the '<em><b>Accessories</b></em>' attribute.
	 * The default value is <code>"camera"</code>.
	 * The literals are from the enumeration {@link org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Accessories</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories
	 * @see #setAccessories(exteriorAccessories)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis_Accessories()
	 * @model default="camera"
	 * @generated
	 */
	exteriorAccessories getAccessories();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getAccessories <em>Accessories</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Accessories</em>' attribute.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.exteriorAccessories
	 * @see #getAccessories()
	 * @generated
	 */
	void setAccessories(exteriorAccessories value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.vehicle.metamodel.vehicle.chassis#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Load Bearing Element</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.supportElement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Load Bearing Element</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis_LoadBearingElement()
	 * @model containment="true"
	 * @generated
	 */
	EList<supportElement> getLoadBearingElement();

	/**
	 * Returns the value of the '<em><b>Transportrange</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.luggageRange}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transportrange</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis_Transportrange()
	 * @model containment="true"
	 * @generated
	 */
	EList<luggageRange> getTransportrange();

	/**
	 * Returns the value of the '<em><b>Window</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.window}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Window</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis_Window()
	 * @model containment="true"
	 * @generated
	 */
	EList<window> getWindow();

	/**
	 * Returns the value of the '<em><b>Door</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.door}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Door</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis_Door()
	 * @model containment="true"
	 * @generated
	 */
	EList<door> getDoor();

	/**
	 * Returns the value of the '<em><b>Informationfacility</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.informationFacility}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Informationfacility</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis_Informationfacility()
	 * @model containment="true"
	 * @generated
	 */
	EList<informationFacility> getInformationfacility();

	/**
	 * Returns the value of the '<em><b>Stayingpossibility</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.loungeArea}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stayingpossibility</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis_Stayingpossibility()
	 * @model containment="true"
	 * @generated
	 */
	EList<loungeArea> getStayingpossibility();

	/**
	 * Returns the value of the '<em><b>Sit</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.seat}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sit</em>' containment reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis_Sit()
	 * @model containment="true"
	 * @generated
	 */
	EList<seat> getSit();

	/**
	 * Returns the value of the '<em><b>Safetydevice</b></em>' reference list.
	 * The list contents are of type {@link org.rm2pt.vehicle.metamodel.vehicle.safetyDevice}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Safetydevice</em>' reference list.
	 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage#getchassis_Safetydevice()
	 * @model
	 * @generated
	 */
	EList<safetyDevice> getSafetydevice();

} // chassis
