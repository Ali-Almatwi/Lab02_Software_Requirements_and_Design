/**
 */
package org.rm2pt.vehicle.metamodel.vehicle.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage;
import org.rm2pt.vehicle.metamodel.vehicle.door;
import org.rm2pt.vehicle.metamodel.vehicle.luggageRange;
import org.rm2pt.vehicle.metamodel.vehicle.window;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>luggage Range</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.luggageRangeImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.luggageRangeImpl#getWindow <em>Window</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.luggageRangeImpl#getDoor <em>Door</em>}</li>
 * </ul>
 *
 * @generated
 */
public class luggageRangeImpl extends MinimalEObjectImpl.Container implements luggageRange {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getWindow() <em>Window</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWindow()
	 * @generated
	 * @ordered
	 */
	protected EList<window> window;

	/**
	 * The cached value of the '{@link #getDoor() <em>Door</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoor()
	 * @generated
	 * @ordered
	 */
	protected EList<door> door;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected luggageRangeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return VehiclePackage.Literals.LUGGAGE_RANGE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.LUGGAGE_RANGE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<window> getWindow() {
		if (window == null) {
			window = new EObjectResolvingEList<window>(window.class, this, VehiclePackage.LUGGAGE_RANGE__WINDOW);
		}
		return window;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<door> getDoor() {
		if (door == null) {
			door = new EObjectResolvingEList<door>(door.class, this, VehiclePackage.LUGGAGE_RANGE__DOOR);
		}
		return door;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case VehiclePackage.LUGGAGE_RANGE__NAME:
			return getName();
		case VehiclePackage.LUGGAGE_RANGE__WINDOW:
			return getWindow();
		case VehiclePackage.LUGGAGE_RANGE__DOOR:
			return getDoor();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case VehiclePackage.LUGGAGE_RANGE__NAME:
			setName((String) newValue);
			return;
		case VehiclePackage.LUGGAGE_RANGE__WINDOW:
			getWindow().clear();
			getWindow().addAll((Collection<? extends window>) newValue);
			return;
		case VehiclePackage.LUGGAGE_RANGE__DOOR:
			getDoor().clear();
			getDoor().addAll((Collection<? extends door>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case VehiclePackage.LUGGAGE_RANGE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case VehiclePackage.LUGGAGE_RANGE__WINDOW:
			getWindow().clear();
			return;
		case VehiclePackage.LUGGAGE_RANGE__DOOR:
			getDoor().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case VehiclePackage.LUGGAGE_RANGE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case VehiclePackage.LUGGAGE_RANGE__WINDOW:
			return window != null && !window.isEmpty();
		case VehiclePackage.LUGGAGE_RANGE__DOOR:
			return door != null && !door.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //luggageRangeImpl
