/**
 */
package org.rm2pt.vehicle.metamodel.vehicle.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage;
import org.rm2pt.vehicle.metamodel.vehicle.Wheel;
import org.rm2pt.vehicle.metamodel.vehicle.chassis;
import org.rm2pt.vehicle.metamodel.vehicle.drive;
import org.rm2pt.vehicle.metamodel.vehicle.meansofTransportation;
import org.rm2pt.vehicle.metamodel.vehicle.person;
import org.rm2pt.vehicle.metamodel.vehicle.powerTransmission;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>meansof Transportation</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl#getChassis <em>Chassis</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl#getPerson <em>Person</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl#getPowertransmission <em>Powertransmission</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl#getDrive <em>Drive</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl#getNamufacturer <em>Namufacturer</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl#getPrice <em>Price</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.meansofTransportationImpl#getWheel <em>Wheel</em>}</li>
 * </ul>
 *
 * @generated
 */
public class meansofTransportationImpl extends MinimalEObjectImpl.Container implements meansofTransportation {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getChassis() <em>Chassis</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChassis()
	 * @generated
	 * @ordered
	 */
	protected EList<chassis> chassis;

	/**
	 * The cached value of the '{@link #getPerson() <em>Person</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPerson()
	 * @generated
	 * @ordered
	 */
	protected EList<person> person;

	/**
	 * The cached value of the '{@link #getPowertransmission() <em>Powertransmission</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPowertransmission()
	 * @generated
	 * @ordered
	 */
	protected EList<powerTransmission> powertransmission;

	/**
	 * The cached value of the '{@link #getDrive() <em>Drive</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDrive()
	 * @generated
	 * @ordered
	 */
	protected EList<drive> drive;

	/**
	 * The default value of the '{@link #getNamufacturer() <em>Namufacturer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNamufacturer()
	 * @generated
	 * @ordered
	 */
	protected static final String NAMUFACTURER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNamufacturer() <em>Namufacturer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNamufacturer()
	 * @generated
	 * @ordered
	 */
	protected String namufacturer = NAMUFACTURER_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected static final int PRICE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected int price = PRICE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getWheel() <em>Wheel</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWheel()
	 * @generated
	 * @ordered
	 */
	protected EList<Wheel> wheel;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected meansofTransportationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return VehiclePackage.Literals.MEANSOF_TRANSPORTATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.MEANSOF_TRANSPORTATION__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<chassis> getChassis() {
		if (chassis == null) {
			chassis = new EObjectContainmentEList<chassis>(chassis.class, this,
					VehiclePackage.MEANSOF_TRANSPORTATION__CHASSIS);
		}
		return chassis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<person> getPerson() {
		if (person == null) {
			person = new EObjectContainmentEList<person>(person.class, this,
					VehiclePackage.MEANSOF_TRANSPORTATION__PERSON);
		}
		return person;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<powerTransmission> getPowertransmission() {
		if (powertransmission == null) {
			powertransmission = new EObjectContainmentEList<powerTransmission>(powerTransmission.class, this,
					VehiclePackage.MEANSOF_TRANSPORTATION__POWERTRANSMISSION);
		}
		return powertransmission;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<drive> getDrive() {
		if (drive == null) {
			drive = new EObjectContainmentEList<drive>(drive.class, this, VehiclePackage.MEANSOF_TRANSPORTATION__DRIVE);
		}
		return drive;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNamufacturer() {
		return namufacturer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNamufacturer(String newNamufacturer) {
		String oldNamufacturer = namufacturer;
		namufacturer = newNamufacturer;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.MEANSOF_TRANSPORTATION__NAMUFACTURER,
					oldNamufacturer, namufacturer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPrice() {
		return price;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrice(int newPrice) {
		int oldPrice = price;
		price = newPrice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.MEANSOF_TRANSPORTATION__PRICE,
					oldPrice, price));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Wheel> getWheel() {
		if (wheel == null) {
			wheel = new EObjectContainmentEList<Wheel>(Wheel.class, this, VehiclePackage.MEANSOF_TRANSPORTATION__WHEEL);
		}
		return wheel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case VehiclePackage.MEANSOF_TRANSPORTATION__CHASSIS:
			return ((InternalEList<?>) getChassis()).basicRemove(otherEnd, msgs);
		case VehiclePackage.MEANSOF_TRANSPORTATION__PERSON:
			return ((InternalEList<?>) getPerson()).basicRemove(otherEnd, msgs);
		case VehiclePackage.MEANSOF_TRANSPORTATION__POWERTRANSMISSION:
			return ((InternalEList<?>) getPowertransmission()).basicRemove(otherEnd, msgs);
		case VehiclePackage.MEANSOF_TRANSPORTATION__DRIVE:
			return ((InternalEList<?>) getDrive()).basicRemove(otherEnd, msgs);
		case VehiclePackage.MEANSOF_TRANSPORTATION__WHEEL:
			return ((InternalEList<?>) getWheel()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case VehiclePackage.MEANSOF_TRANSPORTATION__NAME:
			return getName();
		case VehiclePackage.MEANSOF_TRANSPORTATION__CHASSIS:
			return getChassis();
		case VehiclePackage.MEANSOF_TRANSPORTATION__PERSON:
			return getPerson();
		case VehiclePackage.MEANSOF_TRANSPORTATION__POWERTRANSMISSION:
			return getPowertransmission();
		case VehiclePackage.MEANSOF_TRANSPORTATION__DRIVE:
			return getDrive();
		case VehiclePackage.MEANSOF_TRANSPORTATION__NAMUFACTURER:
			return getNamufacturer();
		case VehiclePackage.MEANSOF_TRANSPORTATION__PRICE:
			return getPrice();
		case VehiclePackage.MEANSOF_TRANSPORTATION__WHEEL:
			return getWheel();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case VehiclePackage.MEANSOF_TRANSPORTATION__NAME:
			setName((String) newValue);
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__CHASSIS:
			getChassis().clear();
			getChassis().addAll((Collection<? extends chassis>) newValue);
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__PERSON:
			getPerson().clear();
			getPerson().addAll((Collection<? extends person>) newValue);
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__POWERTRANSMISSION:
			getPowertransmission().clear();
			getPowertransmission().addAll((Collection<? extends powerTransmission>) newValue);
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__DRIVE:
			getDrive().clear();
			getDrive().addAll((Collection<? extends drive>) newValue);
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__NAMUFACTURER:
			setNamufacturer((String) newValue);
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__PRICE:
			setPrice((Integer) newValue);
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__WHEEL:
			getWheel().clear();
			getWheel().addAll((Collection<? extends Wheel>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case VehiclePackage.MEANSOF_TRANSPORTATION__NAME:
			setName(NAME_EDEFAULT);
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__CHASSIS:
			getChassis().clear();
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__PERSON:
			getPerson().clear();
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__POWERTRANSMISSION:
			getPowertransmission().clear();
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__DRIVE:
			getDrive().clear();
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__NAMUFACTURER:
			setNamufacturer(NAMUFACTURER_EDEFAULT);
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__PRICE:
			setPrice(PRICE_EDEFAULT);
			return;
		case VehiclePackage.MEANSOF_TRANSPORTATION__WHEEL:
			getWheel().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case VehiclePackage.MEANSOF_TRANSPORTATION__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case VehiclePackage.MEANSOF_TRANSPORTATION__CHASSIS:
			return chassis != null && !chassis.isEmpty();
		case VehiclePackage.MEANSOF_TRANSPORTATION__PERSON:
			return person != null && !person.isEmpty();
		case VehiclePackage.MEANSOF_TRANSPORTATION__POWERTRANSMISSION:
			return powertransmission != null && !powertransmission.isEmpty();
		case VehiclePackage.MEANSOF_TRANSPORTATION__DRIVE:
			return drive != null && !drive.isEmpty();
		case VehiclePackage.MEANSOF_TRANSPORTATION__NAMUFACTURER:
			return NAMUFACTURER_EDEFAULT == null ? namufacturer != null : !NAMUFACTURER_EDEFAULT.equals(namufacturer);
		case VehiclePackage.MEANSOF_TRANSPORTATION__PRICE:
			return price != PRICE_EDEFAULT;
		case VehiclePackage.MEANSOF_TRANSPORTATION__WHEEL:
			return wheel != null && !wheel.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", namufacturer: ");
		result.append(namufacturer);
		result.append(", price: ");
		result.append(price);
		result.append(')');
		return result.toString();
	}

} //meansofTransportationImpl
