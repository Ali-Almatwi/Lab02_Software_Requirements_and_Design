/**
 */
package org.rm2pt.vehicle.metamodel.vehicle.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.rm2pt.vehicle.metamodel.vehicle.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class VehicleFactoryImpl extends EFactoryImpl implements VehicleFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static VehicleFactory init() {
		try {
			VehicleFactory theVehicleFactory = (VehicleFactory) EPackage.Registry.INSTANCE
					.getEFactory(VehiclePackage.eNS_URI);
			if (theVehicleFactory != null) {
				return theVehicleFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new VehicleFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case VehiclePackage.SUPPORT_ELEMENT:
			return createsupportElement();
		case VehiclePackage.CHASSIS:
			return createchassis();
		case VehiclePackage.WHEEL:
			return createWheel();
		case VehiclePackage.CONTROL_ELEMENT:
			return createcontrolElement();
		case VehiclePackage.TAX_AREA:
			return createtaxArea();
		case VehiclePackage.SEAT:
			return createseat();
		case VehiclePackage.LOUNGE_AREA:
			return createloungeArea();
		case VehiclePackage.PERSON:
			return createperson();
		case VehiclePackage.DOOR:
			return createdoor();
		case VehiclePackage.WINDOW:
			return createwindow();
		case VehiclePackage.SAFETY_DEVICE:
			return createsafetyDevice();
		case VehiclePackage.DRIVE:
			return createdrive();
		case VehiclePackage.MEANSOF_TRANSPORTATION:
			return createmeansofTransportation();
		case VehiclePackage.BRAKE:
			return createbrake();
		case VehiclePackage.VEHICLE_MODEL:
			return createvehicleModel();
		case VehiclePackage.POWER_TRANSMISSION:
			return createpowerTransmission();
		case VehiclePackage.LUGGAGE_RANGE:
			return createluggageRange();
		case VehiclePackage.INFORMATION_FACILITY:
			return createinformationFacility();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case VehiclePackage.EXTERIOR_ACCESSORIES:
			return createexteriorAccessoriesFromString(eDataType, initialValue);
		case VehiclePackage.TAX_TYPE:
			return createtaxTypeFromString(eDataType, initialValue);
		case VehiclePackage.SEAT_TYPE:
			return createseatTypeFromString(eDataType, initialValue);
		case VehiclePackage.INFO_ART:
			return createInfoArtFromString(eDataType, initialValue);
		case VehiclePackage.FUEL_TYPE:
			return createfuelTypeFromString(eDataType, initialValue);
		case VehiclePackage.BRAKE_TYPE:
			return createbrakeTypeFromString(eDataType, initialValue);
		case VehiclePackage.SAFETY_TYPE:
			return createsafetyTypeFromString(eDataType, initialValue);
		case VehiclePackage.DESIGN:
			return createdesignFromString(eDataType, initialValue);
		case VehiclePackage.RIM_TYPE:
			return createrimTypeFromString(eDataType, initialValue);
		case VehiclePackage.THREAD_TYPE:
			return createthreadTypeFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case VehiclePackage.EXTERIOR_ACCESSORIES:
			return convertexteriorAccessoriesToString(eDataType, instanceValue);
		case VehiclePackage.TAX_TYPE:
			return converttaxTypeToString(eDataType, instanceValue);
		case VehiclePackage.SEAT_TYPE:
			return convertseatTypeToString(eDataType, instanceValue);
		case VehiclePackage.INFO_ART:
			return convertInfoArtToString(eDataType, instanceValue);
		case VehiclePackage.FUEL_TYPE:
			return convertfuelTypeToString(eDataType, instanceValue);
		case VehiclePackage.BRAKE_TYPE:
			return convertbrakeTypeToString(eDataType, instanceValue);
		case VehiclePackage.SAFETY_TYPE:
			return convertsafetyTypeToString(eDataType, instanceValue);
		case VehiclePackage.DESIGN:
			return convertdesignToString(eDataType, instanceValue);
		case VehiclePackage.RIM_TYPE:
			return convertrimTypeToString(eDataType, instanceValue);
		case VehiclePackage.THREAD_TYPE:
			return convertthreadTypeToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public supportElement createsupportElement() {
		supportElementImpl supportElement = new supportElementImpl();
		return supportElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public chassis createchassis() {
		chassisImpl chassis = new chassisImpl();
		return chassis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Wheel createWheel() {
		WheelImpl wheel = new WheelImpl();
		return wheel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public controlElement createcontrolElement() {
		controlElementImpl controlElement = new controlElementImpl();
		return controlElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public taxArea createtaxArea() {
		taxAreaImpl taxArea = new taxAreaImpl();
		return taxArea;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public seat createseat() {
		seatImpl seat = new seatImpl();
		return seat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public loungeArea createloungeArea() {
		loungeAreaImpl loungeArea = new loungeAreaImpl();
		return loungeArea;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public person createperson() {
		personImpl person = new personImpl();
		return person;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public door createdoor() {
		doorImpl door = new doorImpl();
		return door;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public window createwindow() {
		windowImpl window = new windowImpl();
		return window;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public safetyDevice createsafetyDevice() {
		safetyDeviceImpl safetyDevice = new safetyDeviceImpl();
		return safetyDevice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public drive createdrive() {
		driveImpl drive = new driveImpl();
		return drive;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public meansofTransportation createmeansofTransportation() {
		meansofTransportationImpl meansofTransportation = new meansofTransportationImpl();
		return meansofTransportation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public brake createbrake() {
		brakeImpl brake = new brakeImpl();
		return brake;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public vehicleModel createvehicleModel() {
		vehicleModelImpl vehicleModel = new vehicleModelImpl();
		return vehicleModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public powerTransmission createpowerTransmission() {
		powerTransmissionImpl powerTransmission = new powerTransmissionImpl();
		return powerTransmission;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public luggageRange createluggageRange() {
		luggageRangeImpl luggageRange = new luggageRangeImpl();
		return luggageRange;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public informationFacility createinformationFacility() {
		informationFacilityImpl informationFacility = new informationFacilityImpl();
		return informationFacility;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public exteriorAccessories createexteriorAccessoriesFromString(EDataType eDataType, String initialValue) {
		exteriorAccessories result = exteriorAccessories.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertexteriorAccessoriesToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public taxType createtaxTypeFromString(EDataType eDataType, String initialValue) {
		taxType result = taxType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String converttaxTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public seatType createseatTypeFromString(EDataType eDataType, String initialValue) {
		seatType result = seatType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertseatTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InfoArt createInfoArtFromString(EDataType eDataType, String initialValue) {
		InfoArt result = InfoArt.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertInfoArtToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public fuelType createfuelTypeFromString(EDataType eDataType, String initialValue) {
		fuelType result = fuelType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertfuelTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public brakeType createbrakeTypeFromString(EDataType eDataType, String initialValue) {
		brakeType result = brakeType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertbrakeTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public safetyType createsafetyTypeFromString(EDataType eDataType, String initialValue) {
		safetyType result = safetyType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertsafetyTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public design createdesignFromString(EDataType eDataType, String initialValue) {
		design result = design.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertdesignToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public rimType createrimTypeFromString(EDataType eDataType, String initialValue) {
		rimType result = rimType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertrimTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public threadType createthreadTypeFromString(EDataType eDataType, String initialValue) {
		threadType result = threadType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertthreadTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehiclePackage getVehiclePackage() {
		return (VehiclePackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static VehiclePackage getPackage() {
		return VehiclePackage.eINSTANCE;
	}

} //VehicleFactoryImpl
