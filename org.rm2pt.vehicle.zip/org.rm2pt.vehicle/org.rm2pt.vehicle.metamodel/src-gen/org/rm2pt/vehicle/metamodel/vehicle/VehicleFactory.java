/**
 */
package org.rm2pt.vehicle.metamodel.vehicle;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage
 * @generated
 */
public interface VehicleFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	VehicleFactory eINSTANCE = org.rm2pt.vehicle.metamodel.vehicle.impl.VehicleFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>support Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>support Element</em>'.
	 * @generated
	 */
	supportElement createsupportElement();

	/**
	 * Returns a new object of class '<em>chassis</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>chassis</em>'.
	 * @generated
	 */
	chassis createchassis();

	/**
	 * Returns a new object of class '<em>Wheel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Wheel</em>'.
	 * @generated
	 */
	Wheel createWheel();

	/**
	 * Returns a new object of class '<em>control Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>control Element</em>'.
	 * @generated
	 */
	controlElement createcontrolElement();

	/**
	 * Returns a new object of class '<em>tax Area</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>tax Area</em>'.
	 * @generated
	 */
	taxArea createtaxArea();

	/**
	 * Returns a new object of class '<em>seat</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>seat</em>'.
	 * @generated
	 */
	seat createseat();

	/**
	 * Returns a new object of class '<em>lounge Area</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>lounge Area</em>'.
	 * @generated
	 */
	loungeArea createloungeArea();

	/**
	 * Returns a new object of class '<em>person</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>person</em>'.
	 * @generated
	 */
	person createperson();

	/**
	 * Returns a new object of class '<em>door</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>door</em>'.
	 * @generated
	 */
	door createdoor();

	/**
	 * Returns a new object of class '<em>window</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>window</em>'.
	 * @generated
	 */
	window createwindow();

	/**
	 * Returns a new object of class '<em>safety Device</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>safety Device</em>'.
	 * @generated
	 */
	safetyDevice createsafetyDevice();

	/**
	 * Returns a new object of class '<em>drive</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>drive</em>'.
	 * @generated
	 */
	drive createdrive();

	/**
	 * Returns a new object of class '<em>meansof Transportation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>meansof Transportation</em>'.
	 * @generated
	 */
	meansofTransportation createmeansofTransportation();

	/**
	 * Returns a new object of class '<em>brake</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>brake</em>'.
	 * @generated
	 */
	brake createbrake();

	/**
	 * Returns a new object of class '<em>vehicle Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>vehicle Model</em>'.
	 * @generated
	 */
	vehicleModel createvehicleModel();

	/**
	 * Returns a new object of class '<em>power Transmission</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>power Transmission</em>'.
	 * @generated
	 */
	powerTransmission createpowerTransmission();

	/**
	 * Returns a new object of class '<em>luggage Range</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>luggage Range</em>'.
	 * @generated
	 */
	luggageRange createluggageRange();

	/**
	 * Returns a new object of class '<em>information Facility</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>information Facility</em>'.
	 * @generated
	 */
	informationFacility createinformationFacility();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	VehiclePackage getVehiclePackage();

} //VehicleFactory
