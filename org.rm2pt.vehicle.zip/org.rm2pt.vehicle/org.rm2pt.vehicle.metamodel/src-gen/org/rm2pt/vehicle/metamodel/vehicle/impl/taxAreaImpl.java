/**
 */
package org.rm2pt.vehicle.metamodel.vehicle.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.rm2pt.vehicle.metamodel.vehicle.VehiclePackage;
import org.rm2pt.vehicle.metamodel.vehicle.controlElement;
import org.rm2pt.vehicle.metamodel.vehicle.door;
import org.rm2pt.vehicle.metamodel.vehicle.informationFacility;
import org.rm2pt.vehicle.metamodel.vehicle.safetyDevice;
import org.rm2pt.vehicle.metamodel.vehicle.taxArea;
import org.rm2pt.vehicle.metamodel.vehicle.window;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>tax Area</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.taxAreaImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.taxAreaImpl#getControlelement <em>Controlelement</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.taxAreaImpl#getInformationfacility <em>Informationfacility</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.taxAreaImpl#getDoor <em>Door</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.taxAreaImpl#getSafetydevice <em>Safetydevice</em>}</li>
 *   <li>{@link org.rm2pt.vehicle.metamodel.vehicle.impl.taxAreaImpl#getWindow <em>Window</em>}</li>
 * </ul>
 *
 * @generated
 */
public class taxAreaImpl extends MinimalEObjectImpl.Container implements taxArea {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getControlelement() <em>Controlelement</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlelement()
	 * @generated
	 * @ordered
	 */
	protected EList<controlElement> controlelement;

	/**
	 * The cached value of the '{@link #getInformationfacility() <em>Informationfacility</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInformationfacility()
	 * @generated
	 * @ordered
	 */
	protected informationFacility informationfacility;

	/**
	 * The cached value of the '{@link #getDoor() <em>Door</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoor()
	 * @generated
	 * @ordered
	 */
	protected EList<door> door;

	/**
	 * The cached value of the '{@link #getSafetydevice() <em>Safetydevice</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSafetydevice()
	 * @generated
	 * @ordered
	 */
	protected EList<safetyDevice> safetydevice;

	/**
	 * The cached value of the '{@link #getWindow() <em>Window</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWindow()
	 * @generated
	 * @ordered
	 */
	protected EList<window> window;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected taxAreaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return VehiclePackage.Literals.TAX_AREA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.TAX_AREA__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<controlElement> getControlelement() {
		if (controlelement == null) {
			controlelement = new EObjectContainmentEList<controlElement>(controlElement.class, this,
					VehiclePackage.TAX_AREA__CONTROLELEMENT);
		}
		return controlelement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public informationFacility getInformationfacility() {
		if (informationfacility != null && informationfacility.eIsProxy()) {
			InternalEObject oldInformationfacility = (InternalEObject) informationfacility;
			informationfacility = (informationFacility) eResolveProxy(oldInformationfacility);
			if (informationfacility != oldInformationfacility) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							VehiclePackage.TAX_AREA__INFORMATIONFACILITY, oldInformationfacility, informationfacility));
			}
		}
		return informationfacility;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public informationFacility basicGetInformationfacility() {
		return informationfacility;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInformationfacility(informationFacility newInformationfacility) {
		informationFacility oldInformationfacility = informationfacility;
		informationfacility = newInformationfacility;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, VehiclePackage.TAX_AREA__INFORMATIONFACILITY,
					oldInformationfacility, informationfacility));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<door> getDoor() {
		if (door == null) {
			door = new EObjectResolvingEList<door>(door.class, this, VehiclePackage.TAX_AREA__DOOR);
		}
		return door;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<safetyDevice> getSafetydevice() {
		if (safetydevice == null) {
			safetydevice = new EObjectResolvingEList<safetyDevice>(safetyDevice.class, this,
					VehiclePackage.TAX_AREA__SAFETYDEVICE);
		}
		return safetydevice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<window> getWindow() {
		if (window == null) {
			window = new EObjectResolvingEList<window>(window.class, this, VehiclePackage.TAX_AREA__WINDOW);
		}
		return window;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case VehiclePackage.TAX_AREA__CONTROLELEMENT:
			return ((InternalEList<?>) getControlelement()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case VehiclePackage.TAX_AREA__NAME:
			return getName();
		case VehiclePackage.TAX_AREA__CONTROLELEMENT:
			return getControlelement();
		case VehiclePackage.TAX_AREA__INFORMATIONFACILITY:
			if (resolve)
				return getInformationfacility();
			return basicGetInformationfacility();
		case VehiclePackage.TAX_AREA__DOOR:
			return getDoor();
		case VehiclePackage.TAX_AREA__SAFETYDEVICE:
			return getSafetydevice();
		case VehiclePackage.TAX_AREA__WINDOW:
			return getWindow();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case VehiclePackage.TAX_AREA__NAME:
			setName((String) newValue);
			return;
		case VehiclePackage.TAX_AREA__CONTROLELEMENT:
			getControlelement().clear();
			getControlelement().addAll((Collection<? extends controlElement>) newValue);
			return;
		case VehiclePackage.TAX_AREA__INFORMATIONFACILITY:
			setInformationfacility((informationFacility) newValue);
			return;
		case VehiclePackage.TAX_AREA__DOOR:
			getDoor().clear();
			getDoor().addAll((Collection<? extends door>) newValue);
			return;
		case VehiclePackage.TAX_AREA__SAFETYDEVICE:
			getSafetydevice().clear();
			getSafetydevice().addAll((Collection<? extends safetyDevice>) newValue);
			return;
		case VehiclePackage.TAX_AREA__WINDOW:
			getWindow().clear();
			getWindow().addAll((Collection<? extends window>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case VehiclePackage.TAX_AREA__NAME:
			setName(NAME_EDEFAULT);
			return;
		case VehiclePackage.TAX_AREA__CONTROLELEMENT:
			getControlelement().clear();
			return;
		case VehiclePackage.TAX_AREA__INFORMATIONFACILITY:
			setInformationfacility((informationFacility) null);
			return;
		case VehiclePackage.TAX_AREA__DOOR:
			getDoor().clear();
			return;
		case VehiclePackage.TAX_AREA__SAFETYDEVICE:
			getSafetydevice().clear();
			return;
		case VehiclePackage.TAX_AREA__WINDOW:
			getWindow().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case VehiclePackage.TAX_AREA__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case VehiclePackage.TAX_AREA__CONTROLELEMENT:
			return controlelement != null && !controlelement.isEmpty();
		case VehiclePackage.TAX_AREA__INFORMATIONFACILITY:
			return informationfacility != null;
		case VehiclePackage.TAX_AREA__DOOR:
			return door != null && !door.isEmpty();
		case VehiclePackage.TAX_AREA__SAFETYDEVICE:
			return safetydevice != null && !safetydevice.isEmpty();
		case VehiclePackage.TAX_AREA__WINDOW:
			return window != null && !window.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //taxAreaImpl
